# my_rule_based 빌드·실행 및 웹 접속 안내

대상: `revision_20260923_for`에 포함된 `my_rule_based` 워크스페이스  
작성일: 2026-09-30

이 패키지는 차선, 깊이 영상, 라이다 정보를 활용하는 규칙 기반 주행 실습용입니다. 웹에서 센서 정보를 확인하고 주행을 시작·일시정지할 수 있습니다. 깊이 영상의 커서 좌표 표시와 `for`·`yield`를 이용한 반복 명령을 지원합니다.

이 문서의 Bash 명령은 차량의 Jetson 터미널**에서 실행합니다. PC에서 접속한다면 먼저 SSH나 원격 데스크톱으로 차량에 접속합니다. 웹 브라우저는 차량 또는 같은 네트워크의 PC에서 사용할 수 있습니다.

## 1. 폴더 준비

PC의 `revision_20260923_for` 안에 있는 `my_rule_based` 폴더 전체를 차량의 `/home/jetson`으로 복사합니다. 최종 소스 위치는 다음과 같아야 합니다.

```text
/home/jetson/my_rule_based/src/my_rule_based_interfaces
/home/jetson/my_rule_based/src/my_rule_based_learning
```

기존 버전을 교체한다면 실행 중인 런치를 종료하고, 작성해 둔 실습 함수를 먼저 별도로 보관합니다. 같은 워크스페이스의 `src`에 구버전과 새 버전을 함께 넣지 않습니다. 새 버전의 `decision_node.py`에 보관한 실습 함수를 옮기되, 구버전 파일 전체로 덮어쓰지 않습니다.

차량 터미널에서 폴더를 확인합니다.

```bash
ls /home/jetson/my_rule_based/src
```

`my_rule_based_interfaces`, `my_rule_based_learning`이 표시되면 됩니다. 아래 명령은 모두 폴더 이름을 **`my_rule_based`**로 가정합니다. `my_rule_based_copy`와 혼용하지 않습니다.

## 2. 최초 빌드 — 차량 터미널 1

### 2-1. ROS 2와 차량 기본 패키지 환경 불러오기

ROS 2 Humble과 Yahboom 기본 차량·센서 패키지가 설치된 환경을 기준으로 합니다. 아래 두 Yahboom 경로는 실습 환경에서 사용하는 기본 경로이며, 다른 위치에 설치했다면 해당 경로로 바꿉니다.

```bash
source /opt/ros/humble/setup.bash
source /home/jetson/yahboomcar_ros2_ws/software/library_ws/install/setup.bash
source /home/jetson/yahboomcar_ros2_ws/yahboomcar_ws/install/setup.bash
```

필수 외부 패키지를 찾을 수 있는지 확인합니다. 각 명령에서 설치 경로가 출력되어야 합니다.

```bash
ros2 pkg prefix ascamera
ros2 pkg prefix yahboomcar_bringup
ros2 pkg prefix sllidar_ros2
```

`source` 경로가 없거나 패키지를 찾지 못하면 9절의 환경 설정 항목을 확인합니다. 이 교육용 워크스페이스에는 위 세 드라이버 패키지 자체가 들어 있지 않습니다.

웹 서버와 영상 처리에 필요한 Python 모듈도 확인합니다. 모듈이 없다는 오류가 나오면 9절의 의존성 설치 안내를 확인합니다. `colcon build`가 성공해도 실행에 필요한 Python 모듈이 모두 설치되었다는 뜻은 아닙니다.

```bash
python3 -c "import aiohttp, numpy, cv2; from cv_bridge import CvBridge; from geometry_msgs.msg import Twist; print('필수 모듈 확인 완료')"
```

### 2-2. 두 패키지 빌드 및 환경 불러오기

2-1절의 환경을 불러온 **같은 터미널**에서 빌드합니다. 빌드할 때 ROS 2와 Yahboom 환경 경로가 `install/setup.bash`에 기록됩니다.

```bash
cd /home/jetson/my_rule_based
colcon build --symlink-install --packages-select \
  my_rule_based_interfaces \
  my_rule_based_learning
```

두 패키지가 `Finished`로 끝나고 `Summary: 2 packages finished`가 표시되면 빌드 완료입니다. 실패한 패키지가 없다면 다음 명령을 실행합니다.

```bash
source /home/jetson/my_rule_based/install/setup.bash
```

`install/setup.bash`는 빌드 후 생성됩니다. 빌드 전부터 이 파일을 불러오면 파일을 찾을 수 없다는 메시지가 나올 수 있습니다.

### 2-3. 새 터미널에서 사용할 명령

빌드 이후 새 차량 터미널을 열 때마다 다음 **한 줄**로 ROS 2·Yahboom·교육용 워크스페이스 환경을 함께 불러옵니다. 이 작업만으로 노드가 실행되지는 않습니다.

```bash
source /home/jetson/my_rule_based/install/setup.bash
```

기존 빌드에서 ROS 2·Yahboom 환경이 누락되었다면 2-1절을 실행한 같은 터미널에서 2-2절의 빌드를 다시 수행합니다. 이후에는 위 한 줄만 사용합니다.

## 3. 센서 확인 및 미션 실행 — 차량 터미널 1

### 3-1. 먼저 센서 화면 확인하기

주행 명령 출력을 허용하지 않은 상태로 실행합니다. 아래는 깊이 미션을 선택한 예입니다.

```bash
ros2 launch my_rule_based_learning drive.launch.py \
  mission_mode:=depth enable_motion:=false
```

이 터미널은 실행 상태로 둡니다. `drive.launch.py`는 기본적으로 차량 제어부, 카메라, 라이다, 격자 처리, 웹 시각화, 주행 판단 노드를 함께 실행합니다.

**`enable_motion:=false`이면 `/cmd_vel`을 발행하지 않으며, 학생이 작성한 판단 함수도 실행하지 않습니다.** 센서와 웹 화면 확인용입니다. 웹에서 시작 버튼을 눌러도 이 설정을 바꿀 수 없습니다.

### 3-2. 예제 코드 작성하기

별도의 차량 터미널에서 다음 파일을 엽니다.

```bash
nano /home/jetson/my_rule_based/src/my_rule_based_learning/my_rule_based_learning/decision_node.py
```

선택한 미션에 해당하는 기존 함수 전체를 예제 함수로 교체합니다. 기존 함수 안에 같은 이름의 함수를 다시 정의하지 않습니다. `nano`에서는 `Ctrl+O`, Enter로 저장하고 `Ctrl+X`로 닫습니다.

| 미션 값 | 작성할 함수 | 전달되는 정보 |
| --- | --- | --- |
| `lane` | `decide_lane(V, L, R)` | 세로·좌우 가로 격자의 차선 특징값 |
| `depth` | `decide_depth(DEPTH_IMAGE)` | 픽셀별 깊이 거리 값이 담긴 NumPy 배열, 단위 mm |
| `lidar` | `decide_lidar(SCAN)` | `LaserScan` 메시지. 거리 m, 각도 rad |
| `integrated` | `decide_integrated(V, L, R, DEPTH_IMAGE, SCAN)` | 위 세 종류의 입력 모두 |

**기본 실습 함수는 정지 명령을 반환합니다.** 이동하는 예제 코드를 작성하지 않으면 주행 허용과 웹 시작을 설정해도 차량은 이동하지 않습니다.

반복 선회 예제는 다음 파일에서 확인할 수 있습니다. 이 파일을 열거나 실행하는 것만으로 판단 노드에 적용되지는 않습니다. 필요한 `decide_depth()` 함수를 위 파일에 옮겨야 합니다.

```bash
cat /home/jetson/my_rule_based/src/my_rule_based_learning/examples/depth_avoidance_example.py
```

### 3-3. 주행 명령 출력 허용하기

터미널 1에서 `Ctrl+C`로 기존 런치를 종료합니다. 이후 **실습할 미션의 명령 하나만** 실행합니다.

차선 주행:

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=lane enable_motion:=true
```

깊이 장애물 회피:

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=depth enable_motion:=true
```

라이다 장애물 회피:

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=lidar enable_motion:=true
```

통합 주행:

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=integrated enable_motion:=true
```

실행 후 웹 화면에서 **▶ 주행 시작**을 누릅니다. `enable_motion:=true`만으로 바로 주행을 시작하지는 않습니다. 실행 인자의 정확한 이름은 **`mission_mode`**입니다.

### 3-4. 종료·수정·재실행

1. 웹의 **Ⅱ 일시정지**를 누릅니다.
2. 터미널 1에서 `Ctrl+C`로 런치를 종료합니다.
3. 예제 코드 또는 설정을 수정합니다.
4. 필요한 경우 다시 빌드하고 환경을 불러온 뒤, 원하는 미션의 런치를 실행합니다.

`--symlink-install`로 빌드한 상태에서 기존 Python 파일의 함수 내용만 수정했다면 보통 노드 재시작으로 반영됩니다. 설정 YAML, 런치, 웹 파일, 메시지 정의 또는 패키지 구성을 수정하거나 버전을 교체했다면 다음 명령으로 다시 빌드합니다.

```bash
cd /home/jetson/my_rule_based
colcon build --symlink-install --packages-select \
  my_rule_based_interfaces \
  my_rule_based_learning
source /home/jetson/my_rule_based/install/setup.bash
```

웹 파일이 바뀌었다면 브라우저도 새로고침합니다. 이전 화면이 남아 있으면 `Ctrl+F5`로 강력 새로고침합니다.

### 3-5. 센서가 이미 실행 중인 경우

기존 차량·센서 드라이버를 그대로 사용하는 경우에만 해당 항목의 중복 실행을 끕니다. 다음은 세 드라이버가 모두 이미 실행 중인 경우입니다.

```bash
ros2 launch my_rule_based_learning drive.launch.py \
  mission_mode:=depth enable_motion:=false \
  start_bringup:=false start_camera:=false start_lidar:=false
```

| 실행 인자 | 기본값 | 실행 대상 |
| --- | --- | --- |
| `start_bringup` | `true` | Yahboom 차량 제어 런치 |
| `start_camera` | `true` | HP60C 카메라 드라이버 |
| `start_lidar` | `true` | C1 라이다 드라이버 |
| `start_grid` | `true` | `grid_node` |
| `start_vis` | `true` | `vis_node`와 웹 서버 |
| `start_decision` | `true` | `decision_node` |

웹 시각화만 별도로 실행할 때는 다음 명령을 사용합니다. 이 명령은 센서 드라이버나 판단 노드를 함께 실행하지 않습니다. 이미 `drive.launch.py`로 웹 서버를 실행했다면 중복 실행하지 않습니다.

```bash
ros2 launch my_rule_based_learning vis.launch.py
```

## 4. 웹 화면 접속과 사용

### 4-1. 접속 주소

차량 앞쪽 디스플레이에서 IP 주소를 확인하거나, 별도의 차량 터미널에서 다음 명령을 실행합니다.

```bash
hostname -I
```

주소가 여러 개 나오면 PC와 연결된 네트워크의 IP를 사용합니다. 같은 네트워크의 PC에서 브라우저 주소창에 다음 형식으로 입력합니다. `<차량-IP>` 부분을 실제 주소로 바꾸며 꺾쇠는 입력하지 않습니다.

```text
http://<차량-IP>:8080
```

예를 들어 차량 IP가 `192.168.0.20`이면 `http://192.168.0.20:8080`입니다. 차량 자체의 브라우저에서는 `http://localhost:8080`으로 접속할 수 있습니다. **PC 브라우저에서 `localhost`를 입력하면 차량이 아닌 PC에 접속하게 됩니다.**

### 4-2. 화면과 주행 버튼

| 항목 | 사용 방법 |
| --- | --- |
| RGB | 카메라의 컬러 영상 확인 |
| 격자 | 윤곽선·격자와 V·L·R 특징값의 미리보기 확인 |
| Depth | 깊이 영상, 커서 좌표, 관심 영역별 거리 통계 확인 |
| LiDAR | 라이다 측정점과 지정한 각도 구간의 거리 통계 확인 |
| ▶ 주행 시작 | 선택된 실행 미션의 판단·주행 시작. 단축키 `S` |
| Ⅱ 일시정지 | 주행 정지 요청. 단축키 `P` |

입력칸이나 선택 메뉴에 포커스가 있을 때는 `S`, `P` 단축키가 동작하지 않습니다. **화면 선택은 표시 내용만 바꿉니다.** 예를 들어 Depth 화면을 열어도 실행 미션이 `depth`로 바뀌지는 않습니다. 미션 변경은 런치를 종료하고 `mission_mode`를 바꾸어 다시 실행합니다.

### 4-3. 깊이 영상의 커서 좌표

Depth 영상 위에 마우스 커서를 올리면 **영상 오른쪽 위**에 `X: 320, Y: 240 px`와 같이 표시됩니다.

- 왼쪽 위는 `(0, 0)`, 오른쪽 아래는 `(639, 479)`입니다.
- X는 오른쪽으로, Y는 아래쪽으로 증가합니다.
- 화면 크기를 100%·75%·50%로 바꾸어도 좌표는 640×480 기준입니다.
- 커서를 영상 밖으로 옮기면 좌표 표시가 사라집니다.

커서 표시는 **영상의 픽셀 위치**입니다. 그 위치의 거리 값이나 실제 공간의 X·Y 좌표를 표시하는 기능은 아닙니다. 거리 값은 관심 영역 통계에서 확인합니다.

### 4-4. 관심 영역(ROI)과 주행 코드의 관계

Depth 화면에서 **+ ROI 추가**를 누르고 `y1, y2, x1, x2`를 입력한 다음 **ROI 적용·저장**을 누릅니다. 최대 16개 영역을 사용할 수 있으며, 유효한 거리 값의 최솟값·평균값·최댓값을 mm 단위로 확인합니다.

웹은 양 끝 픽셀을 포함합니다. 따라서 웹에서 `y1=200, y2=259, x1=300, x2=359`를 지정한 영역은 Python에서 다음과 같습니다.

```python
FRONT_ROI = DEPTH_IMAGE[200:260, 300:360]
```

**웹 ROI는 표시·통계용입니다. 저장해도 판단 함수의 ROI나 회피 기준이 자동으로 바뀌지 않습니다.** 주행에 사용할 영역은 `decision_node.py`의 실습 함수에 직접 작성합니다. 기본 원본 영상은 640×480이므로 웹 좌표와 배열 좌표가 일치합니다. 카메라 원본 해상도를 변경했다면 배열 좌표를 그 해상도에 맞춰야 합니다.

저장된 ROI는 기본적으로 `/home/jetson/.ros/my_rule_based_learning/depth_rois.json`에 기록되며, 같은 사용자로 재실행하면 복원됩니다. `ROS_HOME`이나 저장 경로 설정을 바꾸면 위치가 달라집니다.

격자의 **미리보기 적용**과 LiDAR 표시 설정도 웹 확인용입니다. 실제 차선 처리 설정은 `grid_node` 설정으로, 장애물 회피 조건은 학생 함수로 변경합니다.

## 5. 폴더 구조와 파일 역할

다음은 차량의 `/home/jetson/my_rule_based`를 기준으로 한 주요 구조입니다. `build`, `install`, `log`는 빌드 후 생성됩니다.

```text
/home/jetson/my_rule_based/
├── 사용_가이드_my_rule_based.md
├── README_FIXES_KO.md
├── VERIFICATION_20260923.md
├── src/
│   ├── my_rule_based_interfaces/
│   │   ├── msg/LaneFeatures.msg
│   │   ├── CMakeLists.txt
│   │   └── package.xml
│   └── my_rule_based_learning/
│       ├── my_rule_based_learning/
│       │   ├── decision_node.py
│       │   ├── grid_node.py
│       │   ├── grid_core.py
│       │   └── vis_node.py
│       ├── launch/
│       │   ├── drive.launch.py
│       │   ├── camera_15fps.launch.py
│       │   ├── grid.launch.py
│       │   └── vis.launch.py
│       ├── config/
│       │   ├── decision.yaml
│       │   ├── grid.yaml
│       │   └── vis.yaml
│       ├── examples/depth_avoidance_example.py
│       ├── web/index.html
│       ├── test/
│       ├── setup.py
│       ├── setup.cfg
│       └── package.xml
├── build/
├── install/
└── log/
```

| 파일·폴더 | 역할 |
| --- | --- |
| `my_rule_based_interfaces` | 차선 특징값 메시지 `LaneFeatures` 정의 |
| `decision_node.py` | 학생의 판단 함수와 명령 발행·정지·반복 실행 처리 |
| `grid_core.py` | 회색조 변환, 블러링, 캐니 윤곽선 검출과 격자 특징값 계산. 독립 실행 노드가 아닌 함수 모듈 |
| `grid_node.py` | RGB 영상 수신, 특징값 계산 호출, `/lane_features` 발행 |
| `vis_node.py` | 웹 서버, 센서 시각화, ROI 통계·저장, 주행 시작·일시정지 요청 |
| `drive.launch.py` | 차량·센서·학습 노드 통합 실행과 미션 선택 |
| `camera_15fps.launch.py` | HP60C 드라이버 실행. 파일명과 달리 현재 코드의 요청 설정은 640×480, 25fps |
| `decision.yaml` | 판단 주기, 센서·함수 시간 초과, 속도 제한, 깊이 정보 처리 기준 |
| `grid.yaml` | RGB·특징값 토픽과 차선 처리 설정. 명시하지 않은 격자 기본값은 `grid_node.py`에서 사용 |
| `vis.yaml` | 웹 포트, 센서 토픽, 깊이·라이다 표시 설정 |
| `web/index.html` | 브라우저 화면과 버튼·좌표 표시 코드 |
| `examples` | 학생 함수로 옮겨 사용하는 예제. 자동 적용되지 않음 |
| `test` | 합성 입력과 테스트 대역을 사용하는 검증 코드 |
| `build` / `install` / `log` | 빌드 중간 결과 / 설치 결과와 환경 설정 / 빌드 로그 |

## 6. 노드·토픽·메시지 타입

**노드**는 기능을 실행하는 프로그램 단위, **토픽**은 노드가 메시지를 발행·구독하는 이름, **메시지 타입**은 전달되는 데이터의 구조입니다. 아래 이름은 이 패키지의 기본 설정 기준입니다.

### 6-1. 주요 노드

| 노드 | 주요 역할 |
| --- | --- |
| `/ascamera_hp60c/camera_publisher` | 외부 `ascamera` 패키지의 HP60C 카메라 드라이버. RGB·깊이 영상 발행 |
| C1 라이다 드라이버 | 외부 `sllidar_ros2`의 `sllidar_c1_launch.py`로 실행. `/scan` 발행. 실제 노드명은 설치된 드라이버와 `ros2 node list`로 확인 |
| `/grid_node` | RGB 영상에서 차선 특징값을 계산해 `/lane_features` 발행 |
| `/decision_node` | 선택 미션의 함수 실행, 주행 명령 발행, 정지 사유 전달 |
| `/vis_node` | 웹 시각화와 주행 시작·일시정지 요청 처리 |
| Yahboom 차량 제어 노드 | 외부 `yahboomcar_bringup_A1_launch.py`로 실행. 차량의 `/cmd_vel` 명령 처리. 실제 노드명은 설치 구성에 따라 확인 |

`grid_core.py`와 `decide_lane()` 등의 학생 함수는 별도의 ROS 노드가 아닙니다. 각각 호출한 노드 안에서 실행됩니다.

### 6-2. 주요 토픽

| 토픽 | 메시지 타입 | 전달 방향과 내용 |
| --- | --- | --- |
| `/ascamera_hp60c/camera_publisher/rgb0/image` | `sensor_msgs/msg/Image` | 카메라 → `grid_node`, `vis_node`. 컬러 영상 |
| `/ascamera_hp60c/camera_publisher/depth0/image_raw` | `sensor_msgs/msg/Image` | 카메라 → `decision_node`, `vis_node`. 원본 깊이 영상 |
| `/scan` | `sensor_msgs/msg/LaserScan` | 라이다 → `decision_node`, `vis_node`. 방향별 거리 값 |
| `/lane_features` | `my_rule_based_interfaces/msg/LaneFeatures` | `grid_node` → `decision_node`. 차선 특징값과 영상·격자 정보 |
| `/driving_enabled` | `std_msgs/msg/Bool` | `vis_node` → `decision_node`. 웹 시작 `true`, 일시정지 `false` 요청 |
| `/cmd_vel` | `geometry_msgs/msg/Twist` | `decision_node` → 차량 제어부. 선속도·각속도 명령. 주행 출력 허용 시에만 발행자 생성 |
| `/decision_status` | `std_msgs/msg/String` | `decision_node` → `vis_node`. 주행 허용 상태와 정지 사유를 담은 JSON 문자열 |

웹 격자 화면은 `vis_node`가 RGB 영상에서 별도로 계산하는 미리보기입니다. `vis_node`는 `/lane_features`를 구독하지 않습니다. 격자 설정을 읽을 때는 `/grid_node/get_parameters` 서비스(`rcl_interfaces/srv/GetParameters`)를 사용합니다.

브라우저는 `vis_node`의 HTTP 서버에 접속합니다. 브라우저가 ROS 토픽을 직접 구독하거나 `/cmd_vel`을 직접 발행하는 구조는 아닙니다.

### 6-3. 메시지에서 사용하는 주요 항목

| 메시지 타입 | 주요 항목과 의미 |
| --- | --- |
| `Image` | `height`, `width`: 영상 크기 / `encoding`: 인코딩 형식 / `step`: 한 행의 바이트 수 / `data`: 픽셀 데이터 |
| `LaserScan` | `ranges`: 거리 배열(m) / `angle_min`: 시작 각도(rad) / `angle_increment`: 측정점 사이 각도 간격(rad) / `range_min`, `range_max`: 유효 거리 범위(m) |
| `LaneFeatures` | `v`, `l`, `r`: 차선 특징값 배열 / `image_width`, `image_height`: 처리 영상 크기 / `rows`, `cols`, `roi_bottom_px`, `roi_top_px`: 격자·관심 영역 설정 / `v_no_hit`, `l_no_hit`, `r_no_hit`: 미검출값 / `header`: 프레임 시각 등의 정보 |
| `Twist` | `linear.x`: 앞뒤 선속도(m/s) / `angular.z`: 차체 방향의 변화 속도(rad/s) |
| `Bool` | `data`에 `true` 또는 `false` 저장 |
| `String` | `data`에 문자열 저장. `/decision_status`에서는 `driving_enabled`, `reason` 항목의 JSON 사용 |

`LaneFeatures`의 필드는 소문자 `v`, `l`, `r`이며, 판단 노드가 학생 함수에 전달할 때 `V`, `L`, `R`로 사용합니다. `linear.x`는 양수이면 전진, 음수이면 후진입니다. 전진 시 `angular.z`는 양수이면 좌회전, 음수이면 우회전 명령입니다. 각속도는 앞바퀴의 조향 각도 자체가 아닙니다.

원본 깊이 영상이 `16UC1`이면 부호 없는 16비트 단일 채널이며 HP60C 거리 단위는 mm입니다. 판단 노드는 이를 **float32형 mm 배열**로 바꾸어 `DEPTH_IMAGE`에 전달합니다. `32FC1`로 들어오는 m 단위 영상도 mm로 변환합니다. 기본 설정에서는 미검출값과 200mm 미만을 0으로 처리하고, 유효한 4000mm 초과 값은 4000mm로 제한합니다. 원본 토픽 자체를 변경하지는 않습니다.

### 6-4. 미션별 필수 입력

| 미션 | 주행 판단에 필요한 최신 입력 |
| --- | --- |
| `lane` | `/lane_features` |
| `depth` | 깊이 영상 |
| `lidar` | `/scan` |
| `integrated` | 차선 특징값, 깊이 영상, `/scan` 모두 |

기본 런치는 모든 센서를 실행하고 판단 노드도 모두 구독하지만, 오래된 입력인지 확인하는 대상은 현재 미션의 필수 입력입니다. 기본 시간 초과는 1초입니다. 센서 미수신·시간 초과 시 정지하며, 입력이 복구되면 주행 허용 상태에 따라 새로 판단할 수 있습니다. 학생 함수 오류·실행 시간 초과는 주행을 비활성화하므로 원인을 해결하고 다시 시작해야 합니다.

## 7. 동작 확인 명령 — 차량 터미널 2

터미널 1에서 런치를 실행한 채 새 터미널을 엽니다. 2-3절의 환경 불러오기 명령을 먼저 실행합니다. 아래는 **상태 확인용 명령**이며 주행 명령을 새로 보내지 않습니다. 연속 출력되는 명령은 `Ctrl+C`로 종료합니다.

설치된 패키지와 실행 중인 노드 확인:

```bash
ros2 pkg prefix my_rule_based_learning
ros2 node list
ros2 node info /decision_node
```

토픽 이름·타입과 연결 확인:

```bash
ros2 topic list -t
ros2 topic info /lane_features
ros2 topic info /scan
ros2 topic info /cmd_vel
```

메시지 구조 확인:

```bash
ros2 interface show my_rule_based_interfaces/msg/LaneFeatures
ros2 interface show sensor_msgs/msg/Image
ros2 interface show sensor_msgs/msg/LaserScan
ros2 interface show geometry_msgs/msg/Twist
```

차선 특징값·주행 명령·정지 사유 확인:

```bash
ros2 topic echo /lane_features
```

```bash
ros2 topic echo /cmd_vel
```

```bash
ros2 topic echo /decision_status --qos-durability transient_local
```

각 명령은 필요할 때 하나씩 실행합니다. `enable_motion:=false`에서는 이 판단 노드가 `/cmd_vel`을 발행하지 않으므로 명령 출력이 없을 수 있습니다.

`/decision_status`는 상태가 바뀔 때 발행되므로, 늦게 연 터미널에서도 최근 상태를 받도록 위 명령에 `--qos-durability transient_local`을 지정합니다.

센서 수신 주기 확인:

```bash
ros2 topic hz /ascamera_hp60c/camera_publisher/depth0/image_raw
```

```bash
ros2 topic hz /scan
```

현재 실행 설정 확인:

```bash
ros2 param get /decision_node mode
ros2 param get /decision_node publish_cmd_vel
ros2 param get /decision_node timer_hz
ros2 param get /vis_node web_port
```

## 8. `return`과 `for`·`yield` 사용

한 번 판단한 명령을 반환할 때는 `return command`를 사용합니다. 반복 명령을 전달할 때는 다음처럼 사용합니다.

```python
for _ in range(15):
    yield command
```

이 버전의 판단 노드는 한 판단 주기마다 명령을 하나씩 받습니다. 기본 `timer_hz: 10.0`에서 15회는 약 1.5초에 해당합니다. 반복 중에는 함수가 멈춘 위치부터 이어서 실행되므로, 반복문 앞에서 계산한 거리 값은 다시 계산되지 않습니다. 웹 정지와 센서 시간 초과 감시는 계속 동작합니다.

반복 함수가 받은 센서 입력은 함수 시작 시 복사한 값입니다. 반복 중 같은 배열을 다시 계산해도 최신 프레임으로 갱신되지 않으며, 반복이 끝난 뒤 새 함수 호출에서 최신 입력을 받습니다.

`yield`를 사용하는 함수에서는 명령을 전달하는 각 분기에도 `yield command`를 사용합니다. 같은 함수의 다른 분기에 `return command`를 쓰면 그 값이 일반 주행 명령처럼 전달되지 않고 반복이 종료됩니다. 한 번도 `yield`하지 않고 종료하는 실행 경로는 오류로 처리되어 주행이 자동 정지합니다. 일반 반환 방식의 함수에는 `yield`를 섞지 않습니다.

다음 명령으로 **현재 터미널 환경에서 불러오는 파일 위치와 반복 지원 여부**를 확인할 수 있습니다. 이미 실행 중인 다른 터미널의 노드를 조사하는 명령은 아닙니다.

```bash
python3 - <<'PY'
import my_rule_based_learning.decision_node as module
print("불러온 파일:", module.__file__)
print("반복 명령 지원:", hasattr(module.DecisionNode, "cancel_rule_sequence"))
PY
```

이 배포본에서는 `반복 명령 지원: True`가 나와야 합니다. 파일이 예상 경로와 다르거나 `False`이면 구버전 또는 다른 워크스페이스를 불러온 상태인지 확인합니다.

## 9. 자주 발생하는 문제

| 증상 | 확인 및 조치 |
| --- | --- |
| `install/setup.bash: 그런 파일이나 디렉터리가 없습니다` | 먼저 빌드가 완료되었는지 확인합니다. 실제 폴더가 `/home/jetson/my_rule_based`인지 확인하고, `my_rule_based_copy` 등 다른 경로를 불러오지 않도록 합니다. |
| `Package ... not found` | `source /home/jetson/my_rule_based/install/setup.bash`를 실행했는지 확인합니다. 상위 환경이 누락된 기존 빌드라면 2-1절 실행 후 같은 터미널에서 다시 빌드합니다. 외부 드라이버는 별도로 설치되어 있어야 합니다. |
| `Twist를 반환해야 합니다`가 나오며 `yield` 예제가 정지 | 반복 실행을 지원하지 않는 버전이 실행될 때 발생할 수 있습니다. 새 버전의 패키지와 학생 함수를 함께 적용하고, 다시 빌드·환경 불러오기·런치 재시작을 합니다. 함수가 `None` 등 잘못된 값을 반환하는지도 확인합니다. |
| 웹은 열리지만 움직이지 않음 | `enable_motion:=true`, 올바른 `mission_mode`, 웹 ▶ 시작, 필수 센서 수신, 이동 명령을 작성한 함수가 모두 필요한지 확인합니다. 기본 함수는 정지 명령입니다. `/decision_status`도 확인합니다. |
| 웹 화면이 열리지 않음 | `vis_node`가 실행 중인지, PC와 차량이 같은 네트워크인지, 차량 IP와 포트 8080이 맞는지 확인합니다. PC의 `localhost`를 사용하지 않습니다. |
| 포트 8080 사용 중 오류 | 기존 웹 서버나 런치가 남아 있는지 확인하고, 해당 터미널에서 종료합니다. `drive.launch.py`와 `vis.launch.py`를 중복 실행하지 않습니다. |
| 커서 좌표가 표시되지 않음 | Depth 화면인지 확인하고 영상 위로 커서를 옮깁니다. 이전 웹 파일이 남아 있으면 새 패키지로 다시 빌드·재실행한 후 `Ctrl+F5`로 새로고침합니다. |
| 웹 ROI를 바꿨지만 주행은 그대로임 | 웹 ROI는 표시용입니다. 판단 함수의 NumPy 슬라이스와 거리 조건을 별도로 수정하고 노드를 재시작합니다. |
| `Mean of empty slice` | 0을 제외한 뒤 ROI에 값이 남지 않은 경우입니다. `ROI.size`를 확인한 뒤 평균을 계산합니다. 값이 없다는 것을 장애물이 없다는 뜻으로 처리하지 않습니다. |

### 환경 경로 확인

기본 Yahboom 경로에 환경 파일이 없다면 실제 설치 위치를 찾아 올바른 `setup.bash`를 불러옵니다.

```bash
ls /opt/ros
find /home/jetson/yahboomcar_ros2_ws -type f -path '*/install/setup.bash'
```

새 터미널을 열 때마다 잘못된 경로 오류가 반복되면 `/home/jetson/.bashrc`에 남은 이전 `source` 명령을 확인합니다.

```bash
nano /home/jetson/.bashrc
```

### Python 모듈이 없다는 오류

`aiohttp`, `numpy`, `cv2`를 찾지 못하면 인터넷에 연결된 차량에서 다음 패키지를 설치합니다.

```bash
sudo apt update
sudo apt install python3-aiohttp python3-numpy python3-opencv
```

ROS 환경을 불러왔는데도 `cv_bridge` 또는 `geometry_msgs`가 없으면 Humble용 패키지를 확인·설치합니다.

```bash
sudo apt install ros-humble-cv-bridge ros-humble-geometry-msgs
```

설치 후 2-1절의 모듈 확인 명령을 다시 실행합니다.

### 빌드 중 ‘파일의 변경 시각이 미래입니다’ 경고

파일의 수정 시각보다 차량 시스템 시간이 과거인 경우 발생할 수 있습니다. 먼저 차량 시간을 확인합니다.

```bash
date
timedatectl status
```

날짜·시간이 잘못되어 있다면 차량을 인터넷에 연결하고 자동 시간 동기화를 활성화합니다.

```bash
sudo timedatectl set-ntp true
```

잠시 뒤 `timedatectl status`로 실제 시각과 `System clock synchronized: yes`를 확인한 다음 다시 빌드합니다. `set-ntp true`만 입력했다고 즉시 동기화된 것은 아닙니다. `2 packages finished`와 함께 `had stderr output`이 표시되었다면, 경고 출력인지 실제 빌드 실패인지 로그를 구분해 확인합니다.

---
