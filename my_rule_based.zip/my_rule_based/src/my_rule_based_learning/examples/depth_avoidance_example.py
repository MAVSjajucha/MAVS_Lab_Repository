"""Replace decide_depth() in the generator-capable decision_node.py.

Central 40x40 ROI in a 640x480 depth image; millimetres; invalid values are zero.
Each yield lasts one decision timer interval (default 10 Hz: ten yields ~1 s).
The vehicle moves forward while steering; this is not an in-place turn.
"""

import numpy as np
from geometry_msgs.msg import Twist

def decide_depth(DEPTH_IMAGE):
    command = Twist()

    ROI = DEPTH_IMAGE[220:260, 300:340]
    ROI = ROI[ROI > 0]
    FRONT = np.mean(ROI) if ROI.size else 0

    if FRONT < 700:
        command.linear.x = 0.04
        command.angular.z = 0.4
        for _ in range(10):
            yield command
    else:
        command.linear.x = 0.1
        command.angular.z = 0.0
        yield command
