"""
규칙 기반 자율주행 교육용 decision_node.

학생 실습 영역:
    1. decide_lane()
    2. decide_depth()
    3. decide_lidar()
    4. decide_integrated()

ROS 구독, 웹 시작/정지 연동 및 /cmd_vel 발행 구조는
학생 실습 영역 아래에 분리되어 있습니다.
"""

import json
import math
import threading
import time
import traceback
from collections.abc import Iterator
from copy import deepcopy

import numpy as np
import rclpy
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist
from my_rule_based_interfaces.msg import LaneFeatures
from rclpy.callback_groups import (
    MutuallyExclusiveCallbackGroup,
    ReentrantCallbackGroup,
)
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image, LaserScan
from std_msgs.msg import Bool, String

# ============================================================
# 학생 실습 영역 시작
# ============================================================

def decide_lane(V, L, R):
    """
    V, L, R 리스트를 이용하여 차선 주행 명령을 작성합니다.

    사용 예:
        V[0], V[1], ...
        L[0], L[1], ...
        R[0], R[1], ...

    웹에서 설정한 표시용 격자가 아니라 grid_node가 발행한
    실제 LaneFeatures 값이 전달됩니다.
    좌우 차선을 찾지 못한 L/R 값은 모두 영상너비 // 2 + 1입니다.
    640픽셀 영상에서는 L/R 모두 321이므로 기존 R == 320 조건은 바꾸세요.
    """
    command = Twist()

    # TODO: V, L, R을 이용한 조건문을 작성하세요.
    #
    # if 조건:
    #     command.linear.x = ...
    #     command.angular.z = ...
    # elif 다른_조건:
    #     ...
    # else:
    #     ...

    return command


def decide_depth(DEPTH_IMAGE):
    """
    mm 단위 Depth 거리로 장애물 회피 명령을 작성합니다.

    DEPTH_IMAGE는 2차원 float32 NumPy 배열이며 각 픽셀값은 mm 단위입니다.
    16UC1의 mm 값과 32FC1의 m 값을 모두 mm로 처리합니다.
    기본값: 200mm 미만 및 미검출(0/음수/NaN/Inf)은 0,
    200~4000mm는 측정값 유지, 4000mm 초과의 유효값은 4000입니다.
    decision.yaml의 depth_min_mm, depth_max_mm, depth_invalid_value_mm으로
    기준을 바꿀 수 있습니다. 원본 미검출값만으로 너무 가까운지 먼지는
    구분할 수 없습니다. 유효값은 DEPTH_IMAGE > 0으로 선택하세요.

    웹에서 지정한 ROI와 통계는 전달되지 않습니다.
    학생이 직접 ROI를 슬라이싱하고 거리값을 계산해야 합니다.
    배열은 원본 해상도를 유지합니다. 입력이 640x480이면 웹 표시 좌표와
    일치하며, 다른 해상도에서는 원본 좌표로 슬라이싱해야 합니다.
    """
    command = Twist()

    # TODO: 학생이 직접 ROI와 조건문을 작성하세요.
    #
    # 예:
    # 웹 ROI의 끝 좌표(x2, y2)도 포함하려면 슬라이스 끝에 +1을 붙입니다.
    # ROI_DISTANCE = DEPTH_IMAGE[y1:y2 + 1, x1:x2 + 1]
    # VALID_DISTANCE = ROI_DISTANCE[ROI_DISTANCE > 0]
    # if VALID_DISTANCE.size:
    #     MEAN_DISTANCE = VALID_DISTANCE.mean()
    #
    # 평균, 중앙값, 최솟값 또는 개별 픽셀 중 무엇을 사용할지는
    # 학생이 직접 결정합니다.

    return command


def decide_lidar(SCAN):
    """
    원본 LaserScan 메시지로 장애물 회피 명령을 작성합니다.

    SCAN에서 직접 사용할 수 있는 주요 필드:
        SCAN.angle_min
        SCAN.angle_max
        SCAN.angle_increment
        SCAN.range_min
        SCAN.range_max
        SCAN.ranges

    웹에서 지정한 각도 구간과 통계는 전달되지 않습니다.
    학생이 각도, 인덱스, 거리값을 직접 재구성해야 합니다.
    """
    command = Twist()

    # TODO: SCAN.ranges를 이용한 조건문을 직접 작성하세요.

    return command


def decide_integrated(V, L, R, DEPTH_IMAGE, SCAN):
    """차선·Depth 거리·LiDAR를 조합합니다. Depth 설명은 위와 같습니다."""
    command = Twist()

    # TODO: 세 가지 입력의 판단 우선순위를 직접 설계하세요.

    return command


# 현재 수업에서 사용하지 않는 함수는 그대로 두거나 삭제해도 됩니다.
# decision_node는 현재 mode에 해당하는 함수만 호출합니다.

# ============================================================
# 학생 실습 영역 끝
# ============================================================


VALID_MODES = ("lane", "depth", "lidar", "integrated")
RULE_NAMES = {
    "lane": "decide_lane",
    "depth": "decide_depth",
    "lidar": "decide_lidar",
    "integrated": "decide_integrated",
}


class DecisionNode(Node):
    """Twist 반환과 주기마다 Twist를 하나씩 yield하는 반복 판단을 지원합니다."""

    def __init__(self):
        super().__init__("decision_node")

        self.declare_parameter("mode", "lane")

        self.declare_parameter(
            "lane_features_topic",
            "/lane_features",
        )
        self.declare_parameter(
            "depth_topic",
            "/ascamera_hp60c/camera_publisher/depth0/image_raw",
        )
        self.declare_parameter(
            "scan_topic",
            "/scan",
        )
        self.declare_parameter(
            "driving_enabled_topic",
            "/driving_enabled",
        )
        self.declare_parameter(
            "cmd_vel_topic",
            "/cmd_vel",
        )

        self.declare_parameter("publish_cmd_vel", False)
        self.declare_parameter("timer_hz", 10.0)
        self.declare_parameter("sensor_timeout_sec", 1.0)
        self.declare_parameter("rule_timeout_sec", 1.0)
        self.declare_parameter("decision_status_topic", "/decision_status")

        self.declare_parameter("depth_min_mm", 200.0)
        self.declare_parameter("depth_max_mm", 4000.0)
        self.declare_parameter("depth_invalid_value_mm", 0.0)
        (self.DEPTH_MIN_MM, self.DEPTH_MAX_MM,
         self.DEPTH_INVALID_VALUE_MM) = self.validate_depth_parameters(
            self.get_parameter("depth_min_mm").value,
            self.get_parameter("depth_max_mm").value,
            self.get_parameter("depth_invalid_value_mm").value,
        )

        # 초기 제한값이며 decision.yaml이나 실행 인자로 변경할 수 있다.
        self.declare_parameter("max_linear_mps", 0.5)
        self.declare_parameter("max_angular_rps", 0.5)

        self.MODE = str(
            self.get_parameter("mode").value
        ).strip().lower()

        if self.MODE not in VALID_MODES:
            raise ValueError(
                f"mode must be one of {VALID_MODES}, "
                f"got {self.MODE!r}"
            )

        self.PUBLISH_CMD_VEL = bool(
            self.get_parameter("publish_cmd_vel").value
        )
        self.TIMER_HZ = float(self.get_parameter("timer_hz").value)
        self.SENSOR_TIMEOUT_SEC = float(
            self.get_parameter("sensor_timeout_sec").value
        )
        self.RULE_TIMEOUT_SEC = float(
            self.get_parameter("rule_timeout_sec").value
        )
        self.MAX_LINEAR_MPS = abs(
            float(self.get_parameter("max_linear_mps").value)
        )
        self.MAX_ANGULAR_RPS = abs(
            float(self.get_parameter("max_angular_rps").value)
        )
        for name, value in (
            ("timer_hz", self.TIMER_HZ),
            ("sensor_timeout_sec", self.SENSOR_TIMEOUT_SEC),
            ("rule_timeout_sec", self.RULE_TIMEOUT_SEC),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not all(math.isfinite(value) for value in (
            self.MAX_LINEAR_MPS, self.MAX_ANGULAR_RPS
        )):
            raise ValueError("Speed limits must be finite")

        self.CMD_VEL_TOPIC = str(
            self.get_parameter("cmd_vel_topic").value
        )
        self.DRIVING_ENABLED_TOPIC = str(
            self.get_parameter(
                "driving_enabled_topic"
            ).value
        )

        # 시작 상태는 항상 정지다.
        self.DRIVING_ENABLED = False
        self.STATE_LOCK = threading.RLock()
        self.CONTROL_GENERATION = 0
        self.SENSOR_TIMES = {"lane": None, "depth": None, "lidar": None}
        self.DEPTH_GENERATION = 0
        self.RULE_STARTED = None
        self.RULE_ITERATOR = None
        self.RETIRED_RULE_ITERATORS = []
        self.RULE_TIMEOUT_REPORTED = False
        self.LAST_ERROR_TIME = float("-inf")
        self.STOP_REASON = "웹에서 시작 명령을 기다리는 중입니다."
        self.LAST_STATUS = None

        # 모든 미션 입력을 항상 보관한다.
        self.V = []
        self.L = []
        self.R = []
        self.DEPTH_IMAGE = None
        self.SCAN = None

        self.BRIDGE = CvBridge()

        rule_name = RULE_NAMES[self.MODE]
        self.RULE_FUNCTION = globals().get(rule_name)

        if not callable(self.RULE_FUNCTION):
            raise NameError(
                f"현재 mode={self.MODE!r}에 필요한 "
                f"{rule_name}() 함수가 없습니다."
            )

        # 학생 판단 함수가 실행 중이어도 p 정지 신호를 처리하기 위해
        # 센서/제어와 판단 타이머의 callback group을 분리한다.
        self.SENSOR_GROUP = ReentrantCallbackGroup()
        self.CONTROL_GROUP = ReentrantCallbackGroup()
        self.RULE_GROUP = MutuallyExclusiveCallbackGroup()
        sensor_qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
        )

        self.create_subscription(
            LaneFeatures,
            str(
                self.get_parameter(
                    "lane_features_topic"
                ).value
            ),
            self.lane_callback,
            sensor_qos,
            callback_group=self.SENSOR_GROUP,
        )

        self.create_subscription(
            Image,
            str(
                self.get_parameter("depth_topic").value
            ),
            self.depth_callback,
            sensor_qos,
            callback_group=self.SENSOR_GROUP,
        )

        self.create_subscription(
            LaserScan,
            str(
                self.get_parameter("scan_topic").value
            ),
            self.scan_callback,
            sensor_qos,
            callback_group=self.SENSOR_GROUP,
        )

        self.create_subscription(
            Bool,
            self.DRIVING_ENABLED_TOPIC,
            self.driving_enabled_callback,
            10,
            callback_group=self.CONTROL_GROUP,
        )

        # enable_motion=true일 때만 /cmd_vel 발행자가 생성된다.
        self.CMD_PUBLISHER = None
        if self.PUBLISH_CMD_VEL:
            self.CMD_PUBLISHER = self.create_publisher(
                Twist,
                self.CMD_VEL_TOPIC,
                10,
            )

        self.DECISION_STATUS_PUBLISHER = self.create_publisher(
            String,
            str(self.get_parameter("decision_status_topic").value),
            QoSProfile(
                depth=1,
                reliability=ReliabilityPolicy.RELIABLE,
                durability=DurabilityPolicy.TRANSIENT_LOCAL,
            ),
        )
        self.publish_decision_status(False, self.STOP_REASON)

        self.create_timer(
            1.0 / self.TIMER_HZ,
            self.timer_callback,
            callback_group=self.RULE_GROUP,
        )
        # 판단 함수가 오래 걸려도 별도 callback group에서 정지시킨다.
        self.create_timer(
            min(0.1, self.SENSOR_TIMEOUT_SEC / 2, self.RULE_TIMEOUT_SEC / 2),
            self.watchdog_callback,
            callback_group=self.CONTROL_GROUP,
        )

        self.get_logger().info(
            "Decision ready: "
            f"mode={self.MODE}, "
            "subscriptions=lane+depth+lidar, "
            f"publish_cmd_vel={self.PUBLISH_CMD_VEL}, "
            "driving_enabled=False"
        )

        if not self.PUBLISH_CMD_VEL:
            self.get_logger().warning(
                "Motion output is disabled. "
                "Set enable_motion:=true only for an actual driving test."
            )

    def lane_callback(self, message):
        with self.STATE_LOCK:
            received_at = time.monotonic()
            self.cancel_after_sensor_gap("lane", received_at)
            self.V = list(message.v)
            self.L = list(message.l)
            self.R = list(message.r)
            self.SENSOR_TIMES["lane"] = received_at

    @staticmethod
    def validate_depth_parameters(min_mm, max_mm, invalid_mm):
        values = tuple(float(value) for value in (min_mm, max_mm, invalid_mm))
        limit = float(np.finfo(np.float32).max)
        if not all(math.isfinite(value) and abs(value) <= limit for value in values):
            raise ValueError("Depth parameters must be finite float32 values")
        min_mm, max_mm, invalid_mm = values
        if not 0.0 <= min_mm < max_mm or invalid_mm > 0.0:
            raise ValueError("Require 0 <= depth_min_mm < depth_max_mm and depth_invalid_value_mm <= 0")
        normalized = tuple(float(np.float32(value)) for value in values)
        if (normalized[0] >= normalized[1]
                or any(value != 0.0 and converted == 0.0
                       for value, converted in zip(values, normalized))):
            raise ValueError("Depth parameters lose their meaning when converted to float32")
        return normalized

    def depth_callback(self, message):
        # 원본 Image의 해상도를 유지한 mm 거리 배열을 만든다. 웹 ROI는 사용하지 않는다.
        with self.STATE_LOCK:
            self.DEPTH_GENERATION += 1
            generation = self.DEPTH_GENERATION
            received_at = time.monotonic()
            self.cancel_after_sensor_gap("depth", received_at)
        try:
            pixels = self.BRIDGE.imgmsg_to_cv2(
                message,
                desired_encoding="passthrough",
            )
            pixels = np.asarray(pixels)
            if pixels.ndim != 2 or pixels.size == 0:
                raise ValueError("Depth input must be a nonempty 2D image")
            if message.encoding == "16UC1":
                if pixels.dtype != np.uint16:
                    raise ValueError("16UC1 depth input must contain uint16 pixels")
                # uint16 cannot represent -1; use a signed-capable float32 copy.
                depth_image = pixels.astype(np.float32)
            elif message.encoding == "32FC1":
                if pixels.dtype != np.float32:
                    raise ValueError("32FC1 depth input must contain float32 pixels")
                depth_image = pixels.copy()
                # 단위 변환 중 오버플로도 다른 미검출과 같이 처리한다.
                with np.errstate(over="ignore", invalid="ignore"):
                    depth_image *= np.float32(1000.0)
            else:
                raise ValueError("Depth encoding must be 16UC1 (mm) or 32FC1 (m)")
            invalid = (~np.isfinite(depth_image) | (depth_image <= 0.0)
                       | (depth_image < self.DEPTH_MIN_MM))
            np.minimum(depth_image, self.DEPTH_MAX_MM, out=depth_image)
            depth_image[invalid] = self.DEPTH_INVALID_VALUE_MM
        except Exception:
            with self.STATE_LOCK:
                if generation != self.DEPTH_GENERATION:
                    return
                self.DEPTH_IMAGE = None
                self.SENSOR_TIMES["depth"] = None
                if self.MODE in ("depth", "integrated"):
                    self.cancel_rule_sequence()
            self.report_input_error("Depth conversion failed")
            return
        with self.STATE_LOCK:
            # Older conversion must not overwrite a newer callback's input or timestamp.
            if generation != self.DEPTH_GENERATION:
                return
            self.DEPTH_IMAGE = depth_image
            self.SENSOR_TIMES["depth"] = received_at

    def scan_callback(self, message):
        # 각도 구간이나 거리 통계를 만들지 않고 원본 메시지를 저장한다.
        with self.STATE_LOCK:
            received_at = time.monotonic()
            self.cancel_after_sensor_gap("lidar", received_at)
            self.SCAN = message
            self.SENSOR_TIMES["lidar"] = received_at

    def driving_enabled_callback(self, message):
        with self.STATE_LOCK:
            previous = self.DRIVING_ENABLED
            self.DRIVING_ENABLED = bool(message.data)
            self.cancel_rule_sequence()
            self.STOP_REASON = "" if self.DRIVING_ENABLED else "웹에서 주행을 정지했습니다."
            if not self.DRIVING_ENABLED:
                self.publish_stop()
            enabled = self.DRIVING_ENABLED
            self.update_decision_status(time.monotonic())

        if previous != enabled:
            state = (
                "START"
                if enabled
                else "PAUSE"
            )
            self.get_logger().info(
                f"Driving permission: {state}"
            )

    def student_arguments(self):
        # 센서 갱신과 같은 잠금으로 입력을 복사하여 학생 함수의 수정을 분리한다.
        with self.STATE_LOCK:
            if self.MODE == "lane":
                return (list(self.V), list(self.L), list(self.R))

            if self.MODE == "lidar":
                return (deepcopy(self.SCAN),)

            depth_image = (
                None
                if self.DEPTH_IMAGE is None
                else self.DEPTH_IMAGE.copy()
            )
            if self.MODE == "depth":
                return (depth_image,)

            return (
                list(self.V),
                list(self.L),
                list(self.R),
                depth_image,
                deepcopy(self.SCAN),
            )

    def limit_command(self, command):
        # 잘못된 반환값은 숨기지 않고 명확한 Python 오류로 표시한다.
        if not isinstance(command, Twist):
            raise TypeError(
                "decide_*() 함수는 "
                "geometry_msgs.msg.Twist를 return하거나 yield해야 합니다."
            )

        linear_x = float(command.linear.x)
        angular_z = float(command.angular.z)

        if not math.isfinite(linear_x):
            raise ValueError(
                "command.linear.x must be finite"
            )
        if not math.isfinite(angular_z):
            raise ValueError(
                "command.angular.z must be finite"
            )

        limited = Twist()
        limited.linear.x = min(
            max(linear_x, -self.MAX_LINEAR_MPS),
            self.MAX_LINEAR_MPS,
        )
        limited.angular.z = min(
            max(angular_z, -self.MAX_ANGULAR_RPS),
            self.MAX_ANGULAR_RPS,
        )
        return limited

    def publish_stop(self):
        with self.STATE_LOCK:
            if self.CMD_PUBLISHER is not None:
                self.CMD_PUBLISHER.publish(Twist())

    def cancel_rule_sequence(self):
        """이전 반복 명령과 실행 중인 결과를 무효화한다. next() 중 close하지 않는다."""
        with self.STATE_LOCK:
            if self.RULE_ITERATOR is not None:
                # 마지막 참조 해제가 학생 generator의 finally를 실행할 수 있다.
                # 웹/센서 callback이나 잠금 안에서는 정리하지 않고 판단 타이머로 넘긴다.
                self.RETIRED_RULE_ITERATORS.append(self.RULE_ITERATOR)
            self.RULE_ITERATOR = None
            self.CONTROL_GENERATION += 1

    def cancel_after_sensor_gap(self, name, received_at):
        # watchdog 사이에 데이터가 다시 도착해도 오래된 반복 기동을 이어가지 않는다.
        previous = self.SENSOR_TIMES[name]
        if (
            self.MODE in (name, "integrated")
            and previous is not None
            and not 0.0 <= received_at - previous <= self.SENSOR_TIMEOUT_SEC
        ):
            self.cancel_rule_sequence()

    def inputs_ready(self, now):
        """현재 미션에 필요한 입력이 모두 도착했고 최신인지 검사한다."""
        names = ("lane", "depth", "lidar") if self.MODE == "integrated" else (self.MODE,)
        return all(
            self.SENSOR_TIMES[name] is not None
            and 0.0 <= now - self.SENSOR_TIMES[name] <= self.SENSOR_TIMEOUT_SEC
            for name in names
        )

    def publish_decision_status(self, driving_enabled, reason):
        """실제 출력 상태가 바뀔 때만 웹에 전달한다."""
        with self.STATE_LOCK:
            status = (bool(driving_enabled), str(reason))
            if status == self.LAST_STATUS:
                return
            self.DECISION_STATUS_PUBLISHER.publish(String(data=json.dumps(
                {"driving_enabled": status[0], "reason": status[1]},
                ensure_ascii=False,
            )))
            self.LAST_STATUS = status

    def update_decision_status(self, now):
        with self.STATE_LOCK:
            if self.CMD_PUBLISHER is None:
                self.publish_decision_status(False, "실제 주행 출력이 비활성화되어 있습니다.")
            elif not self.DRIVING_ENABLED:
                self.publish_decision_status(False, self.STOP_REASON)
            elif not self.inputs_ready(now):
                self.publish_decision_status(
                    False, "필수 센서 데이터가 없거나 오래되어 정지했습니다."
                )
            else:
                self.publish_decision_status(True, "")

    def report_input_error(self, message):
        now = time.monotonic()
        if now - self.LAST_ERROR_TIME >= 1.0:
            self.LAST_ERROR_TIME = now
            self.get_logger().error(f"{message}\n{traceback.format_exc()}")

    def watchdog_callback(self):
        timed_out = False
        with self.STATE_LOCK:
            now = time.monotonic()
            if self.RULE_STARTED is not None and now - self.RULE_STARTED > self.RULE_TIMEOUT_SEC:
                self.DRIVING_ENABLED = False
                self.cancel_rule_sequence()
                self.STOP_REASON = (
                    "판단 함수 실행 시간이 초과되어 자동 정지했습니다. "
                    "무한 반복이면 노드를 재시작하세요."
                )
                timed_out = not self.RULE_TIMEOUT_REPORTED
                self.RULE_TIMEOUT_REPORTED = True
            if not self.DRIVING_ENABLED or not self.inputs_ready(now):
                self.cancel_rule_sequence()
                self.publish_stop()
            self.update_decision_status(now)
        if timed_out:
            self.get_logger().error(
                "Student rule exceeded rule_timeout_sec; motion paused. "
                "A rule containing an infinite loop requires a node restart."
            )

    def timer_callback(self):
        if self.CMD_PUBLISHER is None:
            return

        with self.STATE_LOCK:
            generation = self.CONTROL_GENERATION
            self.RULE_STARTED = time.monotonic()
            self.RULE_TIMEOUT_REPORTED = False
            retired = self.RETIRED_RULE_ITERATORS
            self.RETIRED_RULE_ITERATORS = []
        iterator = None
        try:
            # 취소된 generator의 finally도 잠금 밖에서 실행하고 watchdog로 감시한다.
            retired.clear()
            self.watchdog_callback()
            with self.STATE_LOCK:
                if (
                    generation != self.CONTROL_GENERATION
                    or not self.DRIVING_ENABLED
                    or not self.inputs_ready(time.monotonic())
                ):
                    self.cancel_rule_sequence()
                    self.publish_stop()
                    self.update_decision_status(time.monotonic())
                    return
                iterator = self.RULE_ITERATOR
            # 일반 return 함수는 매 주기 호출하고, yield 함수는 주기당 한 번 진행한다.
            # 이전 반복이 끝난 주기에도 최신 입력으로 즉시 새 판단을 시작한다.
            if iterator is not None:
                try:
                    command = next(iterator)
                except StopIteration:
                    iterator = None
            if iterator is None:
                with self.STATE_LOCK:
                    if (
                        generation != self.CONTROL_GENERATION
                        or not self.DRIVING_ENABLED
                        or not self.inputs_ready(time.monotonic())
                    ):
                        self.cancel_rule_sequence()
                        self.publish_stop()
                        self.update_decision_status(time.monotonic())
                        return
                    arguments = self.student_arguments()
                result = self.RULE_FUNCTION(*arguments)
                if isinstance(result, Iterator):
                    iterator = result
                    try:
                        command = next(iterator)
                    except StopIteration as error:
                        # 빈 반복자를 같은 주기에서 재호출하면 무한 반복이 될 수 있다.
                        raise ValueError("판단 함수는 Twist를 한 번 이상 yield해야 합니다.") from error
                else:
                    command = result
            limited = self.limit_command(command)
            # watchdog 타이머가 아직 실행되지 않은 직후의 시간 초과도 검사한다.
            self.watchdog_callback()
        except Exception as error:
            # traceback을 기록하되 센서/웹 제어 노드가 종료되지 않게 한다.
            with self.STATE_LOCK:
                if iterator is not None and iterator is not self.RULE_ITERATOR:
                    self.RETIRED_RULE_ITERATORS.append(iterator)
                self.DRIVING_ENABLED = False
                self.cancel_rule_sequence()
                self.STOP_REASON = f"판단 함수 오류로 자동 정지했습니다: {error}"
                self.publish_stop()
                self.update_decision_status(time.monotonic())
            self.report_input_error("Student rule failed; motion paused")
            return
        finally:
            with self.STATE_LOCK:
                self.RULE_STARTED = None

        # 정지/재시작과 발행을 같은 잠금으로 직렬화한다.
        with self.STATE_LOCK:
            if (
                not self.DRIVING_ENABLED
                or generation != self.CONTROL_GENERATION
                or not self.inputs_ready(time.monotonic())
            ):
                if iterator is not None and iterator is not self.RULE_ITERATOR:
                    self.RETIRED_RULE_ITERATORS.append(iterator)
                self.cancel_rule_sequence()
                self.publish_stop()
                return
            self.RULE_ITERATOR = iterator
            self.CMD_PUBLISHER.publish(limited)
            self.update_decision_status(time.monotonic())

    def destroy_node(self):
        # Ctrl+C와 정상 종료 시 마지막 명령은 정지다.
        with self.STATE_LOCK:
            self.DRIVING_ENABLED = False
            self.cancel_rule_sequence()
            self.STOP_REASON = "판단 노드가 종료되어 정지했습니다."
            self.publish_stop()
            self.update_decision_status(time.monotonic())
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)

    node = DecisionNode()
    executor = MultiThreadedExecutor(num_threads=3)
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.publish_stop()
        executor.remove_node(node)
        executor.shutdown()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
