from numbers import Integral
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np


# OpenCV는 BGR 순서로 색상을 지정한다.
VERTICAL_LINE_BGR = (0, 255, 255)      # 노란색
HORIZONTAL_LINE_BGR = (255, 246, 0)    # 청록색
V_POINT_BGR = (0, 0, 255)              # 빨간색
L_POINT_BGR = (130, 160, 0)            # 초록색
R_POINT_BGR = (227, 110, 0)            # 파란색


def validate_grid_parameters(
    width: int,
    height: int,
    rows: int,
    cols: int,
    roi_b: int,
    roi_t: int,
    ths1: int,
    ths2: int,
    ker_size: int,
) -> None:
    """격자 영상처리 설정값이 올바른지 검사한다."""
    values = (width, height, rows, cols, roi_b, roi_t, ths1, ths2, ker_size)
    if any(isinstance(value, bool) or not isinstance(value, Integral)
           for value in values):
        raise ValueError("영상 크기와 격자 설정값은 모두 정수여야 합니다.")

    if width <= 0 or height <= 0:
        raise ValueError(
            "processing_width와 processing_height는 양수여야 합니다."
        )

    if rows <= 0 or cols <= 0:
        raise ValueError("rows와 cols는 양수여야 합니다.")

    if not 0 <= roi_b < roi_t <= height:
        raise ValueError(
            "ROI는 0 <= roi_b < roi_t <= 영상 높이를 만족해야 합니다."
        )

    if ths1 < 0 or ths2 <= ths1:
        raise ValueError(
            "Canny 임곗값은 0 <= ths1 < ths2를 만족해야 합니다."
        )

    if ker_size <= 0 or ker_size % 2 == 0:
        raise ValueError("ker_size는 양의 홀수여야 합니다.")


def compute_grid_features(
    image_bgr: np.ndarray,
    rows: int,
    cols: int,
    roi_b: int,
    roi_t: int,
    ths1: int,
    ths2: int,
    ker_size: int,
    render_debug: bool = True,
) -> Tuple[Optional[np.ndarray], Dict[str, object]]:
    """
    RGB 영상에서 격자 기반 특징점 V, L, R을 계산한다.

    V:
        각 세로선에서 ROI 아래쪽부터 차선 경계까지의 거리.
        V[0]은 가장 왼쪽 세로선에 해당한다.

    L:
        각 가로선에서 영상 중심부터 왼쪽 차선 경계까지의 거리.
        L[0]은 가장 아래쪽 가로선에 해당한다.

    R:
        각 가로선에서 영상 중심부터 오른쪽 차선 경계까지의 거리.
        R[0]은 가장 아래쪽 가로선에 해당한다.

    특징점이 발견되지 않으면 각 방향의 no-hit 값을 저장한다.
    """
    if image_bgr.ndim != 3 or image_bgr.shape[2] != 3:
        raise ValueError("image_bgr은 3채널 BGR 영상이어야 합니다.")

    height, width = image_bgr.shape[:2]

    validate_grid_parameters(
        width,
        height,
        rows,
        cols,
        roi_b,
        roi_t,
        ths1,
        ths2,
        ker_size,
    )

    # 1. 회색조 변환
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)

    # 2. 가우시안 블러
    blurred = cv2.GaussianBlur(
        gray,
        (ker_size, ker_size),
        0,
    )

    # 3. 차선 경계 검출
    edges = cv2.Canny(
        blurred,
        ths1,
        ths2,
    )

    # roi_b와 roi_t는 영상 아래쪽을 0으로 하는 좌표이다.
    cv_top = height - roi_t
    cv_bottom = height - roi_b
    roi_height = cv_bottom - cv_top
    center_x = width // 2

    # 가로선은 아래쪽에서 위쪽 순서로 생성한다.
    horizontal_y: List[int] = []

    for index in range(rows):
        y_from_bottom = roi_b + round(
            (index + 1) * (roi_t - roi_b) / (rows + 1)
        )
        # 작은 영상/좁은 ROI에서도 반올림 결과가 ROI 밖으로 나가지 않는다.
        horizontal_y.append(
            min(cv_bottom - 1, max(cv_top, height - 1 - y_from_bottom))
        )

    # 세로선은 왼쪽에서 오른쪽 순서로 생성한다.
    vertical_x: List[int] = [
        min(width - 1, round((index + 1) * width / (cols + 1)))
        for index in range(cols)
    ]

    # L/R은 실제 거리와 겹치지 않는 같은 no-hit 값을 사용한다.
    # 640px 영상에서는 둘 다 321이며, 실제 R 거리는 0~319px이다.
    L_NO_HIT = center_x + 1
    R_NO_HIT = center_x + 1
    # V는 ROI 안에서 실제로 나올 수 있는 최댓값보다 1 크다.
    V_NO_HIT = roi_height

    L: List[int] = []
    R: List[int] = []

    # 각 가로선에서 영상 중심과 가장 가까운 좌우 경계를 찾는다.
    for y_position in horizontal_y:
        left_hits = np.flatnonzero(
            edges[y_position, : center_x + 1]
        )
        right_hits = np.flatnonzero(
            edges[y_position, center_x:]
        )

        if left_hits.size > 0:
            left_x = int(left_hits[-1])
            L.append(center_x - left_x)
        else:
            L.append(L_NO_HIT)

        if right_hits.size > 0:
            right_x_from_center = int(right_hits[0])
            R.append(right_x_from_center)
        else:
            R.append(R_NO_HIT)

    V: List[int] = []

    # 각 세로선에서 ROI 아래쪽과 가장 가까운 경계를 찾는다.
    for x_position in vertical_x:
        column_hits = np.flatnonzero(
            edges[cv_top:cv_bottom, x_position]
        )

        if column_hits.size > 0:
            hit_y = cv_top + int(column_hits[-1])
            distance_from_roi_bottom = (cv_bottom - 1) - hit_y
            V.append(distance_from_roi_bottom)
        else:
            V.append(V_NO_HIT)

    features: Dict[str, object] = {
        "V": V,
        "L": L,
        "R": R,
        "V_NO_HIT": V_NO_HIT,
        "L_NO_HIT": L_NO_HIT,
        "R_NO_HIT": R_NO_HIT,
    }

    # grid_node는 숫자만 발행하므로 불필요한 복사/그리기를 생략한다.
    if not render_debug:
        return None, features

    # 시각화용 영상
    debug_image = image_bgr.copy()

    roi_debug = debug_image[cv_top:cv_bottom]
    roi_edges = edges[cv_top:cv_bottom]
    roi_debug[roi_edges > 0] = (255, 255, 255)

    for x_position in vertical_x:
        cv2.line(
            debug_image,
            (x_position, cv_top),
            (x_position, cv_bottom - 1),
            VERTICAL_LINE_BGR,
            1,
        )

    for y_position in horizontal_y:
        cv2.line(
            debug_image,
            (0, y_position),
            (width - 1, y_position),
            HORIZONTAL_LINE_BGR,
            1,
        )

    # L, R 특징점 표시
    for index, y_position in enumerate(horizontal_y):
        if L[index] != L_NO_HIT:
            cv2.circle(
                debug_image,
                (center_x - L[index], y_position),
                5,
                L_POINT_BGR,
                -1,
            )

        if R[index] != R_NO_HIT:
            cv2.circle(
                debug_image,
                (center_x + R[index], y_position),
                5,
                R_POINT_BGR,
                -1,
            )

    # V 특징점 표시
    for index, x_position in enumerate(vertical_x):
        if V[index] != V_NO_HIT:
            cv2.circle(
                debug_image,
                (
                    x_position,
                    (cv_bottom - 1) - V[index],
                ),
                5,
                V_POINT_BGR,
                -1,
            )

    return debug_image, features
