import asyncio
import json
import math
import os
import queue
import tempfile
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np
import rclpy
from aiohttp import web
from ament_index_python.packages import get_package_share_directory
from cv_bridge import CvBridge
from rcl_interfaces.msg import ParameterType
from rcl_interfaces.srv import GetParameters
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
)
from sensor_msgs.msg import Image, LaserScan
from std_msgs.msg import Bool, String
from my_rule_based_learning.grid_core import (
    compute_grid_features,
    validate_grid_parameters,
)


STREAM_NAMES = ("rgb", "grid", "depth", "lidar")

# Keep per-frame metadata below common HTTP response-header limits.
MAX_DEPTH_ROIS = 16
ROI_WIDTH = 640
ROI_HEIGHT = 480
ROI_FIELDS = ("y1", "y2", "x1", "x2")


def default_roi_path():
    ros_home = Path(os.environ.get("ROS_HOME") or Path.home() / ".ros").expanduser()
    return ros_home / "my_rule_based_learning" / "depth_rois.json"


def empty_roi():
    return dict.fromkeys(ROI_FIELDS)


def validate_depth_rois(rois):
    """Inclusive UI coordinates; blank rows and an empty list are supported."""
    if not isinstance(rois, list) or len(rois) > MAX_DEPTH_ROIS:
        raise ValueError(f"Depth ROI 목록은 0~{MAX_DEPTH_ROIS}개여야 합니다.")
    validated = []
    for index, roi in enumerate(rois, start=1):
        if not isinstance(roi, dict):
            raise ValueError(f"ROI {index}: 좌표 객체가 필요합니다.")
        values = [roi.get(name) for name in ROI_FIELDS]
        if all(value is None for value in values):
            validated.append(empty_roi())
            continue
        if any(type(value) is not int for value in values):
            raise ValueError(f"ROI {index}: y1, y2, x1, x2를 정수로 모두 입력하세요.")
        y1, y2, x1, x2 = values
        if not (0 <= y1 <= y2 < ROI_HEIGHT and 0 <= x1 <= x2 < ROI_WIDTH):
            raise ValueError(f"ROI {index}: 0≤y1≤y2≤479, 0≤x1≤x2≤639여야 합니다.")
        validated.append(dict(zip(ROI_FIELDS, values)))
    return validated


def load_depth_rois(path):
    """A missing file means first use; malformed files are not overwritten."""
    try:
        with Path(path).open("r", encoding="utf-8") as stream:
            payload = json.load(stream)
    except FileNotFoundError:
        return [empty_roi()]
    if (not isinstance(payload, dict)
            or type(payload.get("version")) is not int or payload["version"] != 1
            or payload.get("width") != ROI_WIDTH or payload.get("height") != ROI_HEIGHT):
        raise ValueError("지원하지 않는 Depth ROI 저장 파일 형식입니다.")
    return validate_depth_rois(payload.get("rois"))


def save_depth_rois(path, rois):
    """Write beside the destination, flush, then replace atomically."""
    validated = validate_depth_rois(rois)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "width": ROI_WIDTH, "height": ROI_HEIGHT, "rois": validated}
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent,
            prefix=path.name + ".", suffix=".tmp", delete=False,
        ) as stream:
            temporary = Path(stream.name)
            json.dump(payload, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


@web.middleware
async def validate_api_json(request, handler):
    """잘못된 API 본문은 서버 오류 대신 입력 오류로 응답한다."""
    if request.method == "POST" and request.path.startswith("/api/"):
        try:
            payload = await request.json()
        except (ValueError, TypeError):
            return web.json_response({"ok": False, "error": "JSON object is required"}, status=400)
        if not isinstance(payload, dict):
            return web.json_response({"ok": False, "error": "JSON object is required"}, status=400)
    return await handler(request)


class VisNode(Node):
    def __init__(self) -> None:
        super().__init__("vis_node")

        self.declare_parameter(
            "rgb_topic",
            "/ascamera_hp60c/camera_publisher/rgb0/image",
        )
        self.declare_parameter(
            "depth_topic",
            "/ascamera_hp60c/camera_publisher/depth0/image_raw",
        )
        self.declare_parameter("scan_topic", "/scan")
        self.declare_parameter("driving_enabled_topic", "/driving_enabled")
        self.declare_parameter("decision_status_topic", "/decision_status")
        self.declare_parameter("web_host", "0.0.0.0")
        self.declare_parameter("web_port", 8080)
        self.declare_parameter("stream_fps", 25.0)
        self.declare_parameter("jpeg_quality", 80)
        self.declare_parameter("depth_display_max_mm", 4000)
        self.declare_parameter("depth_min_mm", 200.0)
        self.declare_parameter("depth_max_mm", 4000.0)
        self.declare_parameter("depth_invalid_value_mm", 0.0)
        self.declare_parameter("depth_roi_config_path", str(default_roi_path()))
        self.declare_parameter("lidar_display_max_mm", 1000)
        self.declare_parameter("lidar_heading_offset_deg", 180.0)

        self.rgb_topic = str(self.get_parameter("rgb_topic").value)
        self.depth_topic = str(self.get_parameter("depth_topic").value)
        self.scan_topic = str(self.get_parameter("scan_topic").value)
        self.driving_enabled_topic = str(
            self.get_parameter("driving_enabled_topic").value
        )
        self.web_host = str(self.get_parameter("web_host").value)
        self.web_port = int(self.get_parameter("web_port").value)
        self.stream_fps = float(self.get_parameter("stream_fps").value)
        self.jpeg_quality = int(self.get_parameter("jpeg_quality").value)
        self.depth_display_max_mm = int(
            self.get_parameter("depth_display_max_mm").value
        )
        self.depth_min_mm, self.depth_max_mm, self.depth_invalid_value_mm = (
            self.validate_depth_parameters(
                self.get_parameter("depth_min_mm").value,
                self.get_parameter("depth_max_mm").value,
                self.get_parameter("depth_invalid_value_mm").value,
            )
        )
        self.lidar_display_max_mm = int(
            self.get_parameter("lidar_display_max_mm").value
        )
        self.lidar_heading_offset_deg = float(
            self.get_parameter("lidar_heading_offset_deg").value
        )
        # 각도 구간은 기본적으로 모두 미설정(None)이다.
        self.lidar_zones = [
            {"start_deg": None, "end_deg": None} for _ in range(4)
        ]
        self.lidar_zone_stats = [None for _ in range(4)]
        roi_path = str(self.get_parameter("depth_roi_config_path").value).strip()
        if not roi_path:
            raise ValueError("depth_roi_config_path must not be empty")
        self.depth_roi_config_path = Path(roi_path).expanduser().resolve()
        self.depth_rois_revision = 0
        self.depth_roi_save_lock = threading.Lock()
        self.depth_roi_storage_error = ""
        try:
            self.depth_rois = load_depth_rois(self.depth_roi_config_path)
        except (OSError, ValueError) as error:
            self.depth_rois = [empty_roi()]
            self.depth_roi_storage_error = f"Depth ROI 불러오기 실패: {error}"
            self.get_logger().warning(self.depth_roi_storage_error)
        self.depth_roi_stats = [None for _ in self.depth_rois]

        if self.web_port < 1 or self.web_port > 65535:
            raise ValueError("web_port must be between 1 and 65535")
        if not math.isfinite(self.stream_fps) or not 0.0 < self.stream_fps <= 30.0:
            raise ValueError("stream_fps must be in the range 0 < fps <= 30")
        if self.jpeg_quality < 30 or self.jpeg_quality > 100:
            raise ValueError("jpeg_quality must be between 30 and 100")
        if self.depth_display_max_mm <= 0:
            raise ValueError("depth_display_max_mm must be positive")
        if not 100 <= self.lidar_display_max_mm <= 10000:
            raise ValueError(
                "lidar_display_max_mm must be between 100 and 10000"
            )
        if not -360.0 <= self.lidar_heading_offset_deg <= 360.0:
            raise ValueError(
                "lidar_heading_offset_deg must be between -360 and 360"
            )

        self.bridge = CvBridge()
        self.frame_lock = threading.Lock()
        self.status_lock = threading.Lock()
        self.frames: Dict[str, bytes] = {}
        self.frame_metadata: Dict[str, dict] = {}
        self.frame_versions: Dict[str, int] = {
            name: 0 for name in STREAM_NAMES
        }
        self.last_frame_time: Dict[str, float] = {
            name: 0.0 for name in STREAM_NAMES
        }
        self.source_lock = threading.Lock()
        self.latest_messages = {}
        self.source_versions = {name: 0 for name in ("rgb", "depth", "lidar")}
        self.render_event = threading.Event()
        self.render_stop_event = threading.Event()
        self.render_revision = 0
        self.paused = True
        self.decision_status = None
        self.instance_id = str(time.time_ns())

        # VIS_SELECTED_STREAM_OPTIMIZATION_V1
        # 화면 선택은 vis_node의 표시 연산만 제어한다.
        # grid_node와 decision_node의 ROS 데이터 처리는 영향을 받지 않는다.
        self.active_stream = "rgb"
        self.source_rx_time: Dict[str, float] = {
            name: 0.0 for name in STREAM_NAMES
        }

        self.last_error = self.depth_roi_storage_error
        self.last_error_log_time = 0.0
        # 실제 grid_node 설정이 도착하기 전에는 임의의 격자를 그리지 않는다.
        self.preview_grid_parameters = {}
        # 웹에서만 보여 주는 표시 전용 V/L/R.
        self.preview_features = {
            "V": [],
            "L": [],
            "R": [],
            "V_NO_HIT": 0,
            "L_NO_HIT": 0,
            "R_NO_HIT": 0,
        }
        self.grid_default_names = (
            "rows", "cols", "roi_b", "roi_t",
            "ths1", "ths2", "ker_size", "processing_width", "processing_height",
        )
        self.grid_defaults_loaded = False
        self.grid_defaults_future = None
        self.grid_defaults_requested_at = 0.0
        self.grid_defaults_refreshed_at = 0.0
        # grid_node의 실제 설정 캐시: 기본값 버튼은 이 값을 즉시 반환한다.
        self.grid_node_parameters = dict(self.preview_grid_parameters)

        self.control_queue: queue.Queue = queue.Queue()

        sensor_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            # 표시는 누락된 과거 프레임 재전송보다 최신 센서값을 우선한다.
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )
        state_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )

        self.create_subscription(
            Image,
            self.rgb_topic,
            self.rgb_callback,
            sensor_qos,
        )
        self.create_subscription(
            Image,
            self.depth_topic,
            self.depth_callback,
            sensor_qos,
        )
        self.create_subscription(
            LaserScan,
            self.scan_topic,
            self.scan_callback,
            sensor_qos,
        )

        self.driving_enabled_publisher = self.create_publisher(
            Bool,
            self.driving_enabled_topic,
            state_qos,
        )
        self.create_subscription(
            String,
            str(self.get_parameter("decision_status_topic").value),
            self.decision_status_callback,
            state_qos,
        )
        self.grid_defaults_client = self.create_client(
            GetParameters,
            "/grid_node/get_parameters",
        )
        self.create_timer(0.05, self.process_queued_requests)
        self.create_timer(0.2, self.request_initial_grid_defaults)

        self.publish_driving_enabled(False)
        for stream_name in STREAM_NAMES:
            placeholder = self.make_placeholder(stream_name.upper())
            self.store_frame(stream_name, placeholder)

        package_share = Path(
            get_package_share_directory("my_rule_based_learning")
        )
        self.index_path = package_share / "web" / "index.html"
        if not self.index_path.is_file():
            raise FileNotFoundError(f"Web UI not found: {self.index_path}")

        self.render_thread = threading.Thread(
            target=self.render_latest_frames,
            name="vis-render",
            daemon=True,
        )
        self.render_thread.start()
        self.web_stop_event = threading.Event()
        self.web_ready_event = threading.Event()
        self.web_start_error = None
        self.web_loop = asyncio.new_event_loop()
        self.web_runner: Optional[web.AppRunner] = None
        self.web_thread = threading.Thread(
            target=self.run_web_server,
            name="vis-web-server",
            daemon=True,
        )
        self.web_thread.start()
        if not self.web_ready_event.wait(timeout=5.0) or self.web_start_error:
            error = self.web_start_error or "Web server startup timed out"
            self.destroy_node()
            raise RuntimeError(error)

        self.get_logger().info(
            f"Visualization ready: http://<vehicle-ip>:{self.web_port} "
            f"(LiDAR max={self.lidar_display_max_mm} mm)"
        )

    def mark_source_received(self, *stream_names: str) -> None:
        """영상 처리 없이 센서의 마지막 수신 시각만 기록한다."""
        received_at = time.monotonic()
        with self.frame_lock:
            for stream_name in stream_names:
                self.source_rx_time[stream_name] = received_at

    def queue_sensor_message(self, source: str, message) -> None:
        """ROS 콜백은 참조만 교체한다. 느린 영상 처리 중에도 최신값을 받는다."""
        streams = ("rgb", "grid") if source == "rgb" else (source,)
        self.mark_source_received(*streams)
        with self.source_lock:
            self.source_versions[source] += 1
            self.latest_messages[source] = (self.source_versions[source], message)
        self.render_event.set()

    def rgb_callback(self, message: Image) -> None:
        self.queue_sensor_message("rgb", message)

    def depth_callback(self, message: Image) -> None:
        self.queue_sensor_message("depth", message)

    def scan_callback(self, message: LaserScan) -> None:
        self.queue_sensor_message("lidar", message)

    def render_latest_frames(self) -> None:
        """단일 작업자가 최신 메시지 하나만 처리하여 작업 대기열 누적을 막는다."""
        last_job = None
        next_frame_at = 0.0
        while not self.render_stop_event.is_set():
            self.render_event.wait()
            self.render_event.clear()
            if self.render_stop_event.wait(max(0.0, next_frame_at - time.monotonic())):
                break
            with self.status_lock:
                stream = self.active_stream
                revision = self.render_revision
                if stream == "grid" and not self.grid_defaults_loaded:
                    continue
            source = "rgb" if stream == "grid" else stream
            with self.source_lock:
                latest = self.latest_messages.get(source)
            if latest is None:
                continue
            version, message = latest
            job = (stream, revision, version)
            if job == last_job:
                continue
            last_job = job
            next_frame_at = time.monotonic() + 1.0 / self.stream_fps
            try:
                if source == "rgb":
                    self.process_rgb(message, stream, revision)
                elif source == "depth":
                    self.process_depth(message, revision)
                else:
                    self.process_scan(message, revision)
            except Exception as error:
                self.record_error(f"Preview worker: {error}")
            # 연산 도중 들어온 메시지를 확인하되 이미 처리한 프레임은 건너뛴다.
            self.render_event.set()

    def store_frame(
        self, stream_name: str, image: np.ndarray,
        metadata: Optional[dict] = None, revision: Optional[int] = None,
    ) -> None:
        success, encoded = cv2.imencode(
            ".jpg",
            image,
            [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality],
        )
        if not success:
            raise RuntimeError(f"JPEG encoding failed for {stream_name}")
        # JPEG와 같은 센서 메시지에서 계산한 수치를 하나의 스냅샷으로 저장한다.
        with self.status_lock:
            if revision is not None and (
                revision != self.render_revision or stream_name != self.active_stream
            ):
                return
            snapshot = dict(metadata or {})
            for name in ("preview_features", "depth_roi_stats", "lidar_zone_stats"):
                if name in snapshot:
                    setattr(self, name, snapshot[name])
            with self.frame_lock:
                self.frames[stream_name] = encoded.tobytes()
                self.frame_versions[stream_name] += 1
                self.frame_metadata[stream_name] = {
                    **snapshot, "stream": stream_name,
                    "version": self.frame_versions[stream_name],
                    "revision": self.render_revision,
                }
                self.last_frame_time[stream_name] = time.monotonic()

    @staticmethod
    def make_placeholder(title: str) -> np.ndarray:
        image = np.full((480, 640, 3), (19, 27, 43), dtype=np.uint8)
        cv2.putText(
            image,
            title,
            (32, 70),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.2,
            (226, 232, 240),
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            image,
            "Waiting for ROS 2 topic...",
            (32, 115),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (148, 163, 184),
            2,
            cv2.LINE_AA,
        )
        return image

    def process_rgb(self, message: Image, stream: str, revision: int) -> None:
        try:
            image = self.bridge.imgmsg_to_cv2(message, "bgr8")
            if stream == "rgb":
                if image.shape[:2] != (480, 640):
                    image = cv2.resize(image, (640, 480))
                self.store_frame("rgb", image, revision=revision)
            else:
                with self.status_lock:
                    if not self.grid_defaults_loaded:
                        return
                    preview = dict(self.preview_grid_parameters)
                width, height = preview["processing_width"], preview["processing_height"]
                if image.shape[:2] != (height, width):
                    image = cv2.resize(image, (width, height))
                preview_image, PREVIEW_FEATURES = compute_grid_features(
                    image_bgr=image,
                    rows=preview["rows"],
                    cols=preview["cols"],
                    roi_b=preview["roi_b"],
                    roi_t=preview["roi_t"],
                    ths1=preview["ths1"],
                    ths2=preview["ths2"],
                    ker_size=preview["ker_size"],
                )
                # 학생 화면에는 대문자 V/L/R로 표시한다.
                features = {
                    "V": list(PREVIEW_FEATURES["V"]),
                    "L": list(PREVIEW_FEATURES["L"]),
                    "R": list(PREVIEW_FEATURES["R"]),
                    "V_NO_HIT": int(PREVIEW_FEATURES["V_NO_HIT"]),
                    "L_NO_HIT": int(PREVIEW_FEATURES["L_NO_HIT"]),
                    "R_NO_HIT": int(PREVIEW_FEATURES["R_NO_HIT"]),
                }
                self.store_frame("grid", preview_image, {
                    "grid_preview": preview, "preview_features": features,
                }, revision)
        except Exception as error:
            self.record_error(f"RGB/grid preview: {error}")

    @staticmethod
    def validate_depth_parameters(minimum, maximum, invalid):
        values = tuple(float(value) for value in (minimum, maximum, invalid))
        limit = float(np.finfo(np.float32).max)
        if not all(math.isfinite(value) and abs(value) <= limit for value in values):
            raise ValueError("Depth parameters must be finite and fit float32")
        minimum, maximum, invalid = values
        if not 0.0 <= minimum < maximum:
            raise ValueError("depth_min_mm and depth_max_mm must satisfy 0 <= min < max")
        if invalid > 0.0:
            raise ValueError("depth_invalid_value_mm must be <= 0")
        converted = tuple(float(np.float32(value)) for value in values)
        if any(value != 0.0 and converted_value == 0.0
               for value, converted_value in zip(values, converted)):
            raise ValueError("Depth parameters must not underflow float32")
        if not converted[0] < converted[1]:
            raise ValueError("Depth range must remain distinct in float32")
        return converted

    def process_depth(self, message: Image, revision: int) -> None:
        try:
            depth = np.asarray(self.bridge.imgmsg_to_cv2(message, "passthrough"))
            if depth.ndim != 2 or depth.size == 0:
                raise ValueError("Depth input must be a nonempty 2D image")
            if message.encoding == "16UC1" and depth.dtype == np.uint16:
                depth_mm = depth.astype(np.float32)
            elif message.encoding == "32FC1" and depth.dtype == np.float32:
                depth_mm = depth.copy()
                with np.errstate(over="ignore", invalid="ignore"):
                    depth_mm *= np.float32(1000.0)
            else:
                raise ValueError("Depth input must be 16UC1/uint16 (mm) or 32FC1/float32 (m)")
            # A missing raw value has no known distance: it must not become far/clear.
            valid = (np.isfinite(depth_mm) & (depth_mm > 0.0)
                     & (depth_mm >= self.depth_min_mm))
            depth_mm[~valid] = self.depth_invalid_value_mm
            depth_mm[valid] = np.minimum(depth_mm[valid], self.depth_max_mm)
            if depth_mm.shape != (480, 640):
                depth_mm = cv2.resize(depth_mm, (640, 480), interpolation=cv2.INTER_NEAREST)
            valid = np.isfinite(depth_mm) & (depth_mm > 0.0)
            # 웹 영상 표시용 변환이다. 판단 함수나 ROI 통계로 밝기값을 전달하지 않는다.
            display_gray = np.zeros(depth_mm.shape, dtype=np.uint8)
            clipped = np.clip(depth_mm[valid].astype(np.float64), 0.0, self.depth_display_max_mm)
            scaled = np.floor(255.0 - clipped * 255.0 / self.depth_display_max_mm)
            display_gray[valid] = np.clip(scaled, 0.0, 255.0).astype(np.uint8)
            image = cv2.cvtColor(display_gray, cv2.COLOR_GRAY2BGR)

            with self.status_lock:
                rois = [dict(roi) for roi in self.depth_rois]
                roi_revision = self.depth_rois_revision

            roi_stats = []
            colors = ((0, 255, 255), (255, 160, 0))

            for index, roi in enumerate(rois):
                values = (roi["x1"], roi["y1"], roi["x2"], roi["y2"])
                if any(value is None for value in values):
                    roi_stats.append(None)
                    continue

                x1, y1, x2, y2 = (int(value) for value in values)
                roi_valid = valid[y1:y2 + 1, x1:x2 + 1]
                roi_depth = depth_mm[y1:y2 + 1, x1:x2 + 1][roi_valid]

                color = colors[index % len(colors)]
                cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
                cv2.putText(
                    image,
                    f"ROI {index + 1}",
                    (x1 + 4, max(18, y1 - 7)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    color,
                    2,
                    cv2.LINE_AA,
                )

                if roi_depth.size:
                    roi_stats.append(
                        {
                            "count": int(roi_depth.size),
                            "distance_min_mm": int(round(float(np.min(roi_depth)))),
                            "distance_mean_mm": int(round(float(np.mean(roi_depth, dtype=np.float64)))),
                            "distance_max_mm": int(round(float(np.max(roi_depth)))),
                        }
                    )
                else:
                    roi_stats.append({
                        "count": 0,
                        "distance_min_mm": self.depth_invalid_value_mm,
                        "distance_mean_mm": self.depth_invalid_value_mm,
                        "distance_max_mm": self.depth_invalid_value_mm,
                    })

            self.store_frame("depth", image, {
                "depth_rois": rois, "depth_roi_stats": roi_stats,
                "depth_rois_revision": roi_revision,
            }, revision)
        except Exception as error:
            self.record_error(f"Depth: {error}")

    def process_scan(self, message: LaserScan, revision: int) -> None:
        try:
            with self.status_lock:
                display_max_mm = self.lidar_display_max_mm
                heading_offset_deg = self.lidar_heading_offset_deg
                zones = [dict(zone) for zone in self.lidar_zones]
            image, zone_stats = self.render_lidar(
                message, display_max_mm, zones, heading_offset_deg
            )
            self.store_frame("lidar", image, {
                "lidar_display_max_mm": display_max_mm,
                "lidar_zones": zones, "lidar_zone_stats": zone_stats,
            }, revision)
        except Exception as error:
            self.record_error(f"LiDAR: {error}")

    @staticmethod
    def normalize_angle_deg(angle_deg: float) -> float:
        """각도를 -180° 이상 +180° 미만 범위로 정규화한다."""
        return (angle_deg + 180.0) % 360.0 - 180.0

    @staticmethod
    def scan_angle_to_lidar_deg(
        scan_angle_rad: float, heading_offset_deg: float
    ) -> float:
        """장착 방향을 보정한 /scan 각도를 웹의 후방 0° 좌표로 바꾼다."""
        vehicle_angle_deg = math.degrees(scan_angle_rad) + heading_offset_deg
        # 전방 ±180°, 오른쪽 -90°, 후방 0°, 왼쪽 +90°.
        # 장착 방향 보정과 화면 좌표 규약을 분리해 실제 점 위치를 유지한다.
        return VisNode.normalize_angle_deg(180.0 - vehicle_angle_deg)

    @staticmethod
    def lidar_plot_point(
        angle_deg: float, radius: float, center_x: int, center_y: int
    ) -> tuple[int, int]:
        """웹의 LiDAR 각도를 전방이 위쪽인 영상 좌표로 변환한다."""
        radians = math.radians(angle_deg)
        return (
            round(center_x - math.sin(radians) * radius),
            round(center_y + math.cos(radians) * radius),
        )

    @staticmethod
    def zone_midpoint_deg(start_deg: int, end_deg: int) -> float:
        """두 경계각 사이의 짧은 구간 중앙각을 계산한다."""
        raw_difference = float(end_deg - start_deg)

        # -180°와 +180°를 지정한 경우는 전체 범위로 취급한다.
        if abs(raw_difference) >= 359.999:
            return 0.0

        # 정확히 반원일 때는 입력 숫자 구간의 방향을 보존한다.
        # -180..0은 오른쪽, 0..180은 왼쪽이다.
        signed_difference = raw_difference if abs(raw_difference) == 180.0 else (
            (raw_difference + 180.0) % 360.0
        ) - 180.0

        return VisNode.normalize_angle_deg(
            float(start_deg) + signed_difference / 2.0
        )

    @staticmethod
    def angle_in_zone(angle_deg: float, start_deg: int, end_deg: int) -> bool:
        """웹 좌표에서 입력한 두 각도 사이의 짧은 구간인지 검사한다."""
        raw_difference = float(end_deg - start_deg)

        # 전체 -180°~+180° 범위
        if abs(raw_difference) >= 359.999:
            return True

        signed_difference = raw_difference if abs(raw_difference) == 180.0 else (
            (raw_difference + 180.0) % 360.0
        ) - 180.0

        midpoint = VisNode.normalize_angle_deg(
            float(start_deg) + signed_difference / 2.0
        )
        half_width = abs(signed_difference) / 2.0

        distance_from_midpoint = abs(
            VisNode.normalize_angle_deg(angle_deg - midpoint)
        )

        return distance_from_midpoint <= half_width + 1.0e-6

    @staticmethod
    def render_lidar(
        message: LaserScan,
        display_max_mm: int,
        zones: List[dict],
        heading_offset_deg: float,
    ) -> tuple[np.ndarray, List[Optional[dict]]]:
        width = 640
        height = 480
        center_x = width // 2
        center_y = height // 2
        plot_radius = 205
        image = np.zeros((height, width, 3), dtype=np.uint8)

        # 입력 구간, 통계, 점과 경계선에 같은 후방 0° 좌표계를 사용한다.
        direction_labels = (
            ("-180 / 180 FRONT", center_x, 18),
            ("0 REAR", center_x, height - 9),
            ("+90 LEFT", 55, center_y + 5),
            ("-90 RIGHT", width - 57, center_y + 5),
        )
        for label, label_center_x, label_y in direction_labels:
            (text_width, _), _ = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.43, 1
            )
            cv2.putText(
                image,
                label,
                (label_center_x - text_width // 2, label_y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.43,
                (178, 178, 184),
                1,
                cv2.LINE_AA,
            )

        # 3개의 동심원 거리선. 각 값은 현재 최대 표시거리 기준 mm 값이다.
        ring_color = (76, 76, 80)
        for index in range(1, 4):
            fraction = index / 3.0
            radius = round(plot_radius * fraction)
            distance_mm = round(display_max_mm * fraction)
            cv2.circle(
                image, (center_x, center_y), radius, ring_color, 2, cv2.LINE_AA
            )
            # 거리값은 가장 바깥 동심원에만 표시한다.
            if index == 3:
                label_y = max(18, center_y - radius + 18)
                cv2.putText(
                    image,
                    f"{distance_mm} mm",
                    (center_x + 8, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.43,
                    (178, 178, 184),
                    1,
                    cv2.LINE_AA,
                )

        # 시작과 끝을 모두 입력한 구간만 가는 청록색 경계선으로 표시한다.
        valid_zones = []
        for index, zone in enumerate(zones):
            start_deg = zone.get("start_deg")
            end_deg = zone.get("end_deg")
            if isinstance(start_deg, int) and isinstance(end_deg, int):
                valid_zones.append((index, start_deg, end_deg))
                for angle_deg in (start_deg, end_deg):
                    edge_x, edge_y = VisNode.lidar_plot_point(
                        angle_deg, plot_radius, center_x, center_y
                    )
                    cv2.line(
                        image,
                        (center_x, center_y),
                        (edge_x, edge_y),
                        (86, 150, 154),
                        1,
                        cv2.LINE_AA,
                    )
                # 구간 이름은 두 경계 사이의 짧은 구간 중앙에 표시한다.
                midpoint_deg = VisNode.zone_midpoint_deg(
                    start_deg,
                    end_deg,
                )
                # 바깥쪽 원 안에 배치해 영상 밖으로 잘리지 않게 한다.
                label_radius = plot_radius - 18
                label_center_x, label_center_y = VisNode.lidar_plot_point(
                    midpoint_deg, label_radius, center_x, center_y
                )

                label = f"Z{index + 1}"
                (text_width, text_height), _ = cv2.getTextSize(
                    label,
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.43,
                    1,
                )

                text_x = max(
                    4,
                    min(
                        width - text_width - 4,
                        label_center_x - text_width // 2,
                    ),
                )
                text_y = max(
                    text_height + 4,
                    min(
                        height - 4,
                        label_center_y + text_height // 2,
                    ),
                )

                cv2.putText(
                    image,
                    label,
                    (text_x, text_y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.43,
                    (124, 230, 232),
                    1,
                    cv2.LINE_AA,
                )

        max_m = display_max_mm / 1000.0
        scale = plot_radius / max_m
        zone_values = [[] for _ in range(4)]
        angle = message.angle_min

        for distance in message.ranges:
            is_valid = (
                math.isfinite(distance)
                and message.range_min <= distance <= message.range_max
            )
            if is_valid:
                angle_deg = VisNode.scan_angle_to_lidar_deg(
                    angle, heading_offset_deg
                )
                distance_mm = distance * 1000.0

                # 통계는 표시거리와 무관하게 센서 유효 범위의 모든 값을 쓴다.
                for index, start_deg, end_deg in valid_zones:
                    if VisNode.angle_in_zone(angle_deg, start_deg, end_deg):
                        zone_values[index].append(distance_mm)

                if distance <= max_m:
                    pixel_x, pixel_y = VisNode.lidar_plot_point(
                        angle_deg, distance * scale, center_x, center_y
                    )
                    if 0 <= pixel_x < width and 0 <= pixel_y < height:
                        cv2.circle(
                            image,
                            (pixel_x, pixel_y),
                            3,
                            (255, 245, 65),  # BGR: 밝은 청록색
                            -1,
                            cv2.LINE_AA,
                        )
            angle += message.angle_increment

        # 중앙 차량: 위쪽이 전방인 작은 두 톤 빨간 그래픽.
        tip = (center_x, center_y - 27)
        join = (center_x, center_y + 5)
        base_y = center_y + 20
        cv2.fillConvexPoly(
            image,
            np.array([tip, join, (center_x - 17, base_y)], dtype=np.int32),
            (82, 82, 255),
        )
        cv2.fillConvexPoly(
            image,
            np.array([tip, (center_x + 17, base_y), join], dtype=np.int32),
            (30, 32, 205),
        )

        zone_stats: List[Optional[dict]] = []
        for values in zone_values:
            if values:
                array = np.asarray(values, dtype=np.float32)
                zone_stats.append(
                    {
                        "count": int(array.size),
                        "mean_mm": int(round(float(np.mean(array)))),
                        "median_mm": int(round(float(np.median(array)))),
                        "min_mm": int(round(float(np.min(array)))),
                        "max_mm": int(round(float(np.max(array)))),
                    }
                )
            else:
                zone_stats.append(None)

        return image, zone_stats

    def record_error(self, text: str) -> None:
        now = time.monotonic()
        with self.status_lock:
            should_log = text != self.last_error or now - self.last_error_log_time >= 2.0
            self.last_error = text
            if should_log:
                self.last_error_log_time = now
        if should_log:
            self.get_logger().error(text)

    def publish_driving_enabled(self, enabled: bool) -> None:
        message = Bool()
        message.data = bool(enabled)
        self.driving_enabled_publisher.publish(message)

    def decision_status_callback(self, message: String) -> None:
        try:
            status = json.loads(message.data)
            if (not isinstance(status, dict)
                    or type(status.get("driving_enabled")) is not bool
                    or not isinstance(status.get("reason", ""), str)):
                raise ValueError("Invalid decision status")
            with self.status_lock:
                self.decision_status = {
                    "driving_enabled": status["driving_enabled"],
                    "reason": status.get("reason", ""),
                }
        except (TypeError, ValueError) as error:
            self.record_error(f"Decision status: {error}")

    def process_queued_requests(self) -> None:
        while True:
            try:
                item = self.control_queue.get_nowait()
            except queue.Empty:
                break

            if time.monotonic() > item["deadline"]:
                item["result"] = {"ok": False, "error": "ROS control timeout"}
                item["event"].set()
                continue
            action = item["action"]
            try:
                self.publish_driving_enabled(action == "start")
                with self.status_lock:
                    self.paused = action == "pause"
                item["result"] = {"ok": True, "paused": action == "pause"}
            except Exception as error:
                self.record_error(f"Driving control: {error}")
                item["result"] = {"ok": False, "error": str(error)}
            finally:
                item["event"].set()

    def request_initial_grid_defaults(self) -> None:
        """vis_node 시작 시 grid_node 설정을 미리보기 기본값으로 읽는다."""
        now = time.monotonic()
        if self.grid_defaults_future is not None:
            if now - self.grid_defaults_requested_at > 2.0:
                expired = self.grid_defaults_future
                self.grid_defaults_future = None
                self.grid_defaults_client.remove_pending_request(expired)
                expired.cancel()
            else:
                return
        if self.grid_defaults_loaded and now - self.grid_defaults_refreshed_at < 1.0:
            return
        if not self.grid_defaults_client.service_is_ready():
            return

        request = GetParameters.Request()
        request.names = list(self.grid_default_names)
        self.grid_defaults_requested_at = now
        self.grid_defaults_future = self.grid_defaults_client.call_async(request)
        self.grid_defaults_future.add_done_callback(
            self.initial_grid_defaults_response
        )

    def initial_grid_defaults_response(self, future) -> None:
        if future is not self.grid_defaults_future:
            return
        self.grid_defaults_future = None
        try:
            response = future.result()
            if len(response.values) != len(self.grid_default_names):
                raise RuntimeError("grid_node returned incomplete parameters")
            if any(value.type != ParameterType.PARAMETER_INTEGER for value in response.values):
                raise RuntimeError("grid_node parameters must all be integers")

            values = {
                name: int(value.integer_value)
                for name, value in zip(self.grid_default_names, response.values)
            }
            error = self.validate_grid_request(values)
            if error:
                raise RuntimeError(error)

            with self.status_lock:
                # 실제 grid_node 설정은 계속 캐시한다.
                self.grid_node_parameters = dict(values)
                self.grid_defaults_refreshed_at = time.monotonic()

                # 시작 시 한 번만 현재 실제 설정을 미리보기 기본값으로 사용한다.
                first_load = not self.grid_defaults_loaded
                if first_load:
                    self.preview_grid_parameters = dict(values)
                    self.grid_defaults_loaded = True
                    self.render_revision += 1

            if first_load:
                self.render_event.set()
                self.get_logger().info(
                    "Preview defaults loaded from grid_node: "
                    f"rows={values['rows']}, cols={values['cols']}, "
                    f"ROI={values['roi_b']}..{values['roi_t']}"
                )
        except Exception as error:
            self.get_logger().warn(
                f"Waiting for grid_node defaults: {error}"
            )

    def get_status(self) -> dict:
        now = time.monotonic()
        with self.status_lock:
            status = {
                "instance_id": self.instance_id,
                "paused": self.paused,
                "decision_status": dict(self.decision_status) if self.decision_status else None,
                "active_stream": self.active_stream,
                "lidar_display_max_mm": self.lidar_display_max_mm,
                "lidar_zones": [dict(zone) for zone in self.lidar_zones],
                "lidar_zone_stats": [
                    dict(stat) if stat is not None else None
                    for stat in self.lidar_zone_stats
                ],
                "depth_rois": [dict(roi) for roi in self.depth_rois],
                "depth_rois_revision": self.depth_rois_revision,
                "max_depth_rois": MAX_DEPTH_ROIS,
                "depth_display_max_mm": self.depth_display_max_mm,
                "depth_min_mm": self.depth_min_mm,
                "depth_max_mm": self.depth_max_mm,
                "depth_invalid_value_mm": self.depth_invalid_value_mm,
                "depth_roi_stats": [
                    dict(stat) if stat is not None else None
                    for stat in self.depth_roi_stats
                ],
                "grid_preview": dict(self.preview_grid_parameters),
                "preview_features": {
                    name: list(value) if isinstance(value, list) else value
                    for name, value in self.preview_features.items()
                },
                "grid_defaults_loaded": self.grid_defaults_loaded,
                "last_error": self.last_error,
            }
        with self.frame_lock:
            status["sources"] = {
                name: {
                    "online": self.source_rx_time[name] > 0.0
                    and now - self.source_rx_time[name] < 2.0,
                    "age_seconds": (
                        round(now - self.source_rx_time[name], 2)
                        if self.source_rx_time[name] > 0.0
                        else None
                    ),
                    "output_age_seconds": (
                        round(now - self.last_frame_time[name], 2)
                        if self.last_frame_time[name] > 0.0 else None
                    ),
                }
                for name in STREAM_NAMES
            }
        return status

    def run_web_server(self) -> None:
        asyncio.set_event_loop(self.web_loop)
        try:
            self.web_loop.run_until_complete(self.start_web_server())
            self.web_ready_event.set()
            if not self.web_stop_event.is_set():
                self.web_loop.run_forever()
        except Exception as error:
            self.web_start_error = str(error)
            self.record_error(f"Web server: {error}")
        finally:
            try:
                if self.web_runner is not None:
                    self.web_loop.run_until_complete(self.web_runner.cleanup())
            finally:
                self.web_loop.close()
                # 시작 실패는 정리를 마친 뒤 알린다. 생성자와 cleanup의 경합 방지.
                self.web_ready_event.set()

    async def start_web_server(self) -> None:
        application = web.Application(
            client_max_size=1024 * 1024, middlewares=[validate_api_json],
        )
        application.router.add_get("/", self.handle_index)
        application.router.add_get("/health", self.handle_health)
        application.router.add_get("/api/status", self.handle_status)
        application.router.add_post("/api/control", self.handle_control)
        application.router.add_post("/api/grid", self.handle_grid)
        application.router.add_get("/api/grid/defaults", self.handle_grid_defaults)
        application.router.add_post("/api/lidar", self.handle_lidar)
        application.router.add_post("/api/depth", self.handle_depth)
        application.router.add_post("/api/view", self.handle_view)
        application.router.add_get(
            "/stream/active", self.handle_active_stream
        )
        application.router.add_get(
            "/frame/active.jpg", self.handle_active_frame
        )
        application.router.add_get("/stream/{name}", self.handle_stream)

        self.web_runner = web.AppRunner(application, shutdown_timeout=1.0)
        await self.web_runner.setup()
        site = web.TCPSite(
            self.web_runner,
            host=self.web_host,
            port=self.web_port,
        )
        await site.start()

    async def handle_index(self, _request: web.Request) -> web.StreamResponse:
        response = web.FileResponse(self.index_path)
        response.headers["Cache-Control"] = (
            "no-store, no-cache, must-revalidate, max-age=0"
        )
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

    async def handle_health(self, _request: web.Request) -> web.Response:
        return web.json_response({"ok": True})

    async def handle_status(self, _request: web.Request) -> web.Response:
        return web.json_response(self.get_status(), headers={"Cache-Control": "no-store"})

    async def handle_view(self, request: web.Request) -> web.Response:
        """Update the selected preview without accepting an invalid state."""
        try:
            payload = await request.json()
        except Exception:
            return web.json_response(
                {"ok": False, "error": "JSON body is required"},
                status=400,
            )

        # stream: 현재 형식
        # active_stream: 이전 웹 페이지 캐시와의 호환
        requested = payload.get("stream")
        if requested is None:
            requested = payload.get("active_stream")

        allowed = {"rgb", "grid", "depth", "lidar"}

        with self.status_lock:
            current = self.active_stream

        if not isinstance(requested, str) or requested not in allowed:
            return web.json_response(
                {
                    "ok": False,
                    "error": "stream must be rgb, grid, depth, or lidar",
                    "active_stream": current,
                },
                status=400,
            )

        with self.status_lock:
            if self.active_stream != requested:
                self.active_stream = requested
                self.render_revision += 1
        self.render_event.set()

        return web.json_response(
            {"ok": True, "active_stream": requested}
        )

    async def handle_active_frame(
        self,
        request: web.Request,
    ) -> web.Response:
        """Return one current JPEG frame and immediately close the request."""
        allowed = {"rgb", "grid", "depth", "lidar"}

        with self.status_lock:
            stream_name = self.active_stream
            revision = self.render_revision
            with self.frame_lock:
                jpeg = self.frames.get(stream_name)
                version = self.frame_versions.get(stream_name, 0)
                metadata = self.frame_metadata.get(stream_name, {})
        if request.query.get("stream", stream_name) != stream_name:
            return web.Response(status=409, headers={"Cache-Control": "no-store"})

        if stream_name not in allowed:
            return web.Response(
                status=503,
                text="No valid stream selected",
                headers={"Cache-Control": "no-store"},
            )

        # 다른 화면/설정에서 남아 있던 캐시는 새 프레임으로 보내지 않는다.
        if (metadata.get("revision") != revision
                or request.query.get("after") == str(version)):
            return web.Response(status=204, headers={"Cache-Control": "no-store"})

        if jpeg is None:
            return web.Response(
                status=503,
                text="Frame is not ready",
                headers={"Cache-Control": "no-store"},
            )

        return web.Response(
            body=jpeg,
            content_type="image/jpeg",
            headers={
                "Cache-Control": "no-store, no-cache, must-revalidate",
                "Pragma": "no-cache",
                "X-Stream-Name": stream_name,
                "X-Frame-Version": str(version),
                "X-Frame-Metadata": json.dumps(metadata, ensure_ascii=True, separators=(",", ":")),
            },
        )

    async def handle_active_stream(
        self,
        request: web.Request,
    ) -> web.StreamResponse:
        """연결을 유지하며 현재 선택된 화면만 전송한다."""
        # SINGLE_ACTIVE_MJPEG_STREAM_V4
        response = web.StreamResponse(
            status=200,
            headers={
                "Content-Type": (
                    "multipart/x-mixed-replace; boundary=frame"
                ),
                "Cache-Control": (
                    "no-store, no-cache, must-revalidate"
                ),
                "Pragma": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )
        await response.prepare(request)

        last_stream = None
        last_version = -1

        try:
            while not self.web_stop_event.is_set():
                with self.status_lock:
                    stream_name = self.active_stream

                if stream_name not in STREAM_NAMES:
                    await asyncio.sleep(0.05)
                    continue

                with self.frame_lock:
                    version = self.frame_versions[stream_name]
                    jpeg = self.frames.get(stream_name)

                if stream_name != last_stream:
                    last_stream = stream_name
                    last_version = -1

                if jpeg is not None and version != last_version:
                    await asyncio.wait_for(response.write(
                        b"--frame\r\n"
                        b"Content-Type: image/jpeg\r\n"
                        + f"Content-Length: {len(jpeg)}\r\n\r\n".encode()
                        + jpeg
                        + b"\r\n"
                    ), timeout=1.0)
                    last_version = version

                await asyncio.sleep(0.02)

        except (
            ConnectionResetError,
            BrokenPipeError,
            asyncio.CancelledError,
            asyncio.TimeoutError,
        ):
            response.force_close()

        return response

    async def handle_stream(self, request: web.Request) -> web.StreamResponse:
        stream_name = request.match_info["name"]
        if stream_name not in STREAM_NAMES:
            raise web.HTTPNotFound(text="Unknown stream")

        response = web.StreamResponse(
            status=200,
            headers={
                "Content-Type": "multipart/x-mixed-replace; boundary=frame",
                "Cache-Control": "no-store, no-cache, must-revalidate",
                "Pragma": "no-cache",
            },
        )
        await response.prepare(request)
        last_version = -1
        try:
            while not self.web_stop_event.is_set():
                with self.frame_lock:
                    version = self.frame_versions[stream_name]
                    jpeg = self.frames.get(stream_name)
                if jpeg is not None and version != last_version:
                    await asyncio.wait_for(response.write(
                        b"--frame\r\n"
                        b"Content-Type: image/jpeg\r\n"
                        + f"Content-Length: {len(jpeg)}\r\n\r\n".encode()
                        + jpeg
                        + b"\r\n"
                    ), timeout=1.0)
                    last_version = version
                await asyncio.sleep(0.04)
        except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError, asyncio.TimeoutError):
            response.force_close()
        return response

    async def handle_control(self, request: web.Request) -> web.Response:
        payload = await request.json()
        action = payload.get("action")
        if not isinstance(action, str) or action not in {"pause", "start"}:
            return web.json_response(
                {"ok": False, "error": "action must be pause or start"},
                status=400,
            )

        item = {
            "action": action,
            "event": threading.Event(),
            "result": None,
            "deadline": time.monotonic() + 1.0,
        }
        self.control_queue.put(item)
        completed = await asyncio.to_thread(item["event"].wait, 1.0)
        if not completed:
            return web.json_response(
                {"ok": False, "error": "ROS control timeout"},
                status=504,
            )
        return web.json_response(item["result"])

    async def handle_grid_defaults(self, _request: web.Request) -> web.Response:
        """최근 GetParameters 응답을 즉시 반환한다."""
        with self.status_lock:
            if not self.grid_defaults_loaded:
                return web.json_response(
                    {
                        "ok": False,
                        "error": "grid_node 설정을 아직 읽는 중입니다.",
                    },
                    status=503,
                )
            values = dict(self.grid_node_parameters)
        return web.json_response(
            {"ok": True, "parameters": values}, headers={"Cache-Control": "no-store"}
        )

    async def handle_grid(self, request: web.Request) -> web.Response:
        """웹/우분투 화면의 표시 전용 격자만 바꾼다."""
        payload = await request.json()
        with self.status_lock:
            if not self.grid_defaults_loaded:
                return web.json_response(
                    {"ok": False, "error": "grid_node 설정을 아직 읽는 중입니다."}, status=503,
                )
            parameters = dict(self.preview_grid_parameters)
        required = (
            "rows", "cols", "roi_b", "roi_t",
            "ths1", "ths2", "ker_size",
        )
        if any(type(payload.get(name)) is not int for name in required):
            return web.json_response(
                {"ok": False, "error": "All grid values must be integers"},
                status=400,
            )
        parameters.update({name: int(payload[name]) for name in required})
        # 기본값 버튼은 실제 노드의 해상도 변경도 함께 복원한다.
        for name in ("processing_width", "processing_height"):
            if name in payload:
                if type(payload[name]) is not int:
                    return web.json_response({"ok": False, "error": f"{name} must be an integer"}, status=400)
                parameters[name] = payload[name]
        error = self.validate_grid_request(parameters)
        if error:
            return web.json_response(
                {"ok": False, "error": error},
                status=400,
            )
        with self.status_lock:
            self.preview_grid_parameters = dict(parameters)
            self.render_revision += 1
        self.render_event.set()
        return web.json_response(
            {
                "ok": True,
                "preview": dict(parameters),
                "message": "Preview only; grid_node was not changed.",
            }
        )

    @staticmethod
    def validate_grid_request(parameters: dict) -> str:
        try:
            validate_grid_parameters(
                parameters["processing_width"], parameters["processing_height"],
                parameters["rows"], parameters["cols"],
                parameters["roi_b"], parameters["roi_t"],
                parameters["ths1"], parameters["ths2"], parameters["ker_size"],
            )
        except (KeyError, TypeError, ValueError) as error:
            return str(error)
        return ""

    def apply_depth_rois(self, rois):
        """저장 성공 후에만 적용한다. 저장 중에도 영상 렌더링은 계속된다."""
        with self.depth_roi_save_lock:
            save_depth_rois(self.depth_roi_config_path, rois)
            with self.status_lock:
                self.depth_rois = [dict(roi) for roi in rois]
                self.depth_roi_stats = [None for _ in rois]
                self.depth_rois_revision += 1
                self.render_revision += 1
                if self.last_error == self.depth_roi_storage_error:
                    self.last_error = ""
                self.depth_roi_storage_error = ""
                result = {
                    "ok": True, "saved": True,
                    "rois": [dict(roi) for roi in rois],
                    "depth_rois": [dict(roi) for roi in rois],
                    "depth_rois_revision": self.depth_rois_revision,
                }
            self.render_event.set()
            return result

    async def handle_depth(self, request: web.Request) -> web.Response:
        """0~16개의 표시용 ROI를 검증하고 원자적으로 저장·적용한다."""
        payload = await request.json()
        try:
            rois = validate_depth_rois(payload.get("rois"))
        except ValueError as error:
            return web.json_response({"ok": False, "error": str(error)}, status=400)
        try:
            # 디스크 쓰기는 웹 이벤트 루프와 렌더 상태 잠금 밖에서 실행한다.
            result = await asyncio.to_thread(self.apply_depth_rois, rois)
        except OSError as error:
            text = f"Depth ROI 저장 실패: {error}"
            with self.status_lock:
                self.depth_roi_storage_error = text
            self.record_error(text)
            return web.json_response({
                "ok": False,
                "error": "Depth ROI를 저장하지 못했습니다. 저장 경로와 쓰기 권한을 확인하세요.",
            }, status=500)
        return web.json_response(result)

    async def handle_lidar(self, request: web.Request) -> web.Response:
        # LIDAR_PARTIAL_UPDATE_V1
        # 최대 거리와 각도 구간을 각각 독립적으로 변경할 수 있다.
        payload = await request.json()

        has_range = "lidar_display_max_mm" in payload
        has_zones = "zones" in payload

        if not has_range and not has_zones:
            return web.json_response(
                {
                    "ok": False,
                    "error": "Enter lidar_display_max_mm or zones",
                },
                status=400,
            )

        with self.status_lock:
            current_value = int(self.lidar_display_max_mm)
            current_zones = [dict(zone) for zone in self.lidar_zones]

        value = payload.get("lidar_display_max_mm", current_value)

        if type(value) is not int:
            return web.json_response(
                {"ok": False, "error": "LiDAR range must be an integer"},
                status=400,
            )

        if not 100 <= value <= 10000:
            return web.json_response(
                {
                    "ok": False,
                    "error": "LiDAR range must be between 100 and 10000 mm",
                },
                status=400,
            )

        zones = payload.get("zones", current_zones)

        if not isinstance(zones, list) or len(zones) != 4:
            return web.json_response(
                {
                    "ok": False,
                    "error": "Exactly four LiDAR zones are required",
                },
                status=400,
            )

        validated_zones = []

        for index, zone in enumerate(zones):
            if not isinstance(zone, dict):
                return web.json_response(
                    {
                        "ok": False,
                        "error": f"Zone {index + 1} is invalid",
                    },
                    status=400,
                )

            start_deg = zone.get("start_deg")
            end_deg = zone.get("end_deg")

            if start_deg is None and end_deg is None:
                validated_zones.append(
                    {"start_deg": None, "end_deg": None}
                )
                continue

            if (
                type(start_deg) is not int
                or type(end_deg) is not int
                or not -180 <= start_deg <= 180
                or not -180 <= end_deg <= 180
            ):
                return web.json_response(
                    {
                        "ok": False,
                        "error": (
                            f"Zone {index + 1}: enter both start/end angles "
                            "as integers from -180 to 180"
                        ),
                    },
                    status=400,
                )

            validated_zones.append(
                {
                    "start_deg": start_deg,
                    "end_deg": end_deg,
                }
            )

        with self.status_lock:
            self.lidar_display_max_mm = value
            self.lidar_zones = validated_zones

            if has_range or has_zones:
                self.lidar_zone_stats = [None for _ in range(4)]
                self.render_revision += 1
        self.render_event.set()

        return web.json_response(
            {
                "ok": True,
                "lidar_display_max_mm": value,
                "zones": validated_zones,
            }
        )

    def destroy_node(self) -> bool:
        if rclpy.ok():
            self.publish_driving_enabled(False)
        self.render_stop_event.set()
        self.render_event.set()
        if self.render_thread.is_alive():
            self.render_thread.join(timeout=3.0)
        self.web_stop_event.set()
        if not self.web_loop.is_closed() and self.web_loop.is_running():
            self.web_loop.call_soon_threadsafe(self.web_loop.stop)
        if self.web_thread.is_alive():
            self.web_thread.join(timeout=3.0)
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = None
    try:
        node = VisNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
