import cv2
import rclpy

from cv_bridge import CvBridge
from my_rule_based_interfaces.msg import LaneFeatures
from rcl_interfaces.msg import SetParametersResult
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
)
from sensor_msgs.msg import Image

from my_rule_based_learning.grid_core import (
    compute_grid_features,
    validate_grid_parameters,
)


class GridNode(Node):

    def __init__(self) -> None:
        super().__init__("grid_node")

        # 토픽 설정
        self.declare_parameter(
            "rgb_topic",
            "/ascamera_hp60c/camera_publisher/rgb0/image",
        )
        self.declare_parameter(
            "lane_features_topic",
            "/lane_features",
        )

        # 영상 및 격자 설정
        self.declare_parameter("processing_width", 640)
        self.declare_parameter("processing_height", 480)
        self.declare_parameter("rows", 3)
        self.declare_parameter("cols", 7)
        self.declare_parameter("roi_b", 50)
        self.declare_parameter("roi_t", 150)
        self.declare_parameter("ths1", 100)
        self.declare_parameter("ths2", 300)
        self.declare_parameter("ker_size", 5)

        self.rgb_topic = str(
            self.get_parameter("rgb_topic").value
        )
        self.lane_features_topic = str(
            self.get_parameter("lane_features_topic").value
        )

        self.processing_width = int(
            self.get_parameter("processing_width").value
        )
        self.processing_height = int(
            self.get_parameter("processing_height").value
        )
        self.rows = int(self.get_parameter("rows").value)
        self.cols = int(self.get_parameter("cols").value)
        self.roi_b = int(self.get_parameter("roi_b").value)
        self.roi_t = int(self.get_parameter("roi_t").value)
        self.ths1 = int(self.get_parameter("ths1").value)
        self.ths2 = int(self.get_parameter("ths2").value)
        self.ker_size = int(
            self.get_parameter("ker_size").value
        )

        validate_grid_parameters(
            self.processing_width,
            self.processing_height,
            self.rows,
            self.cols,
            self.roi_b,
            self.roi_t,
            self.ths1,
            self.ths2,
            self.ker_size,
        )

        self.bridge = CvBridge()

        # Reliable/Best Effort 카메라 모두 구독하고 과거 프레임을 쌓지 않는다.
        sensor_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )

        output_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
        )

        self.feature_publisher = self.create_publisher(
            LaneFeatures,
            self.lane_features_topic,
            output_qos,
        )

        self.image_subscription = self.create_subscription(
            Image,
            self.rgb_topic,
            self.image_callback,
            sensor_qos,
        )

        # 추후 vis_node에서 실행 중 설정을 변경하기 위한 콜백
        self.add_on_set_parameters_callback(
            self.parameters_callback
        )

        self.get_logger().info(
            "Grid node ready: "
            f"RGB={self.rgb_topic}, "
            f"rows={self.rows}, cols={self.cols}, "
            f"ROI={self.roi_b}..{self.roi_t}px from bottom"
        )

    def parameters_callback(
        self,
        parameters: list[Parameter],
    ) -> SetParametersResult:
        """실행 중 격자 설정 변경을 검사하고 적용한다."""
        candidate = {
            "processing_width": self.processing_width,
            "processing_height": self.processing_height,
            "rows": self.rows,
            "cols": self.cols,
            "roi_b": self.roi_b,
            "roi_t": self.roi_t,
            "ths1": self.ths1,
            "ths2": self.ths2,
            "ker_size": self.ker_size,
        }

        for parameter in parameters:
            if parameter.name in candidate:
                if type(parameter.value) is not int:
                    return SetParametersResult(
                        successful=False,
                        reason=f"{parameter.name} must be an integer",
                    )
                candidate[parameter.name] = parameter.value

            elif parameter.name in {
                "rgb_topic",
                "lane_features_topic",
            }:
                return SetParametersResult(
                    successful=False,
                    reason=(
                        f"{parameter.name} 변경에는 "
                        "노드 재시작이 필요합니다."
                    ),
                )

        try:
            validate_grid_parameters(
                candidate["processing_width"],
                candidate["processing_height"],
                candidate["rows"],
                candidate["cols"],
                candidate["roi_b"],
                candidate["roi_t"],
                candidate["ths1"],
                candidate["ths2"],
                candidate["ker_size"],
            )

        except (TypeError, ValueError) as error:
            return SetParametersResult(
                successful=False,
                reason=str(error),
            )

        for name, value in candidate.items():
            setattr(self, name, value)

        self.get_logger().info(
            "Grid parameters updated: "
            f"rows={self.rows}, cols={self.cols}, "
            f"ROI={self.roi_b}..{self.roi_t}, "
            f"Canny={self.ths1}/{self.ths2}, "
            f"kernel={self.ker_size}"
        )

        return SetParametersResult(successful=True)

    def image_callback(self, message: Image) -> None:
        try:
            image_bgr = self.bridge.imgmsg_to_cv2(
                message,
                desired_encoding="bgr8",
            )

            if (
                image_bgr.shape[1] != self.processing_width
                or image_bgr.shape[0] != self.processing_height
            ):
                image_bgr = cv2.resize(
                    image_bgr,
                    (
                        self.processing_width,
                        self.processing_height,
                    ),
                    interpolation=cv2.INTER_LINEAR,
                )

            _debug_image, FEATURES = compute_grid_features(
                image_bgr=image_bgr,
                rows=self.rows,
                cols=self.cols,
                roi_b=self.roi_b,
                roi_t=self.roi_t,
                ths1=self.ths1,
                ths2=self.ths2,
                ker_size=self.ker_size,
                render_debug=False,
            )

            # ROS 메시지 필드는 소문자지만,
            # 학생이 사용하는 계산 변수는 항상 대문자이다.
            V = list(FEATURES["V"])
            LEFT_FEATURES = list(FEATURES["L"])
            R = list(FEATURES["R"])

            feature_message = LaneFeatures()
            feature_message.header = message.header

            feature_message.image_width = (
                self.processing_width
            )
            feature_message.image_height = (
                self.processing_height
            )

            feature_message.rows = self.rows
            feature_message.cols = self.cols
            feature_message.roi_bottom_px = self.roi_b
            feature_message.roi_top_px = self.roi_t

            feature_message.v = V
            setattr(feature_message, "l", LEFT_FEATURES)
            feature_message.r = R

            feature_message.v_no_hit = int(
                FEATURES["V_NO_HIT"]
            )
            feature_message.l_no_hit = int(
                FEATURES["L_NO_HIT"]
            )
            feature_message.r_no_hit = int(
                FEATURES["R_NO_HIT"]
            )

            self.feature_publisher.publish(feature_message)
        except Exception as error:
            self.get_logger().error(
                f"RGB image processing failed: {error}"
            )


def main(args=None) -> None:
    rclpy.init(args=args)
    node = GridNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
