// Browser transport regressions, without ROS, a browser, or npm dependencies.
// Run: node --test src/my_rule_based_learning/test/test_web_stream.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {test} = require('node:test');

const html = fs.readFileSync(path.join(__dirname, '../web/index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(match => match[1]);
const transport = scripts.find(script => script.includes('Paired latest-frame JPEG'));
const fields = ['rows', 'cols', 'roi_b', 'roi_t', 'ths1', 'ths2', 'ker_size'];
const streams = ['rgb', 'grid', 'depth', 'lidar'];
const flush = async () => { for (let i = 0; i < 15; i++) await Promise.resolve(); };

class Element {
  constructor(tagName = 'div') {
    this.tagName = tagName.toUpperCase();
    this.value = '';
    this.dataset = {};
    this.listeners = new Map();
    this.children = [];
    const classes = new Set();
    this.classList = {
      add: name => classes.add(name), remove: name => classes.delete(name), contains: name => classes.has(name),
      toggle(name, force) { if (force ?? !classes.has(name)) classes.add(name); else classes.delete(name); },
    };
  }
  addEventListener(name, callback) {
    if (!this.listeners.has(name)) this.listeners.set(name, []);
    this.listeners.get(name).push(callback);
  }
  dispatch(name) { for (const callback of this.listeners.get(name) || []) callback({preventDefault() {}}); }
  querySelector() { return new Element(); }
  replaceChildren(...children) { this.children.forEach(child => { if (typeof child === 'object') child.parentElement = null; }); this.children = []; this.append(...children); }
  append(...children) { children.forEach(child => { if (typeof child === 'object') child.parentElement = this; }); this.children.push(...children); }
  setAttribute(name, value) { this[name] = value; }
  removeAttribute(name) { delete this[name]; }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this); this.parentElement = null; }
  focus() { this.focused = true; }
}

function scheduler() {
  let id = 0;
  const timers = new Map(), animations = new Map();
  return {
    timers, animations,
    window: {
      setTimeout(callback, delay) { const key = ++id; timers.set(key, {callback, delay}); return key; },
      clearTimeout(key) { timers.delete(key); },
      requestAnimationFrame(callback) { const key = ++id; animations.set(key, callback); return key; },
      cancelAnimationFrame(key) { animations.delete(key); },
    },
    runTimer(delay) {
      const entry = [...timers].find(([, item]) => item.delay === delay);
      assert.ok(entry, `No timer with delay ${delay}`);
      timers.delete(entry[0]);
      return entry[1].callback();
    },
    paint() {
      const callbacks = [...animations.values()];
      animations.clear();
      for (const callback of callbacks) callback();
    },
  };
}

function response(stream = 'grid', version = 1, status = 200) {
  const metadata = {stream, version, preview_features: {V: [version], L: [2], R: [3]}, depth_rois: [], depth_roi_stats: []};
  return {
    status, ok: status >= 200 && status < 300,
    headers: new Map([['X-Stream-Name', stream], ['X-Frame-Version', String(version)], ['X-Frame-Metadata', JSON.stringify(metadata)]]),
    async blob() { return {stream, version}; },
    async json() { return {ok: true}; },
  };
}

function frameHarness(frameResults = []) {
  const clock = scheduler();
  const selector = new Element(); selector.value = 'grid';
  const document = new Element(); document.hidden = false; document.readyState = 'complete';
  const images = streams.map(stream => {
    const image = new Element(); image.dataset.streamName = stream;
    image.parentElement = new Element();
    return image;
  });
  document.querySelectorAll = () => images;
  document.getElementById = id => id === 'view-select' ? selector : new Element();
  const calls = [], renders = [], decodes = [], revoked = [];
  let blobNumber = 0;
  const sandbox = {
    document, window: clock.window, AbortController, DOMException, URLSearchParams,
    performance: {now: () => 0},
    URL: {createObjectURL: () => `blob:${++blobNumber}`, revokeObjectURL: url => revoked.push(url)},
    Image: class extends Element {
      decode() { return new Promise((resolve, reject) => decodes.push({resolve, reject})); }
    },
    async fetch(url, options) {
      calls.push({url, options});
      if (url === '/api/view') return response();
      const result = frameResults.shift();
      if (typeof result === 'function') return result(options);
      if (result instanceof Error) throw result;
      return result || response();
    },
    renderValues: (id, values) => renders.push({id, values: [...values]}),
    renderDepthRoiStats: metadata => renders.push({stream: 'depth', metadata}),
    renderLidarZoneStats: metadata => renders.push({stream: 'lidar', metadata}),
  };
  vm.runInNewContext(transport, sandbox);
  return {...clock, calls, renders, decodes, revoked, images, selector, document};
}

function depthHarness(saved = [{y1: null, y2: null, x1: null, x2: null}]) {
  const clock = scheduler();
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, new Element()); return elements.get(id); };
  let status = {instance_id: 'boot-1', paused: true, sources: {}, grid_defaults_loaded: false,
    grid_preview: {}, lidar_display_max_mm: 1000, depth_rois: saved, depth_rois_revision: 1, max_depth_rois: 16};
  const calls = [];
  let postHandler = payload => {
    status = {...status, depth_rois: payload.rois, depth_rois_revision: status.depth_rois_revision + 1};
    return {ok: true, saved: true, depth_rois: status.depth_rois, depth_rois_revision: status.depth_rois_revision};
  };
  const context = vm.createContext({
    document: {getElementById: get, querySelectorAll: () => fields.map(get), addEventListener() {},
      dispatchEvent() {}, hidden: false, createElement: tagName => new Element(tagName), createTextNode: value => value},
    window: clock.window, AbortController, Event,
    fetch: async (url, options) => {
      calls.push({url, options});
      return {ok: true, json: async () => url === '/api/depth' ? postHandler(JSON.parse(options.body)) : status};
    },
  });
  vm.runInContext(scripts[0].replace('    pollStatus();', ''), context);
  const run = source => vm.runInContext(source, context);
  return {
    get, calls, run,
    row: index => run(`depthRows[${index}]`),
    read: () => JSON.parse(run('JSON.stringify(readDepthRois())')),
    poll: () => run('updateStatus()'),
    submit: () => get('depth-form').listeners.get('submit')[0]({preventDefault() {}}),
    setStatus: changes => { status = {...status, ...changes}; },
    setPostHandler: handler => { postHandler = handler; },
  };
}

test('all inline scripts parse; initial markup starts no MJPEG connections', () => {
  scripts.forEach(script => new vm.Script(script));
  const images = [...html.matchAll(/<img\b[^>]+>/g)].map(match => match[0]);
  assert.equal(images.length, 4);
  assert.ok(images.every(image => image.includes('data-stream-name=') && !/\ssrc=/.test(image)));
});

test('drive stop and error notices stay outside sensor-specific panels, including RGB', () => {
  const noticeIndex = html.indexOf('id="error-notice"');
  const mainGridIndex = html.indexOf('<div class="main-grid">');
  const asideIndex = html.indexOf('<aside>');
  assert.ok(noticeIndex > 0 && noticeIndex < mainGridIndex && mainGridIndex < asideIndex);
  assert.equal((html.match(/id="error-notice"/g) || []).length, 1);
  assert.match(html, /<section id="error-notice"[^>]*aria-live="polite"/);
});

test('grid controls wait for ROS defaults and initialize only once; status never renders measurements', async () => {
  const clock = scheduler();
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, new Element()); return elements.get(id); };
  const gridControls = fields.map(get).concat(get('apply'));
  let status = {instance_id: 'boot-1', paused: true, sources: {}, grid_defaults_loaded: false, grid_preview: {}, lidar_display_max_mm: 1000};
  const events = [];
  const context = vm.createContext({
    document: {getElementById: get, querySelectorAll: () => gridControls, addEventListener() {}, hidden: false,
      dispatchEvent: event => events.push(event.type),
      createElement: () => new Element(), createTextNode: value => value},
    window: clock.window, AbortController, Event,
    fetch: async () => ({ok: true, json: async () => status}),
  });
  // Drive the status reads explicitly; the production periodic scheduler is not needed here.
  vm.runInContext(scripts[0].replace('    pollStatus();', ''), context);
  await vm.runInContext('updateStatus()', context);
  assert.ok(gridControls.every(element => element.disabled));
  assert.equal(get('rows').value, '');
  status = {...status, grid_defaults_loaded: true,
    grid_preview: {rows: 9, cols: 13, roi_b: 7, roi_t: 690, ths1: 71, ths2: 153, ker_size: 7, processing_width: 1280, processing_height: 720},
    preview_features: {V: [999], L: [999], R: [999]}};
  await vm.runInContext('updateStatus()', context);
  assert.equal(get('rows').value, 9);
  assert.equal(get('roi_b').max, 719);
  assert.equal(get('roi_t').max, 720);
  assert.ok(gridControls.every(element => !element.disabled));
  get('rows').value = '12';
  await vm.runInContext('updateStatus()', context);
  assert.equal(get('rows').value, '12');
  assert.equal(get('preview-values-v').children.length, 0);
  assert.equal(get('depth-roi-stats').children.length, 0);
  status = {...status, instance_id: 'boot-2', grid_defaults_loaded: false};
  await vm.runInContext('updateStatus()', context);
  assert.ok(gridControls.every(element => element.disabled));
  assert.equal(get('rows').value, '');
  status = {...status, grid_defaults_loaded: true, grid_preview: {...status.grid_preview, rows: 5}};
  await vm.runInContext('updateStatus()', context);
  assert.equal(get('rows').value, 5);
  assert.deepEqual(events, ['vis-server-restarted', 'vis-server-restarted']);
});

test('default button posts actual fetched ROS parameters before updating inputs', async () => {
  const form = new Element();
  const callbacks = [];
  let button;
  form.querySelector = () => ({insertAdjacentElement(position, element) { button = element; }});
  const parameters = {rows: 11, cols: 17, roi_b: 10, roi_t: 680, ths1: 40, ths2: 100, ker_size: 5, processing_height: 720};
  const operations = [];
  const context = {
    document: {
      addEventListener(name, callback) { callbacks.push(callback); },
      getElementById: id => id === 'grid-form' ? form : null,
      createElement: () => new Element(), querySelectorAll: () => [],
    },
    previewDefaultsLoaded: true,
    requestJson: async (url, options) => {
      operations.push({url, options});
      return {parameters};
    },
    fillGridForm: values => operations.push({filled: values}),
    setMessage() {},
  };
  vm.runInNewContext(scripts[1], context);
  callbacks[0]();
  assert.equal(button.disabled, false);
  await button.listeners.get('click')[0]();
  assert.equal(operations[0].url, '/api/grid/defaults');
  assert.equal(operations[1].url, '/api/grid');
  assert.equal(operations[1].options.method, 'POST');
  assert.deepEqual(JSON.parse(operations[1].options.body), parameters);
  assert.equal(operations[2].filled, parameters);
});

test('decision safety stops override a running request and include their reason with visualization errors', async () => {
  const clock = scheduler();
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, new Element()); return elements.get(id); };
  let status;
  const context = vm.createContext({
    document: {getElementById: get, querySelectorAll: () => fields.map(get), addEventListener() {}, hidden: false},
    window: clock.window, AbortController,
    fetch: async () => ({ok: true, json: async () => status}),
  });
  vm.runInContext(scripts[0].replace('    pollStatus();', ''), context);
  const cases = [
    {paused: false, decision_status: null, label: '주행 중', running: true, message: ''},
    {paused: true, decision_status: null, label: '일시정지', running: false, message: ''},
    {paused: false, decision_status: {driving_enabled: false, reason: 'Depth 수신 시간 초과'}, label: '안전 정지', running: false, message: '주행 정지: Depth 수신 시간 초과'},
    {paused: false, decision_status: {driving_enabled: false, reason: ''}, label: '일시정지', running: false, message: ''},
    {paused: false, decision_status: {driving_enabled: false, reason: 'LiDAR 오류'}, last_error: '영상 변환 실패', label: '안전 정지', running: false, message: '주행 정지: LiDAR 오류 · 최근 오류: 영상 변환 실패'},
    {paused: true, decision_status: {driving_enabled: true, reason: ''}, label: '일시정지', running: false, message: ''},
    {paused: false, decision_status: {driving_enabled: true, reason: '이전 오류'}, label: '주행 중', running: true, message: ''},
    {paused: false, label: '주행 중', running: true, message: ''},
  ];
  for (const sample of cases) {
    status = {sources: {}, grid_defaults_loaded: false, grid_preview: {}, lidar_display_max_mm: 1000, ...sample};
    await vm.runInContext('updateStatus()', context);
    assert.equal(get('drive-pill').textContent, sample.label);
    assert.equal(get('drive-pill').classList.contains('running'), sample.running);
    assert.equal(get('error-notice').textContent, sample.message);
    assert.equal(get('error-notice').hidden, !sample.message);
  }
});

test('decoded image and measurements commit together; after and 204 do not re-decode', async () => {
  const h = frameHarness([response('grid', 7), response('grid', 7, 204)]);
  const initialRenderCount = h.renders.length;
  const first = h.runTimer(0);
  await flush();
  assert.deepEqual(h.calls.map(call => call.url), ['/api/view', '/frame/active.jpg?stream=grid']);
  assert.equal(h.renders.length, initialRenderCount);
  assert.equal(h.images[1].src, undefined);
  assert.equal(h.decodes.length, 1);
  h.decodes[0].resolve(); await flush();
  assert.equal(h.renders.length, initialRenderCount);
  h.paint(); await first;
  assert.equal(h.images[1].src, 'blob:1');
  assert.deepEqual(h.renders.slice(-3)[0].values, [7]);
  await h.runTimer(40);
  assert.equal(h.calls.at(-1).url, '/frame/active.jpg?stream=grid&after=7');
  assert.equal(h.decodes.length, 1);
  assert.equal(h.images[1].src, 'blob:1');
  assert.ok(h.calls.every(call => call.options.cache === 'no-store'));
});

test('switching views aborts decoding and prevents a stale frame or measurements', async () => {
  const h = frameHarness([response('grid', 1), response('depth', 2)]);
  const first = h.runTimer(0); await flush();
  h.selector.value = 'depth'; h.selector.dispatch('change');
  await first;
  h.decodes[0].resolve(); await flush(); h.paint();
  assert.equal(h.images[1].src, undefined);
  assert.ok(h.revoked.includes('blob:1'));
  const second = h.runTimer(0); await flush();
  h.decodes[1].resolve(); await flush(); h.paint(); await second;
  assert.equal(h.images[2].src, 'blob:2');
  assert.equal(h.renders.at(-1).metadata.version, 2);
  assert.deepEqual(h.calls.filter(call => call.url === '/api/view').map(call => JSON.parse(call.options.body).stream), ['grid', 'depth']);
});

test('409 and network failures retry view selection before requesting another frame', async () => {
  const h = frameHarness([response('grid', 1, 409), new Error('offline'), response('grid', 2)]);
  await h.runTimer(0);
  await h.runTimer(350);
  const third = h.runTimer(350); await flush();
  h.decodes[0].resolve(); await flush(); h.paint(); await third;
  assert.deepEqual(h.calls.map(call => call.url), [
    '/api/view', '/frame/active.jpg?stream=grid',
    '/api/view', '/frame/active.jpg?stream=grid',
    '/api/view', '/frame/active.jpg?stream=grid',
  ]);
});

test('a hung request is aborted at timeout and retried', async () => {
  const h = frameHarness([options => new Promise((resolve, reject) => {
    options.signal.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
  })]);
  const pending = h.runTimer(0); await flush();
  h.runTimer(5000); await pending;
  assert.ok(h.calls.at(-1).options.signal.aborted);
  assert.ok([...h.timers.values()].some(timer => timer.delay === 350));
});

test('hidden pages abort and pause; visibility restoration selects a fresh frame', async () => {
  const h = frameHarness([response('grid', 10), response('grid', 11)]);
  const pending = h.runTimer(0); await flush();
  h.document.hidden = true; h.document.dispatch('visibilitychange');
  await pending;
  assert.equal(h.timers.size, 0);
  assert.ok(h.revoked.includes('blob:1'));
  h.document.hidden = false; h.document.dispatch('visibilitychange');
  const resumed = h.runTimer(0); await flush();
  h.decodes.at(-1).resolve(); await flush(); h.paint(); await resumed;
  assert.equal(h.calls.at(-2).url, '/api/view');
  assert.equal(h.calls.at(-1).url, '/frame/active.jpg?stream=grid');
  assert.equal(h.renders.slice(-3)[0].values[0], 11);
});

test('switching while waiting for browser paint cancels the pending animation and revokes its blob', async () => {
  const h = frameHarness([response('grid', 10)]);
  const pending = h.runTimer(0); await flush();
  h.decodes[0].resolve(); await flush();
  assert.equal(h.animations.size, 1);
  h.selector.value = 'lidar'; h.selector.dispatch('change');
  await pending;
  assert.equal(h.animations.size, 0);
  assert.ok(h.revoked.includes('blob:1'));
  assert.equal(h.images[1].src, undefined);
});

test('server restart re-registers the selected view and drops its previous version', async () => {
  const h = frameHarness([response('grid', 10), response('grid', 1)]);
  const first = h.runTimer(0); await flush();
  h.decodes[0].resolve(); await flush(); h.paint(); await first;
  h.document.dispatch('vis-server-restarted');
  const second = h.runTimer(0); await flush();
  h.decodes[1].resolve(); await flush(); h.paint(); await second;
  assert.equal(h.calls.at(-2).url, '/api/view');
  assert.equal(h.calls.at(-1).url, '/frame/active.jpg?stream=grid');
  assert.equal(h.renders.slice(-3)[0].values[0], 1);
  assert.ok(h.revoked.includes('blob:1'));
});

test('saved ROI lists restore in y1, y2, x1, x2 order without status painting measurements', async () => {
  const saved = [
    {y1: 10, y2: 20, x1: 30, x2: 40},
    {y1: null, y2: null, x1: null, x2: null},
    {y1: 479, y2: 479, x1: 639, x2: 639},
  ];
  const h = depthHarness(saved);
  await h.poll();
  assert.deepEqual(h.read(), saved);
  const firstRow = h.row(0);
  assert.equal(firstRow.box.tagName, 'FIELDSET');
  assert.equal(firstRow.legend.textContent, 'ROI 1');
  assert.equal(firstRow.remove.type, 'button');
  assert.equal(firstRow.remove['aria-label'], 'ROI 1 삭제');
  assert.deepEqual(firstRow.box.children[1].children.map(label => label.children[0].id),
    ['roi-1-y1', 'roi-1-y2', 'roi-1-x1', 'roi-1-x2']);
  assert.equal(h.get('depth-roi-stats').children.length, 0);
  await h.poll();
  assert.equal(h.row(0), firstRow, 'unchanged status must retain input nodes and focus');
  h.setStatus({depth_rois: [], depth_rois_revision: 2});
  await h.poll();
  assert.deepEqual(h.read(), []);
  assert.match(h.get('depth-roi-count').textContent, /ROI 없음/);
  assert.equal(h.get('depth-add-button').disabled, false);
});

test('ROI additions and removals stay local until apply; removing all persists an empty list', async () => {
  const h = depthHarness([]);
  await h.poll();
  h.get('depth-add-button').dispatch('click');
  assert.equal(h.row(0).fields.y1.focused, true);
  h.get('depth-add-button').dispatch('click');
  h.get('depth-add-button').dispatch('click');
  const survivor = h.row(2);
  h.row(1).remove.dispatch('click');
  assert.equal(h.row(1), survivor);
  assert.equal(survivor.legend.textContent, 'ROI 2');
  assert.equal(survivor.fields.y1.id, 'roi-2-y1');
  assert.equal(survivor.remove['aria-label'], 'ROI 2 삭제');
  assert.equal(h.get('depth-roi-fields').children.length, 2);
  assert.equal(h.calls.filter(call => call.url === '/api/depth').length, 0);
  h.row(1).remove.dispatch('click');
  h.row(0).remove.dispatch('click');
  assert.equal(h.get('depth-add-button').focused, true);
  assert.deepEqual(h.read(), []);
  await h.submit();
  const posted = h.calls.find(call => call.url === '/api/depth');
  assert.deepEqual(JSON.parse(posted.options.body), {rois: []});
  h.setStatus({instance_id: 'boot-2', depth_rois_revision: 0});
  await h.poll();
  assert.deepEqual(h.read(), [], 'saved zero entries must stay empty after restart');
  assert.equal(h.run('depthDirty'), false);
});

test('ROI validation allows blanks, zeros, and inclusive pixels, but rejects partial or invalid coordinates', async () => {
  const h = depthHarness();
  await h.poll();
  assert.deepEqual(h.read(), [{y1: null, y2: null, x1: null, x2: null}]);
  const put = values => Object.entries(values).forEach(([name, value]) => { h.row(0).fields[name].value = value; });
  put({y1: '0', y2: '0', x1: '0', x2: '0'});
  assert.deepEqual(h.read(), [{y1: 0, y2: 0, x1: 0, x2: 0}]);
  put({y1: '0', y2: '479', x1: '0', x2: '639'});
  assert.deepEqual(h.read(), [{y1: 0, y2: 479, x1: 0, x2: 639}]);
  for (const invalid of [
    {y1: ''}, {y1: '-1'}, {y1: '480'}, {y1: '1.5'}, {y1: 'NaN'},
    {y2: '480'}, {y2: '-1'}, {x1: '-1'}, {x1: '640'}, {x2: '640'}, {x2: '-1'},
  ]) {
    put({y1: '0', y2: '479', x1: '0', x2: '639', ...invalid});
    assert.throws(h.read, /ROI 1:/);
  }
  await h.submit();
  assert.equal(h.calls.filter(call => call.url === '/api/depth').length, 0);
  assert.match(h.get('depth-message').className, /error/);
});

test('ROI add button and payload validation enforce the advertised maximum of 16', async () => {
  const h = depthHarness([]);
  await h.poll();
  for (let index = 0; index < 17; index++) h.get('depth-add-button').dispatch('click');
  assert.equal(h.read().length, 16);
  assert.equal(h.get('depth-add-button').disabled, true);
  assert.match(h.get('depth-roi-count').textContent, /16 \/ 16/);
  h.run('appendDepthRow()');
  assert.throws(h.read, /최대 16개/);
  h.row(16).remove.dispatch('click');
  h.row(15).remove.dispatch('click');
  assert.equal(h.get('depth-add-button').disabled, false);
});

test('polling or a server restart preserves unsaved ROI edits; clean forms follow saved revisions', async () => {
  const h = depthHarness([{y1: 10, y2: 20, x1: 30, x2: 40}]);
  await h.poll();
  h.row(0).fields.y1.value = '11';
  h.row(0).fields.y1.dispatch('input');
  const draft = h.row(0);
  const replacement = [{y1: 100, y2: 200, x1: 300, x2: 400}];
  h.setStatus({depth_rois: replacement, depth_rois_revision: 2});
  await h.poll();
  assert.equal(h.row(0), draft);
  assert.equal(h.read()[0].y1, 11);
  h.setStatus({instance_id: 'boot-2', depth_rois_revision: 0});
  await h.poll();
  assert.equal(h.row(0), draft);
  assert.equal(h.read()[0].y1, 11);
  await h.submit();
  assert.equal(h.run('depthDirty'), false);
  h.setStatus({depth_rois: replacement, depth_rois_revision: 0});
  await h.poll();
  assert.equal(h.read()[0].y1, 11, 'an older status response cannot replace a successful save');
  h.setStatus({depth_rois: replacement, depth_rois_revision: 2});
  await h.poll();
  assert.deepEqual(h.read(), replacement);
  h.setStatus({instance_id: 'boot-3', depth_rois: [], depth_rois_revision: 0});
  await h.poll();
  assert.deepEqual(h.read(), [], 'a clean form restores persisted data after restart');
});

test('edits made during ROI save remain a draft and failed saves do not discard it', async () => {
  const h = depthHarness();
  await h.poll();
  let finishSave;
  h.setPostHandler(payload => new Promise(resolve => { finishSave = () => resolve({ok: true, saved: true, depth_rois: payload.rois, depth_rois_revision: 2}); }));
  const pending = h.submit();
  await flush();
  assert.equal(h.get('depth-apply-button').disabled, true);
  h.get('depth-add-button').dispatch('click');
  const added = h.row(1);
  finishSave();
  await pending;
  assert.equal(h.row(1), added);
  assert.equal(h.read().length, 2);
  assert.equal(h.run('depthDirty'), true);
  assert.match(h.get('depth-message').textContent, /아직 저장되지/);
  h.setPostHandler(() => { throw new Error('설정 파일 저장 실패'); });
  await h.submit();
  assert.equal(h.row(1), added);
  assert.equal(h.run('depthDirty'), true);
  assert.equal(h.get('depth-apply-button').disabled, false);
  assert.match(h.get('depth-message').textContent, /설정 파일 저장 실패/);
});

test('Depth frame statistics use the saved frame list and mark default-zero invalid distances as missing', async () => {
  const h = depthHarness();
  await h.poll();
  const stat = {count: 0, distance_min_mm: 0, distance_mean_mm: 0, distance_max_mm: 0};
  const validStat = {count: 3, distance_min_mm: 1000, distance_mean_mm: 1500, distance_max_mm: 2000};
  const metadata = {depth_rois: [{x1: null}, {x1: 0}, {x1: 10}], depth_roi_stats: [null, stat, validStat]};
  h.run(`renderDepthRoiStats(${JSON.stringify(metadata)})`);
  const rendered = h.get('depth-roi-stats').children;
  assert.equal(rendered.length, 3);
  assert.match(rendered[0].innerHTML, /ROI 1.*미설정/);
  assert.match(rendered[1].innerHTML, /유효 0 픽셀/);
  assert.equal((rendered[1].innerHTML.match(/<td>0<\/td>/g) || []).length, 3);
  assert.match(rendered[1].innerHTML, /유효값 없음/);
  assert.doesNotMatch(rendered[1].innerHTML, /밝기|undefined/);
  assert.match(rendered[2].innerHTML, /ROI 3/);
  h.run('renderDepthRoiStats({depth_rois: [], depth_roi_stats: []})');
  assert.equal(h.get('depth-roi-stats').children.length, 0);
});
