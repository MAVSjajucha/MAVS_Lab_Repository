"""Real OpenCV regression tests; no ROS installation is required."""
import ast
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


SOURCE = Path(__file__).parents[1] / "my_rule_based_learning"
SPEC = importlib.util.spec_from_file_location("grid_core_under_test", SOURCE / "grid_core.py")
CORE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CORE)


@pytest.mark.parametrize("width,height,rows,cols,roi_b,roi_t", [
    (2, 2, 4, 4, 0, 2),
    (1, 1, 3, 3, 0, 1),
    (8, 8, 20, 30, 7, 8),
    (640, 480, 3, 7, 50, 150),
])
def test_dense_grid_never_indexes_outside_image(width, height, rows, cols, roi_b, roi_t):
    image = np.zeros((height, width, 3), dtype=np.uint8)
    debug, features = CORE.compute_grid_features(image, rows, cols, roi_b, roi_t, 100, 300, 1)
    assert debug.shape == image.shape
    assert features["V"] == [roi_t - roi_b] * cols
    assert features["L"] == [width // 2 + 1] * rows
    assert features["R"] == [width // 2 + 1] * rows


def test_blank_640_image_uses_321_for_both_horizontal_no_hit_values():
    _, features = CORE.compute_grid_features(
        np.zeros((480, 640, 3), dtype=np.uint8),
        3, 7, 50, 150, 100, 300, 1, render_debug=False,
    )
    assert features["L_NO_HIT"] == features["R_NO_HIT"] == 321
    assert features["L"] == features["R"] == [321, 321, 321]


@pytest.mark.parametrize("right_x,expected_distance", [
    (320, 0), (321, 1), (500, 180), (639, 319),
])
def test_640_right_hits_keep_measured_pixel_distances(
    monkeypatch, right_x, expected_distance,
):
    edges = np.zeros((10, 640), dtype=np.uint8)
    edges[:, right_x] = 255
    monkeypatch.setattr(CORE.cv2, "Canny", lambda *_args: edges)
    _, features = CORE.compute_grid_features(
        np.zeros((10, 640, 3), dtype=np.uint8),
        3, 7, 0, 10, 100, 300, 1, render_debug=False,
    )
    assert features["R"] == [expected_distance] * 3
    assert features["R_NO_HIT"] == 321


@pytest.mark.parametrize("width", [1, 2, 319, 320, 321, 640, 641])
def test_shared_horizontal_no_hit_never_collides_with_image_edge_hits(
    monkeypatch, width,
):
    edges = np.zeros((10, width), dtype=np.uint8)
    monkeypatch.setattr(CORE.cv2, "Canny", lambda *_args: edges)
    image = np.zeros((10, width, 3), dtype=np.uint8)

    _, blank_features = CORE.compute_grid_features(
        image, 3, 7, 0, 10, 100, 300, 1, render_debug=False,
    )
    no_hit = width // 2 + 1
    assert blank_features["L_NO_HIT"] == blank_features["R_NO_HIT"] == no_hit
    assert blank_features["L"] == blank_features["R"] == [no_hit] * 3

    # Exercise each boundary separately, including one- and two-pixel images.
    for direction, x_position, expected_distance in (
        ("L", 0, width // 2),
        ("R", width - 1, width - 1 - width // 2),
    ):
        edges.fill(0)
        edges[:, x_position] = 255
        _, features = CORE.compute_grid_features(
            image, 3, 7, 0, 10, 100, 300, 1, render_debug=False,
        )
        assert features[direction] == [expected_distance] * 3
        assert expected_distance < features[f"{direction}_NO_HIT"] == no_hit


def test_dense_top_roi_does_not_sample_bottom_row(monkeypatch):
    edges = np.zeros((5, 6), dtype=np.uint8)
    edges[-1, :] = 255
    monkeypatch.setattr(CORE.cv2, "Canny", lambda *_args: edges)
    _, features = CORE.compute_grid_features(
        np.zeros((5, 6, 3), dtype=np.uint8), 10, 2, 4, 5, 100, 300, 1
    )
    assert features["L"] == [4] * 10
    assert features["R"] == [4] * 10


def test_debug_skip_preserves_all_feature_values():
    image = np.zeros((80, 100, 3), dtype=np.uint8)
    image[:, 20:25] = 255
    image[:, 75:80] = 255
    debug, expected = CORE.compute_grid_features(image, 3, 7, 0, 70, 20, 100, 3)
    no_debug, actual = CORE.compute_grid_features(
        image, 3, 7, 0, 70, 20, 100, 3, render_debug=False
    )
    assert debug is not None
    assert no_debug is None
    assert actual == expected


@pytest.mark.parametrize("invalid", [None, True, 1.5, float("nan"), float("inf"), "3"])
def test_grid_rejects_noninteger_parameters(invalid):
    with pytest.raises(ValueError):
        CORE.validate_grid_parameters(640, 480, invalid, 7, 50, 150, 100, 300, 5)


def test_invalid_parameter_update_is_rejected_without_mutation():
    tree = ast.parse((SOURCE / "grid_node.py").read_text(encoding="utf-8"))
    node_class = next(node for node in tree.body if isinstance(node, ast.ClassDef))
    callback = next(node for node in node_class.body if isinstance(node, ast.FunctionDef) and node.name == "parameters_callback")
    namespace = {
        "Parameter": object,
        "SetParametersResult": lambda **kwargs: SimpleNamespace(**kwargs),
        "validate_grid_parameters": CORE.validate_grid_parameters,
    }
    exec(compile(ast.Module(body=[callback], type_ignores=[]), "grid_callback", "exec"), namespace)
    original = dict(processing_width=640, processing_height=480, rows=3, cols=7,
                    roi_b=50, roi_t=150, ths1=100, ths2=300, ker_size=5)
    for value in (None, True, "invalid", 1.5, float("nan")):
        node = SimpleNamespace(**original)
        result = namespace["parameters_callback"](node, [SimpleNamespace(name="rows", value=value)])
        assert not result.successful
        assert vars(node) == original
