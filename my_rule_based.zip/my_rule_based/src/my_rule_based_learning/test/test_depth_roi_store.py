"""Exercise the ROI helpers integrated into vis_node without ROS imports."""

import ast
import json
import os
from pathlib import Path
import tempfile
from types import ModuleType

import pytest


source_path = (Path(__file__).resolve().parents[1]
               / "my_rule_based_learning" / "vis_node.py")
tree = ast.parse(source_path.read_text(encoding="utf-8"))
constants = {"MAX_DEPTH_ROIS", "ROI_WIDTH", "ROI_HEIGHT", "ROI_FIELDS"}
functions = {"default_roi_path", "empty_roi", "validate_depth_rois",
             "load_depth_rois", "save_depth_rois"}
helpers = [item for item in tree.body if (
    isinstance(item, ast.Assign)
    and any(isinstance(target, ast.Name) and target.id in constants
            for target in item.targets)
) or (isinstance(item, ast.FunctionDef) and item.name in functions)]
store = ModuleType("vis_roi_helpers")
store.__dict__.update(json=json, os=os, Path=Path, tempfile=tempfile)
exec(compile(ast.Module(body=helpers, type_ignores=[]), str(source_path), "exec"),
     store.__dict__)


def test_missing_file_and_saved_empty_list_are_distinct(tmp_path):
    path = tmp_path / "nested" / "rois.json"
    assert store.load_depth_rois(path) == [store.empty_roi()]
    store.save_depth_rois(path, [])
    assert store.load_depth_rois(path) == []


def test_multiple_rois_round_trip_and_inclusive_edges(tmp_path):
    path = tmp_path / "rois.json"
    rois = [{"y1": 0, "y2": 479, "x1": 0, "x2": 639},
            {"y1": 479, "y2": 479, "x1": 639, "x2": 639}, store.empty_roi()]
    store.save_depth_rois(path, rois)
    assert store.load_depth_rois(path) == rois
    assert list(json.loads(path.read_text())["rois"][0]) == ["y1", "y2", "x1", "x2"]
    assert list(tmp_path.glob("*.tmp")) == []


@pytest.mark.parametrize("rois", [
    None, {}, [None], [store.empty_roi()] * 17,
    [{"y1": 0, "y2": None, "x1": 0, "x2": 10}],
    [{"y1": True, "y2": 10, "x1": 0, "x2": 10}],
    [{"y1": 1.0, "y2": 10, "x1": 0, "x2": 10}],
    [{"y1": -1, "y2": 10, "x1": 0, "x2": 10}],
    [{"y1": 0, "y2": 480, "x1": 0, "x2": 10}],
    [{"y1": 0, "y2": 10, "x1": 0, "x2": 640}],
    [{"y1": 20, "y2": 10, "x1": 0, "x2": 10}],
])
def test_invalid_rois_never_change_existing_file(tmp_path, rois):
    path = tmp_path / "rois.json"
    store.save_depth_rois(path, [])
    before = path.read_bytes()
    with pytest.raises(ValueError):
        store.save_depth_rois(path, rois)
    assert path.read_bytes() == before


def test_atomic_replace_failure_preserves_previous_file(tmp_path, monkeypatch):
    path = tmp_path / "rois.json"
    store.save_depth_rois(path, [])
    before = path.read_bytes()

    def fail_replace(*_):
        raise PermissionError("simulated save failure")

    monkeypatch.setattr(store.os, "replace", fail_replace)
    with pytest.raises(PermissionError):
        store.save_depth_rois(path, [store.empty_roi()])
    assert path.read_bytes() == before
    assert list(tmp_path.glob("*.tmp")) == []


@pytest.mark.parametrize("content", ["{broken", "[]", '{"version":99}',
    '{"version":1,"width":640,"height":480,"rois":[{"y1":7}]}'])
def test_corrupt_file_is_not_overwritten(tmp_path, content):
    path = tmp_path / "rois.json"
    path.write_text(content)
    with pytest.raises(ValueError):
        store.load_depth_rois(path)
    assert path.read_text() == content


def test_custom_ros_home_is_used(monkeypatch, tmp_path):
    monkeypatch.setenv("ROS_HOME", str(tmp_path))
    assert store.default_roi_path() == tmp_path / "my_rule_based_learning" / "depth_rois.json"
