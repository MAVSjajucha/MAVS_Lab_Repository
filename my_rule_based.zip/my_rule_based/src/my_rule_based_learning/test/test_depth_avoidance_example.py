"""Verify the for/yield example independently of ROS hardware."""
import ast
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

EXAMPLE = Path(__file__).resolve().parents[1] / "examples" / "depth_avoidance_example.py"


class Twist:
    def __init__(self):
        self.linear = SimpleNamespace(x=0.0)
        self.angular = SimpleNamespace(z=0.0)


@pytest.fixture
def rule():
    tree = ast.parse(EXAMPLE.read_text(encoding="utf-8"))
    tree.body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
    namespace = dict(np=np, Twist=Twist)
    exec(compile(tree, str(EXAMPLE), "exec"), namespace)
    return namespace["decide_depth"]


def frame(front):
    data = np.zeros((480, 640), np.float32)
    data[220:260, 300:340] = front
    return data


@pytest.mark.parametrize("front", [0, 200, 699])
def test_near_or_missing_roi_yields_ten_forward_left_commands(rule, front):
    commands = list(rule(frame(front)))
    assert len(commands) == 10
    assert all((c.linear.x, c.angular.z) == (0.04, 0.4) for c in commands)


@pytest.mark.parametrize("front", [700, 1000, 4000])
def test_clear_roi_yields_one_straight_command(rule, front):
    commands = list(rule(frame(front)))
    assert len(commands) == 1
    assert (commands[0].linear.x, commands[0].angular.z) == (0.1, 0.0)


def test_zeros_are_excluded_and_outside_roi_does_not_change_decision(rule):
    data = frame(800)
    data[220:240, 300:340] = 0
    original = data.copy()
    commands = list(rule(data))
    assert len(commands) == 1
    assert (commands[0].linear.x, commands[0].angular.z) == (0.1, 0.0)
    np.testing.assert_array_equal(data, original)


def test_started_turn_finishes_before_new_input_is_used(rule):
    data = frame(500)
    sequence = rule(data)
    assert next(sequence).angular.z == 0.4
    data[:] = 1000
    remaining = list(sequence)
    assert len(remaining) == 9
    assert all((c.linear.x, c.angular.z) == (0.04, 0.4) for c in remaining)
    commands = list(rule(data))
    assert len(commands) == 1
    assert (commands[0].linear.x, commands[0].angular.z) == (0.1, 0.0)
