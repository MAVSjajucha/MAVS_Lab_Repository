"""Exercise real rendering and HTTP without installing ROS or starting a node.

Only ROS imports and Node construction are omitted via the AST; OpenCV, NumPy,
aiohttp, the production methods, and the grid feature implementation run as-is.
"""

import ast
import asyncio
from concurrent.futures import Future
import importlib.util
import json
import math
import os
from pathlib import Path
import queue
import tempfile
import threading
import time
from types import SimpleNamespace
from unittest.mock import Mock

import cv2
import numpy as np
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer


PACKAGE_PATH = Path(__file__).resolve().parents[1] / "my_rule_based_learning"
STREAM_NAMES = ("rgb", "grid", "depth", "lidar")
GRID_PARAMETERS = {
    "rows": 4, "cols": 9, "roi_b": 20, "roi_t": 120,
    "ths1": 60, "ths2": 170, "ker_size": 3,
    "processing_width": 320, "processing_height": 240,
}


def load_vis_class():
    core_spec = importlib.util.spec_from_file_location(
        "grid_core_for_vis_tests", PACKAGE_PATH / "grid_core.py"
    )
    core = importlib.util.module_from_spec(core_spec)
    core_spec.loader.exec_module(core)
    source_path = PACKAGE_PATH / "vis_node.py"
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    roi_constants = {"MAX_DEPTH_ROIS", "ROI_WIDTH", "ROI_HEIGHT", "ROI_FIELDS"}
    roi_functions = {
        "default_roi_path", "empty_roi", "validate_depth_rois",
        "load_depth_rois", "save_depth_rois",
    }
    roi_helpers = [item for item in tree.body if (
        isinstance(item, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id in roi_constants
                for target in item.targets)
    ) or (isinstance(item, ast.FunctionDef) and item.name in roi_functions)]
    vis_class = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "VisNode"
    )
    vis_class.bases = []
    vis_class.body = [
        node for node in vis_class.body
        if getattr(node, "name", None) != "__init__"
    ]
    api_middleware = next(
        item for item in tree.body
        if isinstance(item, ast.AsyncFunctionDef)
        and item.name == "validate_api_json"
    )
    isolated = ast.Module(body=[
        ast.ImportFrom(
            module="__future__", names=[ast.alias(name="annotations")], level=0
        ),
        *roi_helpers, api_middleware, vis_class,
    ], type_ignores=[])
    namespace = {
        "asyncio": asyncio, "json": json, "math": math, "queue": queue,
        "os": os, "Path": Path, "tempfile": tempfile,
        "threading": threading, "time": time, "cv2": cv2, "np": np,
        "web": web, "STREAM_NAMES": STREAM_NAMES,
        "compute_grid_features": core.compute_grid_features,
        "validate_grid_parameters": core.validate_grid_parameters,
        "ParameterType": SimpleNamespace(PARAMETER_INTEGER=2),
        "GetParameters": SimpleNamespace(Request=SimpleNamespace),
    }
    exec(compile(ast.fix_missing_locations(isolated), str(source_path), "exec"),
         namespace)
    namespace["VisNode"].api_json_middleware = staticmethod(
        namespace["validate_api_json"]
    )
    return namespace["VisNode"]


@pytest.fixture
def node(tmp_path):
    instance = load_vis_class()()
    instance.status_lock = threading.Lock()
    instance.frame_lock = threading.Lock()
    instance.source_lock = threading.Lock()
    instance.render_event = threading.Event()
    instance.render_stop_event = threading.Event()
    instance.web_stop_event = threading.Event()
    instance.latest_messages = {}
    instance.source_versions = {name: 0 for name in ("rgb", "depth", "lidar")}
    instance.source_rx_time = dict.fromkeys(STREAM_NAMES, 0.0)
    instance.frames = {}
    instance.frame_versions = dict.fromkeys(STREAM_NAMES, 0)
    instance.frame_metadata = {}
    instance.last_frame_time = dict.fromkeys(STREAM_NAMES, 0.0)
    instance.stream_fps = 30.0
    instance.jpeg_quality = 80
    instance.render_revision = 0
    instance.active_stream = "rgb"
    instance.grid_defaults_loaded = False
    instance.grid_defaults_future = None
    instance.grid_defaults_requested_at = 0.0
    instance.grid_defaults_refreshed_at = 0.0
    instance.grid_default_names = tuple(GRID_PARAMETERS)
    instance.grid_node_parameters = {}
    instance.preview_grid_parameters = {}
    instance.preview_features = {
        "V": [], "L": [], "R": [],
        "V_NO_HIT": 0, "L_NO_HIT": 0, "R_NO_HIT": 0,
    }
    instance.depth_display_max_mm = 4000
    instance.depth_min_mm = 200.0
    instance.depth_max_mm = 4000.0
    instance.depth_invalid_value_mm = 0.0
    instance.depth_rois = [
        {"x1": None, "y1": None, "x2": None, "y2": None}
        for _ in range(2)
    ]
    instance.depth_roi_stats = [None, None]
    instance.depth_roi_config_path = tmp_path / "settings" / "depth_rois.json"
    instance.depth_roi_save_lock = threading.Lock()
    instance.depth_roi_storage_error = ""
    instance.depth_rois_revision = 0
    instance.lidar_display_max_mm = 1000
    instance.lidar_heading_offset_deg = 180.0
    instance.lidar_zones = [
        {"start_deg": None, "end_deg": None} for _ in range(4)
    ]
    instance.lidar_zone_stats = [None] * 4
    instance.paused = True
    instance.decision_status = {}
    instance.last_error = ""
    instance.last_error_log_time = 0.0
    instance.instance_id = "test-instance"
    instance.control_queue = queue.Queue()
    instance.bridge = SimpleNamespace(
        imgmsg_to_cv2=lambda message, encoding: message.image
    )
    instance.logger = Mock()
    instance.get_logger = lambda: instance.logger
    yield instance
    instance.render_stop_event.set()
    instance.render_event.set()
    if hasattr(instance, "render_thread"):
        instance.render_thread.join(timeout=3)
        assert not instance.render_thread.is_alive(), "Render worker did not stop"


def set_grid_defaults(node, values=None, parameter_type=2):
    parameters = dict(values or GRID_PARAMETERS)
    future = Future()
    node.grid_defaults_future = future
    future.set_result(SimpleNamespace(values=[
        SimpleNamespace(type=parameter_type, integer_value=parameters[name])
        for name in node.grid_default_names
    ]))
    node.initial_grid_defaults_response(future)
    return future


def image_message(value=0, shape=(480, 640, 3), encoding="bgr8", **kwargs):
    return SimpleNamespace(
        image=np.full(shape, value, dtype=np.uint8), encoding=encoding, **kwargs
    )


def test_first_grid_uses_actual_parameters_and_resolution(node):
    node.active_stream = "grid"
    node.process_rgb(image_message(), "grid", 0)
    assert "grid" not in node.frames
    assert node.preview_grid_parameters == {}
    set_grid_defaults(node)
    node.process_rgb(image_message(), "grid", node.render_revision)
    decoded = cv2.imdecode(np.frombuffer(node.frames["grid"], np.uint8), 1)
    assert decoded.shape == (240, 320, 3)
    metadata = node.frame_metadata["grid"]
    assert metadata["grid_preview"] == GRID_PARAMETERS
    assert metadata["preview_features"] == {
        "V": [100] * 9, "L": [161] * 4, "R": [161] * 4,
        "V_NO_HIT": 100, "L_NO_HIT": 161, "R_NO_HIT": 161,
    }
    assert node.last_error == ""


def test_depth_jpeg_and_statistics_use_the_same_sensor_message(node):
    node.active_stream = "depth"
    node.depth_rois[0] = {"x1": 20, "y1": 20, "x2": 29, "y2": 29}
    depth_m = np.full((480, 640), 1.5, np.float32)
    node.process_depth(SimpleNamespace(image=depth_m, encoding="32FC1"), 0)
    statistics = node.frame_metadata["depth"]["depth_roi_stats"]
    assert statistics[0]["count"] == 100
    assert statistics[0]["distance_mean_mm"] == 1500
    assert set(statistics[0]) == {
        "count", "distance_min_mm", "distance_mean_mm", "distance_max_mm",
    }
    assert statistics[1] is None
    decoded = cv2.imdecode(np.frombuffer(node.frames["depth"], np.uint8), 1)
    assert int(decoded[200, 200, 0]) == 159
    assert node.depth_roi_stats == statistics


def test_many_rois_zero_invalid_pixels_and_metadata_header_size(node):
    node.active_stream = "depth"
    node.depth_rois = [{"y1": 0, "y2": 9, "x1": i * 10, "x2": i * 10 + 9}
                       for i in range(16)]
    data = np.zeros((480, 640), np.float32)
    data[0:10, 10:20] = 1.5
    data[0:10, 20:30] = np.nan
    data[0:10, 30:40] = np.inf
    data[0:10, 40:50] = -1.0
    node.process_depth(SimpleNamespace(image=data, encoding="32FC1"), 0)
    metadata = node.frame_metadata["depth"]
    assert len(metadata["depth_roi_stats"]) == 16
    assert metadata["depth_roi_stats"][1]["distance_mean_mm"] == 1500
    assert "brightness" not in json.dumps(metadata)
    for index in (0, 2, 3, 4, 15):
        assert metadata["depth_roi_stats"][index] == {
            "count": 0,
            "distance_min_mm": 0.0, "distance_mean_mm": 0.0,
            "distance_max_mm": 0.0,
        }
    assert len(json.dumps(metadata).encode("utf-8")) < 8190
    assert node.last_error == ""


@pytest.mark.parametrize("encoding", ["16UC1", "32FC1"])
def test_depth_render_converts_units_resizes_and_leaves_source_unchanged(node, encoding):
    node.active_stream = "depth"
    dtype, value = (np.uint16, 1500) if encoding == "16UC1" else (np.float32, 1.5)
    data = np.full((240, 320), value, dtype=dtype)
    data[:60] = 0
    if encoding == "32FC1":
        data[:10] = np.nan
        data[10:20] = np.inf
        data[20:30] = -1.0
        data[30:40] = np.finfo(np.float32).max
    original = data.copy()
    node.depth_rois = [{"y1": 200, "y2": 209, "x1": 200, "x2": 209}]
    node.process_depth(SimpleNamespace(image=data, encoding=encoding), 0)
    decoded = cv2.imdecode(np.frombuffer(node.frames["depth"], np.uint8), 1)
    assert decoded.shape == (480, 640, 3)
    assert decoded[5:110, 400:500].max() == 0
    assert decoded[300, 400, 0] == 159
    assert node.depth_roi_stats[0]["distance_mean_mm"] == 1500
    np.testing.assert_equal(data, original)
    assert node.last_error == ""


@pytest.mark.parametrize("encoding", ["16UC1", "32FC1"])
@pytest.mark.parametrize("invalid_value", [-1.0, 0.0, -999.0, -0.5])
def test_depth_range_boundaries_invalid_sentinel_and_valid_roi_counts(node, encoding, invalid_value):
    node.active_stream = "depth"
    node.depth_invalid_value_mm = invalid_value
    # Four invalid pixels followed by four valid pixels, including saturation.
    values_mm = [0, 1, 100, 199, 200, 1000, 4000, 4001]
    if encoding == "16UC1":
        data = np.zeros((480, 640), np.uint16)
        data[20, 20:28] = values_mm
    else:
        data = np.zeros((480, 640), np.float32)
        data[20, 20:28] = np.asarray(values_mm, np.float32) / 1000.0
    original = data.copy()
    node.depth_rois = [
        {"y1": 20, "y2": 20, "x1": 20, "x2": 27},
        {"y1": 20, "y2": 20, "x1": 20, "x2": 23},
        {"y1": 20, "y2": 20, "x1": 24, "x2": 24},
        {"y1": 20, "y2": 20, "x1": 27, "x2": 27},
    ]
    node.process_depth(SimpleNamespace(image=data, encoding=encoding), 0)
    assert node.depth_roi_stats == [
        {"count": 4, "distance_min_mm": 200, "distance_mean_mm": 2300,
         "distance_max_mm": 4000},
        {"count": 0, "distance_min_mm": invalid_value,
         "distance_mean_mm": invalid_value, "distance_max_mm": invalid_value},
        {"count": 1, "distance_min_mm": 200, "distance_mean_mm": 200,
         "distance_max_mm": 200},
        {"count": 1, "distance_min_mm": 4000, "distance_mean_mm": 4000,
         "distance_max_mm": 4000},
    ]
    np.testing.assert_equal(data, original)
    assert node.last_error == ""


def test_depth_nonfinite_and_float_overflow_remain_unknown_not_maximum(node):
    node.active_stream = "depth"
    data = np.zeros((480, 640), np.float32)
    data[10, 10:15] = [np.nan, np.inf, -np.inf, -1.0, np.finfo(np.float32).max]
    node.depth_rois = [{"y1": 10, "y2": 10, "x1": 10, "x2": 14}]
    node.process_depth(SimpleNamespace(image=data, encoding="32FC1"), 0)
    assert node.depth_roi_stats == [{
        "count": 0, "distance_min_mm": 0.0,
        "distance_mean_mm": 0.0, "distance_max_mm": 0.0,
    }]
    assert node.last_error == ""


def test_depth_maximum_distance_is_separate_from_display_maximum(node):
    node.active_stream = "depth"
    node.depth_rois = [{"y1": 0, "y2": 0, "x1": 0, "x2": 0}]
    node.depth_display_max_mm = 4000
    node.depth_max_mm = 5000.0
    captured = []
    node.store_frame = lambda stream, image, metadata, revision: captured.append((image, metadata))
    data = np.zeros((480, 640), np.uint16)
    data[:, :160] = 1000
    data[:, 160:320] = 2000
    data[:, 320:480] = 3000
    data[:, 480:] = 4500
    data[0, 0] = 4500
    node.process_depth(SimpleNamespace(image=data, encoding="16UC1"), 0)
    image, metadata = captured[0]
    assert image[300, [80, 240, 400, 560], 0].tolist() == [191, 127, 63, 0]
    assert metadata["depth_roi_stats"][0]["distance_mean_mm"] == 4500
    assert node.last_error == ""


def test_depth_custom_minimum_maximum_and_unsigned_large_distance(node):
    node.active_stream = "depth"
    node.depth_min_mm = 500.0
    node.depth_max_mm = 2500.0
    data = np.zeros((480, 640), np.uint16)
    data[10, 10:14] = [499, 500, 2501, 65535]
    node.depth_rois = [{"y1": 10, "y2": 10, "x1": 10, "x2": 13}]
    node.process_depth(SimpleNamespace(image=data, encoding="16UC1"), 0)
    assert node.depth_roi_stats == [{
        "count": 3, "distance_min_mm": 500,
        "distance_mean_mm": 1833, "distance_max_mm": 2500,
    }]
    assert node.get_status()["depth_min_mm"] == 500.0
    assert node.get_status()["depth_max_mm"] == 2500.0
    assert node.get_status()["depth_invalid_value_mm"] == 0.0


@pytest.mark.parametrize("minimum,maximum,invalid", [
    (200.0, 4000.0, -1.0), (0.0, 1000.0, 0.0),
    (0.5, 1500.5, -999.0), (200.0, 4000.0, -0.5),
])
def test_depth_parameters_accept_finite_nonpositive_sentinels(node, minimum, maximum, invalid):
    assert node.validate_depth_parameters(minimum, maximum, invalid) == (minimum, maximum, invalid)


@pytest.mark.parametrize("minimum,maximum,invalid", [
    (-1.0, 4000.0, -1.0), (200.0, 200.0, -1.0), (4000.0, 200.0, -1.0),
    (200.0, np.inf, -1.0), (np.nan, 4000.0, -1.0),
    (200.0, 4000.0, 4000.0), (200.0, 4000.0, np.nan),
    (200.0, 4000.0, -np.inf), (200.0, 4000.0, -1e40),
    (200.0, 1e40, -1.0), (0.0, 1e-50, -1.0),
    (200.0, 4000.0, -1e-50), (200.0, 200.00000000001, -1.0),
])
def test_depth_parameters_reject_invalid_ranges_and_unsafe_sentinels(node, minimum, maximum, invalid):
    with pytest.raises(ValueError):
        node.validate_depth_parameters(minimum, maximum, invalid)


@pytest.mark.parametrize("data,encoding", [
    (np.zeros((2, 2), np.uint8), "mono8"),
    (np.zeros((2, 2), np.uint16), "32FC1"),
    (np.zeros((2, 2), np.float32), "16UC1"),
    (np.zeros((2, 2, 3), np.uint16), "16UC1"),
    (np.zeros((0, 2), np.uint16), "16UC1"),
])
def test_bad_depth_encoding_or_shape_rejects_frame_and_recovers(node, data, encoding):
    node.active_stream = "depth"
    node.process_depth(SimpleNamespace(image=data, encoding=encoding), 0)
    assert "depth" not in node.frames
    assert node.last_error.startswith("Depth:")
    node.process_depth(SimpleNamespace(
        image=np.full((480, 640), 1500, np.uint16), encoding="16UC1",
    ), 0)
    assert node.frame_versions["depth"] == 1


def test_depth_api_saves_restores_and_clears_multiple_rois(node):
    async def run():
        app = web.Application(middlewares=[node.api_json_middleware])
        app.router.add_post("/api/depth", node.handle_depth)
        async with TestClient(TestServer(app)) as client:
            rois = [{"y1": i, "y2": i, "x1": 0, "x2": 639} for i in range(4)]
            response = await client.post("/api/depth", json={"rois": rois})
            assert response.status == 200
            body = await response.json()
            assert body["saved"] is True
            assert body["depth_rois"] == rois
            assert body["depth_rois_revision"] == 1
            assert node.depth_rois == rois
            assert node.depth_roi_stats == [None] * 4
            load = node.apply_depth_rois.__globals__["load_depth_rois"]
            assert load(node.depth_roi_config_path) == rois
            # Same load function is used during a new node's construction.
            node.depth_rois = load(node.depth_roi_config_path)
            assert node.get_status()["depth_rois"] == rois
            assert node.get_status()["max_depth_rois"] == 16
            response = await client.post("/api/depth", json={"rois": []})
            assert response.status == 200
            assert load(node.depth_roi_config_path) == []
    asyncio.run(run())


def test_depth_api_invalid_input_or_save_failure_preserves_state(node, monkeypatch):
    async def run():
        app = web.Application(middlewares=[node.api_json_middleware])
        app.router.add_post("/api/depth", node.handle_depth)
        async with TestClient(TestServer(app)) as client:
            rois = [{"y1": 10, "y2": 20, "x1": 30, "x2": 40}]
            response = await client.post("/api/depth", json={"rois": rois})
            assert response.status == 200
            before = node.depth_roi_config_path.read_bytes()
            for invalid in ([{"y1": 1}], rois * 17, {"rois": rois}):
                response = await client.post("/api/depth", json={"rois": invalid})
                assert response.status == 400
                assert node.depth_roi_config_path.read_bytes() == before
                assert node.depth_rois == rois
            globals_ = node.apply_depth_rois.__globals__
            save = globals_["save_depth_rois"]

            def fail_save(*_):
                raise PermissionError("disk not writable")

            monkeypatch.setitem(globals_, "save_depth_rois", fail_save)
            response = await client.post("/api/depth", json={"rois": []})
            assert response.status == 500
            assert node.depth_rois == rois
            assert node.depth_rois_revision == 1
            assert node.depth_roi_config_path.read_bytes() == before
            assert node.last_error
            monkeypatch.setitem(globals_, "save_depth_rois", save)
            response = await client.post("/api/depth", json={"rois": []})
            assert response.status == 200
            assert node.depth_rois_revision == 2
            assert node.last_error == ""
    asyncio.run(run())


def test_roi_change_discards_frame_and_stats_from_old_revision(node):
    node.active_stream = "depth"
    old_revision = node.render_revision
    node.apply_depth_rois([{"y1": 0, "y2": 0, "x1": 0, "x2": 0}])
    message = SimpleNamespace(image=np.full((480, 640), 1500, np.uint16), encoding="16UC1")
    node.process_depth(message, old_revision)
    assert "depth" not in node.frames
    node.process_depth(message, node.render_revision)
    assert node.frame_metadata["depth"]["depth_rois_revision"] == 1
    assert node.frame_metadata["depth"]["depth_roi_stats"][0]["count"] == 1


def test_slow_render_does_not_queue_old_camera_messages(node):
    entered = threading.Event()
    release = threading.Event()
    second_stored = threading.Event()
    processed = []
    original_store = node.store_frame

    def slow_bridge(message, encoding):
        processed.append(message.sequence)
        if message.sequence == 1:
            entered.set()
            assert release.wait(3), "Test did not release renderer"
        return message.image

    def observe_store(*args, **kwargs):
        original_store(*args, **kwargs)
        if len(processed) >= 2:
            second_stored.set()

    node.bridge.imgmsg_to_cv2 = slow_bridge
    node.store_frame = observe_store
    node.render_thread = threading.Thread(target=node.render_latest_frames)
    node.render_thread.start()
    try:
        node.rgb_callback(image_message(sequence=1))
        assert entered.wait(2)
        for sequence in range(2, 51):
            node.rgb_callback(image_message(value=sequence, sequence=sequence))
        assert node.source_versions["rgb"] == 50
        assert len(node.latest_messages) == 1
        release.set()
        assert second_stored.wait(3)
        assert processed == [1, 50]
        decoded = cv2.imdecode(np.frombuffer(node.frames["rgb"], np.uint8), 1)
        assert abs(int(decoded[200, 200, 0]) - 50) <= 1
    finally:
        release.set()


def test_changed_configuration_rejects_inflight_jpeg_and_numbers(node):
    node.active_stream = "grid"
    set_grid_defaults(node)
    old_revision = node.render_revision
    original_bridge = node.bridge.imgmsg_to_cv2

    def change_configuration_during_conversion(message, encoding):
        node.render_revision += 1
        return original_bridge(message, encoding)

    node.bridge.imgmsg_to_cv2 = change_configuration_during_conversion
    node.process_rgb(image_message(), "grid", old_revision)
    assert "grid" not in node.frames
    assert node.preview_features["V"] == []
    assert node.frame_versions["grid"] == 0


@pytest.mark.parametrize("fault", ["wrong_type", "incomplete", "invalid_roi"])
def test_bad_initial_defaults_are_rejected_then_recover(node, fault):
    if fault == "wrong_type":
        set_grid_defaults(node, parameter_type=3)
    elif fault == "invalid_roi":
        set_grid_defaults(node, {**GRID_PARAMETERS, "roi_t": 241})
    else:
        future = Future()
        node.grid_defaults_future = future
        future.set_result(SimpleNamespace(values=[]))
        node.initial_grid_defaults_response(future)
    assert not node.grid_defaults_loaded
    assert node.preview_grid_parameters == {}
    assert node.grid_defaults_future is None
    set_grid_defaults(node)
    assert node.grid_defaults_loaded
    assert node.preview_grid_parameters == GRID_PARAMETERS


def test_parameter_request_timeout_retries_and_ignores_old_completion(node):
    old_future = Future()
    old_future.set_running_or_notify_cancel()
    new_future = Future()
    node.grid_defaults_future = old_future
    node.grid_defaults_requested_at = time.monotonic() - 3.0
    node.grid_defaults_client = SimpleNamespace(
        service_is_ready=lambda: True,
        call_async=Mock(return_value=new_future),
        remove_pending_request=Mock(),
    )
    node.request_initial_grid_defaults()
    node.grid_defaults_client.remove_pending_request.assert_called_once_with(old_future)
    assert node.grid_defaults_future is new_future
    assert node.grid_defaults_client.call_async.call_args.args[0].names == list(GRID_PARAMETERS)
    old_future.set_result(SimpleNamespace(values=[]))
    node.initial_grid_defaults_response(old_future)
    assert node.grid_defaults_future is new_future
    assert not node.grid_defaults_loaded
    new_future.set_result(SimpleNamespace(values=[
        SimpleNamespace(type=2, integer_value=GRID_PARAMETERS[name])
        for name in node.grid_default_names
    ]))
    assert node.grid_defaults_loaded


def test_refresh_updates_defaults_cache_without_overwriting_user_preview(node):
    set_grid_defaults(node)
    custom = {**GRID_PARAMETERS, "rows": 7}
    node.preview_grid_parameters = custom
    original_revision = node.render_revision
    updated_defaults = {**GRID_PARAMETERS, "cols": 11}
    set_grid_defaults(node, updated_defaults)
    assert node.grid_node_parameters == updated_defaults
    assert node.preview_grid_parameters == custom
    assert node.render_revision == original_revision


def test_http_frame_bytes_metadata_and_configuration_revision(node):
    async def scenario():
        application = web.Application(middlewares=[node.api_json_middleware])
        application.router.add_get("/frame/active.jpg", node.handle_active_frame)
        application.router.add_get("/api/grid/defaults", node.handle_grid_defaults)
        application.router.add_post("/api/view", node.handle_view)
        application.router.add_post("/api/grid", node.handle_grid)
        async with TestClient(TestServer(application)) as client:
            response = await client.get("/api/grid/defaults")
            assert response.status == 503
            response = await client.post("/api/grid", json=GRID_PARAMETERS)
            assert response.status == 503
            set_grid_defaults(node)
            response = await client.post("/api/view", json={"stream": "grid"})
            assert response.status == 200
            node.process_rgb(image_message(), "grid", node.render_revision)
            response = await client.get("/frame/active.jpg?stream=grid")
            assert response.status == 200
            jpeg = await response.read()
            metadata = json.loads(response.headers["X-Frame-Metadata"])
            assert jpeg == node.frames["grid"]
            assert metadata == node.frame_metadata["grid"]
            assert cv2.imdecode(np.frombuffer(jpeg, np.uint8), 1).shape == (240, 320, 3)
            response = await client.get(
                "/frame/active.jpg", params={"stream": "grid", "after": metadata["version"]}
            )
            assert response.status == 204
            response = await client.get("/frame/active.jpg?stream=depth")
            assert response.status == 409
            response = await client.post(
                "/api/grid", json={**GRID_PARAMETERS, "rows": 6}
            )
            assert response.status == 200
            response = await client.get("/frame/active.jpg?stream=grid")
            assert response.status == 204
            node.process_rgb(image_message(), "grid", node.render_revision)
            response = await client.get("/frame/active.jpg?stream=grid")
            assert response.status == 200
            refreshed = json.loads(response.headers["X-Frame-Metadata"])
            assert len(refreshed["preview_features"]["L"]) == 6
            assert refreshed["revision"] > metadata["revision"]
            response = await client.get("/api/grid/defaults")
            assert (await response.json())["parameters"] == GRID_PARAMETERS
    asyncio.run(scenario())


def test_worker_recovers_after_unexpected_renderer_failure(node):
    failed = threading.Event()
    recovered = threading.Event()
    original_process = node.process_rgb

    def fail_once(message, stream, revision):
        if message.sequence == 1:
            failed.set()
            raise RuntimeError("synthetic renderer failure")
        original_process(message, stream, revision)
        recovered.set()

    node.process_rgb = fail_once
    node.render_thread = threading.Thread(target=node.render_latest_frames)
    node.render_thread.start()
    node.rgb_callback(image_message(sequence=1))
    assert failed.wait(2)
    node.rgb_callback(image_message(value=100, sequence=2))
    assert recovered.wait(3)
    assert node.render_thread.is_alive()
    assert node.frame_versions["rgb"] == 1
    assert "synthetic renderer failure" in node.last_error


def test_expired_control_request_cannot_start_vehicle_later(node):
    expired = {
        "action": "start", "event": threading.Event(), "result": None,
        "deadline": time.monotonic() - 0.01,
    }
    node.publish_driving_enabled = Mock()
    node.control_queue.put(expired)
    node.process_queued_requests()
    node.publish_driving_enabled.assert_not_called()
    assert node.paused
    assert expired["event"].is_set()
    assert expired["result"]["ok"] is False


def test_http_rejects_bad_input_without_corrupting_view(node):
    async def scenario():
        application = web.Application(middlewares=[node.api_json_middleware])
        application.router.add_get("/api/status", node.handle_status)
        application.router.add_post("/api/view", node.handle_view)
        application.router.add_post("/api/control", node.handle_control)
        async with TestClient(TestServer(application)) as client:
            for payload in ([], None, 42, {"stream": []}, {"stream": {}}):
                response = await client.post("/api/view", json=payload)
                assert response.status == 400
            response = await client.post("/api/view", data="{not JSON")
            assert response.status == 400
            response = await client.post("/api/control", json={"action": []})
            assert response.status == 400
            response = await client.get("/api/status")
            status = await response.json()
            assert status["active_stream"] == "rgb"
            assert status["instance_id"] == "test-instance"
            assert node.control_queue.empty()
    asyncio.run(scenario())


def test_decision_stop_reason_is_exposed_without_changing_requested_state(node):
    node.paused = False
    node.decision_status_callback(SimpleNamespace(data=json.dumps({
        "driving_enabled": False, "reason": "판단 함수 오류",
    })))
    status = node.get_status()
    assert status["paused"] is False
    assert status["decision_status"] == {
        "driving_enabled": False, "reason": "판단 함수 오류",
    }
    node.decision_status_callback(SimpleNamespace(data="[]"))
    assert node.get_status()["decision_status"] == status["decision_status"]
    assert "Invalid decision status" in node.last_error


def test_web_bind_failure_is_reported_instead_of_false_ready(node):
    async def fail_start():
        raise OSError("Address already in use")

    node.web_loop = asyncio.new_event_loop()
    node.web_runner = None
    node.web_ready_event = threading.Event()
    node.web_start_error = None
    node.start_web_server = fail_start
    worker = threading.Thread(target=node.run_web_server)
    worker.start()
    assert node.web_ready_event.wait(2)
    worker.join(timeout=2)
    assert not worker.is_alive()
    assert node.web_start_error == "Address already in use"
    assert "Web server" in node.last_error
    assert node.web_loop.is_closed()
