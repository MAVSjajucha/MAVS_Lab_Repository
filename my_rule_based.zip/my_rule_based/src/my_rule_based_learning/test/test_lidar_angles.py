"""LiDAR geometry regressions, runnable with unittest without a ROS install.

Load the production geometry methods from the syntax tree so testing them does
not start a ROS node or require ROS/OpenCV bindings. The renderer uses a drawing
recorder; NumPy is needed only for the renderer tests.
"""

import ast
import math
from pathlib import Path
from types import SimpleNamespace
import unittest

try:
    import numpy as np
except ImportError:
    np = None


class DrawingRecorder:
    FONT_HERSHEY_SIMPLEX = 0
    LINE_AA = 16

    def __init__(self):
        self.circles = []
        self.lines = []
        self.labels = []

    def circle(self, image, center, radius, color, *args):
        self.circles.append((center, radius, color))

    def line(self, image, start, end, color, *args):
        self.lines.append((start, end, color))

    def getTextSize(self, text, *args):
        return (len(text) * 7, 10), 0

    def putText(self, image, text, origin, *args):
        self.labels.append((text, origin))

    def fillConvexPoly(self, *args):
        pass


def load_lidar_methods():
    source_path = (
        Path(__file__).resolve().parents[1]
        / "my_rule_based_learning"
        / "vis_node.py"
    )
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    original = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "VisNode"
    )
    names = {
        "normalize_angle_deg", "scan_angle_to_lidar_deg", "lidar_plot_point",
        "zone_midpoint_deg", "angle_in_zone", "render_lidar",
    }
    methods = [
        node for node in original.body
        if isinstance(node, ast.FunctionDef) and node.name in names
    ]
    assert len(methods) == len(names), "A production LiDAR method is missing"
    isolated = ast.Module(
        body=[
            ast.ImportFrom(
                module="__future__",
                names=[ast.alias(name="annotations")],
                level=0,
            ),
            ast.ClassDef(
                name="VisNode", bases=[], keywords=[], body=methods,
                decorator_list=[],
            ),
        ],
        type_ignores=[],
    )
    recorder = DrawingRecorder()
    namespace = {"math": math, "np": np, "cv2": recorder}
    exec(compile(ast.fix_missing_locations(isolated), str(source_path), "exec"),
         namespace)
    return namespace["VisNode"], recorder


class LidarAngleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry, cls.drawing = load_lidar_methods()

    def test_cardinal_angles_with_default_mounting_offset(self):
        for raw_degrees, expected in (
            (-180, -180), (-90, 90), (0, 0), (90, -90), (180, -180)
        ):
            with self.subTest(raw_degrees=raw_degrees):
                self.assertAlmostEqual(
                    self.geometry.scan_angle_to_lidar_deg(
                        math.radians(raw_degrees), 180.0
                    ),
                    expected,
                )

    def test_requested_cardinal_angles_match_screen_directions(self):
        for degrees, expected in (
            (-180, (320, 140)), (180, (320, 140)),
            (-90, (420, 240)), (0, (320, 340)), (90, (220, 240)),
        ):
            with self.subTest(degrees=degrees):
                self.assertEqual(
                    self.geometry.lidar_plot_point(degrees, 100, 320, 240),
                    expected,
                )

    def test_mounting_correction_keeps_existing_physical_point_positions(self):
        for offset in (-360, -180, -27.5, 0, 91, 180, 360):
            for raw_degrees in range(-180, 181, 7):
                raw_angle = math.radians(raw_degrees)
                previous_angle = raw_angle + math.radians(offset)
                expected = (
                    round(320 - math.sin(previous_angle) * 137.25),
                    round(240 - math.cos(previous_angle) * 137.25),
                )
                angle = self.geometry.scan_angle_to_lidar_deg(raw_angle, offset)
                self.assertEqual(
                    self.geometry.lidar_plot_point(angle, 137.25, 320, 240),
                    expected,
                )

    def test_front_zone_crosses_minus_plus_180_seam(self):
        for start, end in ((170, -170), (-170, 170)):
            self.assertEqual(self.geometry.zone_midpoint_deg(start, end), -180)
            for angle in (-180, -175, -170, 170, 175, 180):
                self.assertTrue(self.geometry.angle_in_zone(angle, start, end))
            for angle in (-169, -90, 0, 90, 169):
                self.assertFalse(self.geometry.angle_in_zone(angle, start, end))

    def test_half_circle_ranges_match_right_and_left_in_both_orders(self):
        for start, end, inside, outside in (
            (-180, 0, -90, 90), (0, -180, -90, 90),
            (0, 180, 90, -90), (180, 0, 90, -90),
        ):
            with self.subTest(start=start, end=end):
                self.assertTrue(self.geometry.angle_in_zone(inside, start, end))
                self.assertFalse(self.geometry.angle_in_zone(outside, start, end))
                self.assertEqual(self.geometry.zone_midpoint_deg(start, end), inside)

    def test_rear_zone_is_centered_on_zero(self):
        self.assertEqual(self.geometry.zone_midpoint_deg(-20, 20), 0)
        self.assertTrue(self.geometry.angle_in_zone(0, -20, 20))
        self.assertFalse(self.geometry.angle_in_zone(180, -20, 20))

    def test_full_circle_and_single_angle_zones_are_preserved(self):
        for start, end in ((-180, 180), (180, -180)):
            for angle in range(-180, 181):
                self.assertTrue(self.geometry.angle_in_zone(angle, start, end))
        self.assertTrue(self.geometry.angle_in_zone(-180, 180, 180))
        self.assertFalse(self.geometry.angle_in_zone(0, 180, 180))

    @unittest.skipIf(np is None, "Renderer tests require NumPy")
    def test_renderer_zones_labels_and_points_share_the_new_coordinates(self):
        scan = SimpleNamespace(
            angle_min=-math.pi,
            angle_increment=math.pi / 2,
            ranges=[0.2, 0.4, 0.6, 0.8],
            range_min=0.05,
            range_max=10.0,
        )
        zones = [
            {"start_deg": 170, "end_deg": -170},
            {"start_deg": -100, "end_deg": -80},
            {"start_deg": -10, "end_deg": 10},
            {"start_deg": 80, "end_deg": 100},
        ]
        self.drawing.circles.clear()
        self.drawing.lines.clear()
        self.drawing.labels.clear()
        image, statistics = self.geometry.render_lidar(scan, 1000, zones, 180)
        self.assertEqual(image.shape, (480, 640, 3))
        self.assertEqual([row["mean_mm"] for row in statistics], [200, 800, 600, 400])
        self.assertEqual([row["count"] for row in statistics], [1, 1, 1, 1])
        points = [center for center, radius, _ in self.drawing.circles if radius == 3]
        self.assertEqual(points, [(320, 199), (238, 240), (320, 363), (484, 240)])
        labels = dict(self.drawing.labels)
        self.assertIn("-180 / 180 FRONT", labels)
        self.assertIn("-90 RIGHT", labels)
        self.assertIn("0 REAR", labels)
        self.assertIn("+90 LEFT", labels)
        self.assertLess(labels["Z1"][1], 240)
        self.assertGreater(labels["Z2"][0], 320)
        self.assertGreater(labels["Z3"][1], 240)
        self.assertLess(labels["Z4"][0], 320)
        for index, zone in enumerate(zones):
            for boundary_index, degrees in enumerate(zone.values()):
                self.assertEqual(
                    self.drawing.lines[index * 2 + boundary_index][1],
                    self.geometry.lidar_plot_point(degrees, 205, 320, 240),
                )

    @unittest.skipIf(np is None, "Renderer tests require NumPy")
    def test_statistics_include_valid_returns_beyond_display_range(self):
        scan = SimpleNamespace(
            angle_min=-math.pi,
            angle_increment=math.pi / 8,
            ranges=[0.2, 0.8, float("nan"), float("inf"), 0.01, 11.0],
            range_min=0.05,
            range_max=10.0,
        )
        zones = [{"start_deg": -180, "end_deg": 180}] + [
            {"start_deg": None, "end_deg": None} for _ in range(3)
        ]
        self.drawing.circles.clear()
        _, statistics = self.geometry.render_lidar(scan, 500, zones, 180)
        self.assertEqual(statistics[0], {
            "count": 2, "mean_mm": 500, "median_mm": 500,
            "min_mm": 200, "max_mm": 800,
        })
        self.assertEqual(statistics[1:], [None, None, None])
        points = [center for center, radius, _ in self.drawing.circles if radius == 3]
        self.assertEqual(points, [(320, 158)])


if __name__ == "__main__":
    unittest.main()
