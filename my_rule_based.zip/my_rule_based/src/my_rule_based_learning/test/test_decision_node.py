"""Exercise the real decision methods with a small ROS message/publisher shim."""
import ast
import json
import math
import threading
import time
import traceback
from collections.abc import Iterator
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


class Node:
    def destroy_node(self):
        self.destroyed = True
        return True


class Twist:
    def __init__(self):
        self.linear = SimpleNamespace(x=0.0)
        self.angular = SimpleNamespace(z=0.0)


class Publisher:
    def __init__(self):
        self.messages = []

    def publish(self, message):
        self.messages.append(message)


class Logger:
    def __init__(self):
        self.errors = []

    def error(self, message):
        self.errors.append(message)

    def info(self, _message):
        pass


SOURCE = Path(__file__).parents[1] / "my_rule_based_learning" / "decision_node.py"
TREE = ast.parse(SOURCE.read_text(encoding="utf-8"))
CLASS = next(node for node in TREE.body if isinstance(node, ast.ClassDef) and node.name == "DecisionNode")
NAMESPACE = dict(Node=Node, Twist=Twist, math=math, time=time, threading=threading,
                 traceback=traceback, deepcopy=deepcopy, np=np, json=json, Iterator=Iterator,
                 String=lambda **kwargs: SimpleNamespace(**kwargs))
exec(compile(ast.Module(body=[CLASS], type_ignores=[]), str(SOURCE), "exec"), NAMESPACE)
DecisionNode = NAMESPACE["DecisionNode"]


def make_node(mode="lane"):
    node = DecisionNode.__new__(DecisionNode)
    node.STATE_LOCK = threading.RLock()
    node.CONTROL_GENERATION = 0
    node.DRIVING_ENABLED = True
    node.MODE = mode
    node.SENSOR_TIMEOUT_SEC = 1.0
    node.RULE_TIMEOUT_SEC = 1.0
    node.SENSOR_TIMES = {name: time.monotonic() for name in ("lane", "depth", "lidar")}
    node.DEPTH_GENERATION = 0
    node.RULE_STARTED = None
    node.RULE_ITERATOR = None
    node.RETIRED_RULE_ITERATORS = []
    node.RULE_TIMEOUT_REPORTED = False
    node.LAST_ERROR_TIME = float("-inf")
    node.STOP_REASON = ""
    node.LAST_STATUS = None
    node.DECISION_STATUS_PUBLISHER = Publisher()
    node.CMD_PUBLISHER = Publisher()
    node.MAX_LINEAR_MPS = 0.5
    node.MAX_ANGULAR_RPS = 0.5
    node.DEPTH_MIN_MM = 200.0
    node.DEPTH_MAX_MM = 4000.0
    node.DEPTH_INVALID_VALUE_MM = 0.0
    node.V, node.L, node.R = [1], [2], [3]
    node.DEPTH_IMAGE = np.ones((2, 2), dtype=np.uint16)
    node.SCAN = SimpleNamespace(ranges=[1.0])
    node.logger = Logger()
    node.get_logger = lambda: node.logger
    node.RULE_FUNCTION = lambda *_args: movement()
    return node


def movement():
    command = Twist()
    command.linear.x = 0.4
    return command


def test_fresh_inputs_publish_limited_command():
    node = make_node()
    node.timer_callback()
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.4


@pytest.mark.parametrize("mode,missing", [("lane", "lane"), ("depth", "depth"),
                                         ("lidar", "lidar"), ("integrated", "depth")])
def test_missing_or_stale_required_sensor_stops(mode, missing):
    node = make_node(mode)
    called = []
    node.RULE_FUNCTION = lambda *_args: called.append(True)
    for stamp in (None, time.monotonic() - 5):
        node.SENSOR_TIMES[missing] = stamp
        node.timer_callback()
        assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert not called


def test_unused_missing_sensors_do_not_block_lane():
    node = make_node()
    node.SENSOR_TIMES["depth"] = None
    node.SENSOR_TIMES["lidar"] = None
    node.timer_callback()
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.4


def test_rule_exception_pauses_and_reports_traceback_without_crash():
    node = make_node()
    def broken_rule(*_args):
        raise RuntimeError("student error")
    node.RULE_FUNCTION = broken_rule
    node.timer_callback()
    assert not node.DRIVING_ENABLED
    assert node.RULE_STARTED is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert "RuntimeError: student error" in node.logger.errors[0]


@pytest.mark.parametrize("invalid", [None, float("nan"), float("inf")])
def test_invalid_rule_return_or_nonfinite_command_stops(invalid):
    node = make_node()
    command = movement()
    command.linear.x = invalid
    node.RULE_FUNCTION = lambda *_args: None if invalid is None else command
    node.timer_callback()
    assert not node.DRIVING_ENABLED
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0


def test_stop_then_restart_discards_inflight_rule_result():
    node = make_node()
    started, release = threading.Event(), threading.Event()
    def blocked_rule(*_args):
        started.set()
        assert release.wait(2)
        return movement()
    node.RULE_FUNCTION = blocked_rule
    worker = threading.Thread(target=node.timer_callback)
    worker.start()
    assert started.wait(2)
    node.driving_enabled_callback(SimpleNamespace(data=False))
    node.driving_enabled_callback(SimpleNamespace(data=True))
    release.set()
    worker.join(2)
    assert not worker.is_alive()
    assert all(message.linear.x == 0 for message in node.CMD_PUBLISHER.messages)


def test_watchdog_stops_hung_rule_while_sensor_inputs_are_fresh():
    node = make_node()
    node.RULE_STARTED = time.monotonic() - 2
    node.watchdog_callback()
    assert not node.DRIVING_ENABLED
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert "rule_timeout_sec" in node.logger.errors[0]


def test_sensor_snapshots_are_private_to_student_rule():
    node = make_node("integrated")
    def mutate(v, left, right, depth, scan):
        v[0] = left[0] = right[0] = 99
        depth[:] = 99
        scan.ranges[0] = 99
        return movement()
    node.RULE_FUNCTION = mutate
    node.timer_callback()
    assert (node.V, node.L, node.R) == ([1], [2], [3])
    assert np.all(node.DEPTH_IMAGE == 1)
    assert node.SCAN.ranges == [1.0]


def test_depth_conversion_exception_invalidates_input_without_crash():
    node = make_node("depth")
    def fail(*_args, **_kwargs):
        raise RuntimeError("bad sensor image")
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=fail)
    node.depth_callback(object())
    assert node.DEPTH_IMAGE is None
    assert node.SENSOR_TIMES["depth"] is None
    node.timer_callback()
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0


def test_float_depth_is_converted_to_mm_and_invalid_pixels_remain_zero():
    node = make_node("depth")
    original = np.array([[1.25, float("nan"), float("inf"), -0.1, 0.0,
                          np.finfo(np.float32).max]], dtype=np.float32)
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: original)
    node.depth_callback(SimpleNamespace(encoding="32FC1"))
    np.testing.assert_array_equal(node.DEPTH_IMAGE, [[1250.0, 0.0, 0.0, 0.0, 0.0, 0.0]])
    assert node.DEPTH_IMAGE.dtype == np.float32
    assert node.SENSOR_TIMES["depth"] is not None
    assert np.isnan(original[0, 1])
    assert original[0, -1] == np.finfo(np.float32).max
    assert not np.shares_memory(original, node.DEPTH_IMAGE)


def test_uint16_depth_caps_far_values_and_owns_float32_copy():
    node = make_node("depth")
    original = np.array([[0, 1500, 65535]], dtype=np.uint16)
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: original)
    node.depth_callback(SimpleNamespace(encoding="16UC1"))
    np.testing.assert_array_equal(node.DEPTH_IMAGE, [[0, 1500, 4000]])
    assert node.DEPTH_IMAGE.dtype == np.float32
    np.testing.assert_array_equal(original, [[0, 1500, 65535]])
    assert not np.shares_memory(original, node.DEPTH_IMAGE)
    assert node.DEPTH_IMAGE.shape == original.shape


@pytest.mark.parametrize("encoding", ["16UC1", "32FC1"])
def test_depth_range_boundaries_are_distinct_from_missing_data(encoding):
    node = make_node("depth")
    pixels = np.array([[0, 1, 199, 200, 1000, 4000, 4001, 6000]], dtype=np.uint16)
    if encoding == "32FC1":
        pixels = pixels.astype(np.float32) / 1000.0
    original = pixels.copy()
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: pixels)
    node.depth_callback(SimpleNamespace(encoding=encoding))
    np.testing.assert_allclose(node.DEPTH_IMAGE, [[0, 0, 0, 200, 1000, 4000, 4000, 4000]])
    np.testing.assert_array_equal(pixels, original)
    assert node.DEPTH_IMAGE.dtype == np.float32


@pytest.mark.parametrize("encoding", ["16UC1", "32FC1"])
@pytest.mark.parametrize("sentinel", [-1.0, -9.5])
def test_custom_depth_parameters_affect_student_input(encoding, sentinel):
    node = make_node("depth")
    node.DEPTH_MIN_MM, node.DEPTH_MAX_MM, node.DEPTH_INVALID_VALUE_MM = (
        node.validate_depth_parameters(500.0, 2500.0, sentinel)
    )
    pixels = np.array([[0, 499, 500, 2500, 2501]], dtype=np.uint16)
    if encoding == "32FC1":
        pixels = pixels.astype(np.float32) / 1000.0
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: pixels)
    node.depth_callback(SimpleNamespace(encoding=encoding))
    np.testing.assert_allclose(node.student_arguments()[0], [[sentinel, sentinel, 500, 2500, 2500]])


@pytest.mark.parametrize("values", [
    (-1.0, 4000.0, -1.0), (200.0, 200.0, -1.0),
    (200.0, 100.0, -1.0), (200.0, 4000.0, 1.0),
    (float("nan"), 4000.0, -1.0), (200.0, float("inf"), -1.0),
    (200.0, 4000.0, float("nan")), (200.0, 4000.0, float("-inf")),
    (200.0, 1e40, -1.0), (200.0, 4000.0, -1e40),
    (200.0, 4000.0, -1e-50), (200.0, 200.0000001, -1.0),
    (1e-50, 4000.0, 0.0),
])
def test_invalid_depth_parameter_combinations_are_rejected(values):
    with pytest.raises(ValueError):
        DecisionNode.validate_depth_parameters(*values)


@pytest.mark.parametrize("old_conversion_fails", [False, True])
def test_delayed_old_depth_cannot_replace_or_clear_newer_frame(old_conversion_fails):
    node = make_node("depth")
    started, release = threading.Event(), threading.Event()
    old = SimpleNamespace(encoding="16UC1", pixels=np.full((2, 2), 500, np.uint16))
    new = SimpleNamespace(encoding="16UC1", pixels=np.full((2, 2), 1500, np.uint16))

    def convert(message, **_kwargs):
        if message is old:
            started.set()
            assert release.wait(2)
            if old_conversion_fails:
                raise ValueError("old malformed frame")
        return message.pixels

    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=convert)
    worker = threading.Thread(target=node.depth_callback, args=(old,))
    worker.start()
    try:
        assert started.wait(2)
        node.depth_callback(new)
        new_time = node.SENSOR_TIMES["depth"]
    finally:
        release.set()
        worker.join(2)
    assert not worker.is_alive()
    np.testing.assert_array_equal(node.DEPTH_IMAGE, new.pixels)
    assert node.SENSOR_TIMES["depth"] == new_time
    assert not node.logger.errors


def test_slow_conversion_does_not_refresh_an_old_receive_time(monkeypatch):
    node = make_node("depth")
    clock = [10.0]
    monkeypatch.setitem(NAMESPACE, "time", SimpleNamespace(monotonic=lambda: clock[0]))

    def convert(*_args, **_kwargs):
        clock[0] += 2.0
        return np.full((2, 2), 500, np.uint16)

    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=convert)
    node.depth_callback(SimpleNamespace(encoding="16UC1"))
    assert node.SENSOR_TIMES["depth"] == 10.0
    assert not node.inputs_ready(clock[0])


@pytest.mark.parametrize("encoding,pixels", [
    ("mono8", np.ones((2, 2), dtype=np.uint8)),
    ("16UC1", np.ones((2, 2), dtype=np.float32)),
    ("32FC1", np.ones((2, 2), dtype=np.float64)),
    ("16UC1", np.ones((2, 2, 3), dtype=np.uint16)),
    ("32FC1", np.ones((0, 2), dtype=np.float32)),
])
def test_unsupported_or_malformed_depth_invalidates_input(encoding, pixels):
    node = make_node("depth")
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: pixels)
    node.depth_callback(SimpleNamespace(encoding=encoding))
    assert node.DEPTH_IMAGE is None
    assert node.SENSOR_TIMES["depth"] is None


def test_status_changes_are_published_once_and_fault_reason_is_visible():
    node = make_node()
    node.watchdog_callback()
    node.watchdog_callback()
    assert len(node.DECISION_STATUS_PUBLISHER.messages) == 1
    assert json.loads(node.DECISION_STATUS_PUBLISHER.messages[-1].data) == {
        "driving_enabled": True, "reason": ""
    }
    node.SENSOR_TIMES["lane"] = None
    node.watchdog_callback()
    stale = json.loads(node.DECISION_STATUS_PUBLISHER.messages[-1].data)
    assert stale["driving_enabled"] is False
    assert "센서" in stale["reason"]
    node.SENSOR_TIMES["lane"] = time.monotonic()
    node.RULE_STARTED = time.monotonic() - 2
    node.watchdog_callback()
    timeout = json.loads(node.DECISION_STATUS_PUBLISHER.messages[-1].data)
    assert timeout["driving_enabled"] is False
    assert "초과" in timeout["reason"]
    node.RULE_STARTED = None
    node.driving_enabled_callback(SimpleNamespace(data=True))
    assert json.loads(node.DECISION_STATUS_PUBLISHER.messages[-1].data)["driving_enabled"] is True


@pytest.mark.parametrize("mode", ["depth", "integrated"])
def test_rule_retains_distance_snapshot_during_new_callback(mode):
    node = make_node(mode)
    first = np.array([[1000, 1500], [0, 65535]], dtype=np.uint16)
    next_frame = np.full((2, 2), 750, dtype=np.uint16)
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda message, **_kwargs: message.pixels)
    node.depth_callback(SimpleNamespace(encoding="16UC1", pixels=first))
    snapshots = []

    def rule(*args):
        depth = args[0] if mode == "depth" else args[3]
        node.depth_callback(SimpleNamespace(encoding="16UC1", pixels=next_frame))
        snapshots.append(depth)
        return movement()

    node.RULE_FUNCTION = rule
    node.timer_callback()
    assert len(snapshots) == 1
    depth = snapshots[0]
    np.testing.assert_array_equal(depth, [[1000, 1500], [0, 4000]])
    np.testing.assert_array_equal(node.DEPTH_IMAGE, next_frame)
    assert not np.shares_memory(depth, node.DEPTH_IMAGE)


@pytest.mark.parametrize("mode", ["depth", "integrated"])
def test_invalid_depth_clears_distance_in_student_snapshot(mode):
    node = make_node(mode)
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: np.zeros((1, 1)))
    node.depth_callback(SimpleNamespace(encoding="32FC1"))  # float64 is not 32FC1.
    args = node.student_arguments()
    assert len(args) == (1 if mode == "depth" else 5)
    depth = args[0] if mode == "depth" else args[3]
    assert depth is None
    assert node.SENSOR_TIMES["depth"] is None


def test_unedited_student_functions_still_return_stopped_twists():
    functions = [node for node in TREE.body if isinstance(node, ast.FunctionDef)
                 and node.name.startswith("decide_")]
    namespace = {"Twist": Twist}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(SOURCE), "exec"), namespace)
    node = make_node()
    for mode in ("lane", "depth", "lidar", "integrated"):
        node.MODE = mode
        command = namespace[f"decide_{mode}"](*node.student_arguments())
        assert command.linear.x == command.angular.z == 0.0


def test_generator_publishes_one_step_per_tick_then_uses_latest_sensor_input(monkeypatch):
    node = make_node("depth")
    clock = [10.0]
    monkeypatch.setitem(NAMESPACE, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    node.SENSOR_TIMES["depth"] = clock[0]
    node.DEPTH_IMAGE = np.full((2, 2), 500.0, dtype=np.float32)
    observations = []

    def rule(depth):
        distance = depth.mean()
        observations.append(distance)
        if distance < 700:
            for _ in range(10):
                command = Twist()
                command.linear.x = 0.04
                command.angular.z = 0.4
                yield command
        else:
            command = Twist()
            command.linear.x = 0.1
            yield command

    node.RULE_FUNCTION = rule
    for tick in range(11):
        clock[0] = 10.0 + tick / 10
        node.SENSOR_TIMES["depth"] = clock[0]
        if tick:
            node.DEPTH_IMAGE[:] = 1200
        node.timer_callback()
        assert len(node.CMD_PUBLISHER.messages) == tick + 1
        if tick < 10:
            assert observations == [500]
    commands = node.CMD_PUBLISHER.messages
    assert [(c.linear.x, c.angular.z) for c in commands[:10]] == [(0.04, 0.4)] * 10
    assert (commands[10].linear.x, commands[10].angular.z) == (0.1, 0.0)
    assert observations == [500, 1200]


def test_plain_iterator_of_twists_is_supported():
    node = make_node()
    calls = []

    def rule(*_args):
        calls.append(True)
        return iter([movement(), movement()])

    node.RULE_FUNCTION = rule
    node.timer_callback()
    node.timer_callback()
    assert len(calls) == 1
    assert [command.linear.x for command in node.CMD_PUBLISHER.messages] == [0.4, 0.4]


def queued_rule(node):
    snapshots = []

    def rule(*args):
        snapshot = len(snapshots) + 1
        snapshots.append(args)
        for _ in range(5):
            command = Twist()
            command.linear.x = 0.01 * snapshot
            yield command

    node.RULE_FUNCTION = rule
    node.timer_callback()
    assert node.RULE_ITERATOR is not None
    return snapshots


def test_web_pause_restart_discards_remaining_generator_steps():
    node = make_node()
    snapshots = queued_rule(node)
    node.driving_enabled_callback(SimpleNamespace(data=False))
    assert node.RULE_ITERATOR is None
    node.driving_enabled_callback(SimpleNamespace(data=True))
    node.timer_callback()
    assert len(snapshots) == 2
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.02


@pytest.mark.parametrize("interrupt", ["timer", "watchdog"])
def test_stale_sensor_cancels_sequence_before_fresh_data_returns(interrupt):
    node = make_node()
    snapshots = queued_rule(node)
    node.SENSOR_TIMES["lane"] = time.monotonic() - 5
    getattr(node, f"{interrupt}_callback")()
    assert node.RULE_ITERATOR is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    node.lane_callback(SimpleNamespace(v=[10], l=[20], r=[30]))
    node.timer_callback()
    assert len(snapshots) == 2
    assert snapshots[-1] == ([10], [20], [30])
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.02


@pytest.mark.parametrize("mode", ["lane", "depth", "lidar"])
def test_late_sensor_arrival_cancels_sequence_even_before_watchdog(mode):
    node = make_node(mode)
    snapshots = queued_rule(node)
    node.SENSOR_TIMES[mode] = time.monotonic() - 5
    if mode == "lane":
        node.lane_callback(SimpleNamespace(v=[10], l=[20], r=[30]))
    elif mode == "depth":
        pixels = np.full((2, 2), 500, np.uint16)
        node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda *_args, **_kwargs: pixels)
        node.depth_callback(SimpleNamespace(encoding="16UC1"))
    else:
        node.scan_callback(SimpleNamespace(ranges=[2.0]))
    assert node.RULE_ITERATOR is None
    node.timer_callback()
    assert len(snapshots) == 2
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.02


def test_invalid_depth_frame_cancels_sequence_even_if_next_frame_is_valid():
    node = make_node("depth")
    snapshots = queued_rule(node)
    node.BRIDGE = SimpleNamespace(imgmsg_to_cv2=lambda message, **_kwargs: message.pixels)
    node.depth_callback(SimpleNamespace(encoding="16UC1", pixels=np.zeros((2, 2))))
    assert node.RULE_ITERATOR is None
    node.depth_callback(SimpleNamespace(encoding="16UC1", pixels=np.full((2, 2), 500, np.uint16)))
    node.timer_callback()
    assert len(snapshots) == 2
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.02


def test_empty_generator_is_invoked_once_then_pauses():
    node = make_node()
    calls = []

    def empty(*_args):
        calls.append(True)
        yield from ()

    node.RULE_FUNCTION = empty
    node.timer_callback()
    assert len(calls) == 1
    assert not node.DRIVING_ENABLED
    assert node.RULE_ITERATOR is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert "yield" in node.STOP_REASON


@pytest.mark.parametrize("invalid", [None, "wrong type", float("nan")])
def test_invalid_yield_cancels_remaining_sequence(invalid):
    node = make_node()

    def rule(*_args):
        yield movement()
        if isinstance(invalid, float):
            command = movement()
            command.angular.z = invalid
            yield command
        else:
            yield invalid
        yield movement()

    node.RULE_FUNCTION = rule
    node.timer_callback()
    node.timer_callback()
    assert not node.DRIVING_ENABLED
    assert node.RULE_ITERATOR is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0


def test_stop_restart_during_next_never_publishes_or_resumes_old_sequence():
    node = make_node()
    started, release = threading.Event(), threading.Event()
    calls, closed = [], []

    def rule(*_args):
        invocation = len(calls)
        calls.append(True)
        try:
            yield movement()
            if invocation == 0:
                started.set()
                assert release.wait(2)
            yield movement()
            yield movement()
        finally:
            closed.append(invocation)

    node.RULE_FUNCTION = rule
    node.timer_callback()
    worker = threading.Thread(target=node.timer_callback)
    worker.start()
    try:
        assert started.wait(2)
        node.driving_enabled_callback(SimpleNamespace(data=False))
        node.driving_enabled_callback(SimpleNamespace(data=True))
        assert closed == []  # Cancellation must not call close() while next() executes.
    finally:
        release.set()
        worker.join(2)
    assert not worker.is_alive()
    assert all(message.linear.x == 0 for message in node.CMD_PUBLISHER.messages[1:])
    assert node.RULE_ITERATOR is None
    node.timer_callback()
    assert len(calls) == 2
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0.4


def test_each_next_execution_is_subject_to_rule_timeout(monkeypatch):
    node = make_node()
    clock = [10.0]
    monkeypatch.setitem(NAMESPACE, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    node.SENSOR_TIMES["lane"] = 10.0
    node.SENSOR_TIMEOUT_SEC = 10.0

    def slow_next(*_args):
        yield movement()
        clock[0] += 1.1
        yield movement()

    node.RULE_FUNCTION = slow_next
    node.timer_callback()
    node.timer_callback()
    assert not node.DRIVING_ENABLED
    assert node.RULE_ITERATOR is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert "초과" in node.STOP_REASON


def test_cancelled_generator_finally_runs_outside_control_lock_under_watchdog():
    node = make_node()
    cleaning, release = threading.Event(), threading.Event()

    def rule(*_args):
        try:
            for _ in range(5):
                yield movement()
        finally:
            cleaning.set()
            assert release.wait(2)

    node.RULE_FUNCTION = rule
    node.timer_callback()
    node.driving_enabled_callback(SimpleNamespace(data=False))
    assert not cleaning.is_set()  # Pause must publish its stop before any student cleanup.
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    worker = threading.Thread(target=node.timer_callback)
    worker.start()
    try:
        assert cleaning.wait(2)
        with node.STATE_LOCK:  # The student's blocked finally cannot hold this lock.
            node.RULE_STARTED = time.monotonic() - 2
        node.watchdog_callback()
        assert not node.DRIVING_ENABLED
        assert "초과" in node.STOP_REASON
        assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    finally:
        release.set()
        worker.join(2)
    assert not worker.is_alive()
    assert node.RULE_ITERATOR is None
    assert node.RETIRED_RULE_ITERATORS == []


def test_shutdown_cancels_queued_sequence_and_finishes_with_stop():
    node = make_node()
    queued_rule(node)
    assert node.destroy_node() is True
    assert node.destroyed
    assert not node.DRIVING_ENABLED
    assert node.RULE_ITERATOR is None
    assert node.CMD_PUBLISHER.messages[-1].linear.x == 0
    assert "종료" in node.STOP_REASON


def test_cancel_during_first_yield_defers_generator_finally_to_next_timer():
    node = make_node()
    started, release = threading.Event(), threading.Event()
    closed = []

    def rule(*_args):
        try:
            started.set()
            assert release.wait(2)
            yield movement()
        finally:
            closed.append(node.RULE_STARTED is not None)

    node.RULE_FUNCTION = rule
    worker = threading.Thread(target=node.timer_callback)
    worker.start()
    try:
        assert started.wait(2)
        node.driving_enabled_callback(SimpleNamespace(data=False))
    finally:
        release.set()
        worker.join(2)
    assert not worker.is_alive()
    assert closed == []
    assert all(command.linear.x == 0 for command in node.CMD_PUBLISHER.messages)
    node.timer_callback()
    assert closed == [True]
    assert node.RETIRED_RULE_ITERATORS == []
