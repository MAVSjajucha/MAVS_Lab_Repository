import os
from glob import glob

from setuptools import find_packages, setup


PACKAGE_NAME = "my_rule_based_learning"


setup(
    name=PACKAGE_NAME,
    version="0.3.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + PACKAGE_NAME],
        ),
        ("share/" + PACKAGE_NAME, ["package.xml"]),
        (
            os.path.join("share", PACKAGE_NAME, "launch"),
            glob("launch/*.launch.py"),
        ),
        (
            os.path.join("share", PACKAGE_NAME, "config"),
            glob("config/*.yaml"),
        ),
        (
            os.path.join("share", PACKAGE_NAME, "web"),
            glob("web/*"),
        ),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="jetson",
    maintainer_email="jetson@yahboom.local",
    description="Rule-based autonomous-driving learning nodes.",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "grid_node = my_rule_based_learning.grid_node:main",
            "vis_node = my_rule_based_learning.vis_node:main",
            "decision_node = my_rule_based_learning.decision_node:main",
        ],
    },
)
