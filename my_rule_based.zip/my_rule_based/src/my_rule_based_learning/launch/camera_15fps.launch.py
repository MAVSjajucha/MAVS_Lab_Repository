from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    camera_driver = Node(
        package='ascamera',
        executable='ascamera_node',
        namespace='ascamera_hp60c',
        name='camera_publisher',
        output='screen',
        respawn=True,
        respawn_delay=3.0,
        parameters=[
            {'usb_bus_no': -1},
            {'usb_path': 'null'},
            {
                'confiPath':
                '/home/jetson/yahboomcar_ros2_ws/'
                'software/library_ws/src/ascamera/configurationfiles'
            },
            {'color_pcl': False},
            {'pub_tfTree': True},
            {'depth_width': 640},
            {'depth_height': 480},
            {'rgb_width': 640},
            {'rgb_height': 480},
            {'fps': 25},
        ],
    )

    # vis_node가 직접 JPEG 영상을 생성하므로
    # Yahboom camera_app 압축 노드는 실행하지 않는다.
    return LaunchDescription([
        camera_driver,
    ])
