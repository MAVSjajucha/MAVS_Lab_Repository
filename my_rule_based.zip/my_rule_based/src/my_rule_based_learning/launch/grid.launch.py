import os

from ament_index_python.packages import (
    get_package_share_directory,
)
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description() -> LaunchDescription:
    package_share = get_package_share_directory(
        "my_rule_based_learning"
    )

    parameter_file = os.path.join(
        package_share,
        "config",
        "grid.yaml",
    )

    grid_node = Node(
        package="my_rule_based_learning",
        executable="grid_node",
        name="grid_node",
        output="screen",
        emulate_tty=True,
        parameters=[parameter_file],
    )

    return LaunchDescription([grid_node])
