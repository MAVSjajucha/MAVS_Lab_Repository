import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    LogInfo,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import (
    PythonLaunchDescriptionSource,
)
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    mission_mode = LaunchConfiguration("mission_mode")

    start_bringup = LaunchConfiguration("start_bringup")
    start_camera = LaunchConfiguration("start_camera")
    start_lidar = LaunchConfiguration("start_lidar")
    start_grid = LaunchConfiguration("start_grid")
    start_vis = LaunchConfiguration("start_vis")
    start_decision = LaunchConfiguration("start_decision")
    enable_motion = LaunchConfiguration("enable_motion")

    learning_share = get_package_share_directory(
        "my_rule_based_learning"
    )

    # 모든 미션에서 동일한 차량·센서 구성을 사용한다.
    bringup_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("yahboomcar_bringup"),
                "launch",
                "yahboomcar_bringup_A1_launch.py",
            ])
        ),
        condition=IfCondition(start_bringup),
    )

    camera_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                learning_share,
                "launch",
                "camera_15fps.launch.py",
            )
        ),
        condition=IfCondition(start_camera),
    )

    lidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("sllidar_ros2"),
                "launch",
                "sllidar_c1_launch.py",
            ])
        ),
        condition=IfCondition(start_lidar),
    )

    grid_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                learning_share,
                "launch",
                "grid.launch.py",
            )
        ),
        condition=IfCondition(start_grid),
    )

    vis_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                learning_share,
                "launch",
                "vis.launch.py",
            )
        ),
        condition=IfCondition(start_vis),
    )

    decision_config = os.path.join(
        learning_share,
        "config",
        "decision.yaml",
    )

    decision_node = Node(
        package="my_rule_based_learning",
        executable="decision_node",
        name="decision_node",
        output="screen",
        parameters=[
            decision_config,
            {
                "mode": mission_mode,
                "publish_cmd_vel": ParameterValue(
                    enable_motion,
                    value_type=bool,
                ),
            },
        ],
        condition=IfCondition(start_decision),
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            "mission_mode",
            default_value="lane",
            description=(
                "lane, depth, lidar, integrated 중 하나"
            ),
        ),
        DeclareLaunchArgument(
            "start_bringup",
            default_value="true",
            description=(
                "차량 bringup 실행 여부. "
                "이미 실행 중이면 false"
            ),
        ),
        DeclareLaunchArgument(
            "start_camera",
            default_value="true",
            description=(
                "HP60C RGB/Depth 카메라 실행 여부"
            ),
        ),
        DeclareLaunchArgument(
            "start_lidar",
            default_value="true",
            description="C1 LiDAR 실행 여부",
        ),
        DeclareLaunchArgument(
            "start_grid",
            default_value="true",
            description="grid_node 실행 여부",
        ),
        DeclareLaunchArgument(
            "start_vis",
            default_value="true",
            description="vis_node 실행 여부",
        ),
        DeclareLaunchArgument(
            "start_decision",
            default_value="true",
            description="decision_node 실행 여부",
        ),
        DeclareLaunchArgument(
            "enable_motion",
            default_value="false",
            description=(
                "true일 때만 /cmd_vel을 발행합니다."
            ),
        ),
        LogInfo(
            msg=[
                "[my_rule_based] mission_mode=",
                mission_mode,
                ", all_sensor_subscriptions=true",
                ", enable_motion=",
                enable_motion,
            ]
        ),
        bringup_launch,
        camera_launch,
        lidar_launch,
        grid_launch,
        vis_launch,
        decision_node,
    ])
